package com.shovel.filemanager.ui.screens

import com.shovel.filemanager.ui.localization.LText
import com.shovel.filemanager.ui.localization.uiText
import com.shovel.filemanager.ui.localization.rememberLocalizedDateTimeFormat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import com.shovel.filemanager.ui.theme.ShovelButton as Button
import com.shovel.filemanager.ui.theme.ShovelCard as Card
import androidx.compose.material3.CircularProgressIndicator
import com.shovel.filemanager.ui.theme.ShovelDropdownMenu as DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import com.shovel.filemanager.ui.theme.ShovelSurface as Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import com.shovel.filemanager.ui.theme.ShovelDialog
import com.shovel.filemanager.core.FileSystemRules
import com.shovel.filemanager.data.SafEntry
import com.shovel.filemanager.data.DirectoryDisplaySettings
import com.shovel.filemanager.data.DirectoryGridStyle
import com.shovel.filemanager.data.DirectoryLayoutMode
import com.shovel.filemanager.model.SortDirection
import com.shovel.filemanager.model.SortMode
import com.shovel.filemanager.ui.MainViewModel
import com.shovel.filemanager.ui.SafBrowserUiState
import com.shovel.filemanager.ui.components.DirectoryBrowserToolbar
import com.shovel.filemanager.ui.components.DirectoryGridItemContent
import com.shovel.filemanager.ui.components.DirectoryDisplayMenuItems
import com.shovel.filemanager.ui.components.DirectoryEntryFilter
import com.shovel.filemanager.ui.components.DirectoryEntryFilterDialog
import com.shovel.filemanager.ui.components.DirectoryEntryFilterRules
import com.shovel.filemanager.ui.components.DirectoryDisplaySettingsDialog
import com.shovel.filemanager.ui.components.SafFileVisual
import com.shovel.filemanager.ui.components.DirectoryQuickSearchField
import com.shovel.filemanager.ui.components.DirectorySearchButton
import com.shovel.filemanager.ui.components.ShovelPullToRefresh
import com.shovel.filemanager.ui.components.ShovelModalDialog
import com.shovel.filemanager.ui.components.LazyListFastScroller
import com.shovel.filemanager.ui.components.LazyGridFastScroller
import com.shovel.filemanager.ui.components.DeleteConfirmationDialog
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun SafBrowserDialog(
    state: SafBrowserUiState,
    selectedLocalPath: String?,
    viewModel: MainViewModel,
    onDismiss: () -> Unit,
) {
    var create by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf<SafEntry?>(null) }
    var delete by remember { mutableStateOf<SafEntry?>(null) }
    var info by remember { mutableStateOf<SafEntry?>(null) }
    var menu by remember(state.currentUri) { mutableStateOf(false) }
    var showDisplaySettings by remember(state.currentUri) { mutableStateOf(false) }
    var searchVisible by remember(state.location?.uri) { mutableStateOf(false) }
    var searchQuery by remember(state.location?.uri) { mutableStateOf("") }
    var entryFilters by remember(state.currentUri) { mutableStateOf<Set<DirectoryEntryFilter>>(emptySet()) }
    var showEntryFilter by remember(state.currentUri) { mutableStateOf(false) }
    val listState = androidx.compose.runtime.key(state.currentUri) { rememberLazyListState() }
    val gridState = androidx.compose.runtime.key(state.currentUri) { rememberLazyGridState() }
    LaunchedEffect(state.currentUri) {
        searchVisible = false
        searchQuery = ""
    }
    var displayedEntries by remember(state.currentUri) { mutableStateOf<List<SafEntry>>(emptyList()) }
    var transforming by remember(state.currentUri) { mutableStateOf(false) }
    LaunchedEffect(state.entries, searchQuery, entryFilters, state.sortMode, state.sortDirection) {
        val entries = state.entries
        val query = searchQuery.trim()
        transforming = true
        displayedEntries = emptyList()
        displayedEntries = withContext(Dispatchers.Default) {
            val ordered = orderSafEntries(entries, state.sortMode, state.sortDirection)
            ordered.filter { entry ->
                (query.isEmpty() || entry.name.contains(query, ignoreCase = true)) &&
                    DirectoryEntryFilterRules.matches(entry.kind, entryFilters)
            }
        }
        transforming = false
    }

    val navigateBack: () -> Unit = { if (!viewModel.navigateSafBack()) onDismiss() }
    ShovelDialog(onDismissRequest = navigateBack, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        com.shovel.filemanager.ui.theme.AppearancePage(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize().padding(WindowInsets.safeDrawing.asPaddingValues())) {
                DirectoryBrowserToolbar(
                    title = state.title,
                    path = safLocationLabel(state),
                    backEnabled = true,
                    forwardEnabled = false,
                    upEnabled = state.backStack.isNotEmpty(),
                    searchActive = searchVisible,
                    grid = state.grid,
                    testTagPrefix = "saf",
                    onBack = navigateBack,
                    onForward = {},
                    onUp = { viewModel.navigateSafBack() },
                    onToggleSearch = {
                        searchVisible = !searchVisible
                        if (!searchVisible) searchQuery = ""
                    },
                    onToggleLayout = viewModel::toggleSafLayout,
                    onOpenSettings = { showDisplaySettings = true },
                ) {
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Folder actions"))
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            if (selectedLocalPath != null) {
                                DropdownMenuItem(
                                    text = { LText("Copy the selected local item here") },
                                    leadingIcon = { Icon(Icons.Rounded.FileUpload, contentDescription = null) },
                                    onClick = { menu = false; viewModel.copyLocalToSaf(selectedLocalPath) },
                                )
                                HorizontalDivider()
                            }
                            DirectoryDisplayMenuItems(
                                grid = state.grid,
                                includeHidden = false,
                                hiddenFilesAvailable = false,
                                showThumbnails = state.showThumbnails,
                                thumbnailsAvailable = true,
                                sortMode = state.sortMode,
                                sortDirection = state.sortDirection,
                                displaySettingsTestTag = "saf_display_settings",
                                onToggleHidden = {},
                                onToggleLayout = viewModel::toggleSafLayout,
                                onToggleThumbnails = viewModel::toggleSafThumbnails,
                                onOpenSettings = { showDisplaySettings = true },
                                onSort = { mode -> viewModel.setSafSort(mode, state.sortDirection) },
                                onDismissMenu = { menu = false },
                                filterActive = entryFilters.isNotEmpty(),
                                onOpenFilter = { showEntryFilter = true },
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { LText("Refresh") },
                                leadingIcon = { Icon(Icons.Rounded.Refresh, contentDescription = null) },
                                enabled = !state.loading,
                                onClick = { menu = false; viewModel.refreshSafBrowser() },
                            )
                        }
                    }
                }
                if (searchVisible) {
                    DirectoryQuickSearchField(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        onClose = { searchVisible = false; searchQuery = "" },
                        filterActive = entryFilters.isNotEmpty(),
                        onOpenFilter = { showEntryFilter = true },
                    )
                }
                HorizontalDivider()
                state.error?.let { error ->
                    Card(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                        LText(error, modifier = Modifier.padding(14.dp), color = MaterialTheme.colorScheme.error)
                    }
                }
                ShovelPullToRefresh(
                    isRefreshing = state.loading,
                    onRefresh = viewModel::refreshSafBrowser,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    testTag = "pull_to_refresh_saf",
                ) {
                    if (state.loading && state.entries.isEmpty()) {
                        CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    } else if (transforming && displayedEntries.isEmpty()) {
                        CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    } else if (state.entries.isEmpty() && state.error == null) {
                        Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.Folder, contentDescription = null, modifier = Modifier.size(56.dp))
                            LText("Folder is empty", style = MaterialTheme.typography.titleMedium)
                        }
                    } else if (displayedEntries.isEmpty()) {
                        Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Rounded.Folder, contentDescription = null, modifier = Modifier.size(56.dp))
                            LText("No matches found", style = MaterialTheme.typography.titleMedium)
                            LText("Try another name", style = MaterialTheme.typography.bodySmall)
                        }
                    } else if (state.grid) {
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(state.gridColumns.coerceIn(1, 6)),
                            state = gridState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(10.dp, 8.dp, 10.dp, 92.dp),
                            horizontalArrangement = Arrangement.spacedBy((8f * state.spacingScalePercent / 100f).dp),
                            verticalArrangement = Arrangement.spacedBy((8f * state.spacingScalePercent / 100f).dp),
                        ) {
                            gridItems(displayedEntries, key = SafEntry::uri) { entry ->
                                SafEntryGridItem(
                                    entry = entry,
                                    showThumbnails = state.showThumbnails,
                                    iconScalePercent = state.iconScalePercent,
                                    gridStyle = state.gridStyle,
                                    onOpen = { viewModel.openSafEntry(entry) },
                                    onRename = { rename = entry },
                                    onInfo = { info = entry },
                                    onDelete = { delete = entry },
                                    onDownload = { viewModel.copySafToLocal(entry) },
                                )
                            }
                        }
                    } else {
                        LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 92.dp)) {
                            items(displayedEntries, key = SafEntry::uri) { entry ->
                                SafEntryRow(
                                    entry = entry,
                                    showThumbnails = state.showThumbnails,
                                    iconScalePercent = state.iconScalePercent,
                                    spacingScalePercent = state.spacingScalePercent,
                                    onOpen = { viewModel.openSafEntry(entry) },
                                    onRename = { rename = entry },
                                    onInfo = { info = entry },
                                    onDelete = { delete = entry },
                                    onDownload = { viewModel.copySafToLocal(entry) },
                                )
                            }
                        }
                    }
                    if (displayedEntries.isNotEmpty()) {
                        if (state.grid) LazyGridFastScroller(gridState) else LazyListFastScroller(listState)
                    }
                    FloatingActionButton(onClick = { create = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp)) {
                        Icon(Icons.Rounded.Add, contentDescription = uiText("Create"))
                    }
                }
            }
        }
    }

    if (create) {
        SafCreateDialog(
            onDismiss = { create = false },
            onFolder = { name -> viewModel.createSafDirectory(name); create = false },
            onFile = { name -> viewModel.createSafFile(name); create = false },
        )
    }
    rename?.let { entry ->
        SafNameDialog(
            title = "Rename",
            initial = entry.name,
            confirm = "Rename",
            onDismiss = { rename = null },
            onConfirm = { name -> viewModel.renameSafEntry(entry, name); rename = null },
        )
    }
    info?.let { entry ->
        SafInfoDialog(entry = entry, onDismiss = { info = null })
    }
    delete?.let { entry ->
        DeleteConfirmationDialog(
            names = listOf(entry.name), permanent = true,
            onDismiss = { delete = null },
            onConfirm = { viewModel.deleteSafEntry(entry); delete = null },
            loadSummary = { viewModel.loadSafSelectionInfo(listOf(entry.uri)) },
            confirmLabel = "Delete",
            explanation = "The item will be deleted through Android's document provider and will not enter Shovel Trash.",
        )
    }
    if (showDisplaySettings) {
        DirectoryDisplaySettingsDialog(
            initialSettings = DirectoryDisplaySettings(
                layoutMode = if (state.grid) DirectoryLayoutMode.GRID else DirectoryLayoutMode.LIST,
                iconScalePercent = state.iconScalePercent,
                spacingScalePercent = state.spacingScalePercent,
                gridColumns = state.gridColumns,
                gridStyle = state.gridStyle,
                showThumbnails = state.showThumbnails,
            ),
            thumbnailsAvailable = true,
            initialSortMode = state.sortMode,
            initialSortDirection = state.sortDirection,
            onDismiss = { showDisplaySettings = false },
            onApply = {
                viewModel.setSafDisplaySettings(it)
                showDisplaySettings = false
            },
            onApplySort = viewModel::setSafSort,
            onApplyToAll = { settings, mode, direction ->
                viewModel.applyDirectoryDisplaySettingsToAll(settings, mode, direction)
                showDisplaySettings = false
            },
        )
    }
    if (showEntryFilter) {
        DirectoryEntryFilterDialog(
            selected = entryFilters,
            onSelectedChange = { entryFilters = it },
            onDismiss = { showEntryFilter = false },
        )
    }
}

@Composable
private fun SafEntryRow(
    entry: SafEntry,
    showThumbnails: Boolean,
    iconScalePercent: Int,
    spacingScalePercent: Int,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onInfo: () -> Unit,
    onDelete: () -> Unit,
    onDownload: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val iconSize = (42f * iconScalePercent / 100f).dp
    val verticalPadding = (4f * spacingScalePercent / 100f).dp
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = verticalPadding),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Card(onClick = onOpen, modifier = Modifier.weight(1f)) {
            Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                SafFileVisual(
                    entry = entry,
                    targetWidth = iconSize,
                    targetHeight = iconSize,
                    showThumbnails = showThumbnails,
                    modifier = Modifier.size(iconSize),
                )
                Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(entry.name, fontWeight = if (entry.directory) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (!entry.directory) Text(FileSystemRules.humanBytes(entry.sizeBytes), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Actions")) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                SafEntryMenuItems(
                    entry = entry,
                    dismiss = { menu = false },
                    onOpen = onOpen,
                    onRename = onRename,
                    onInfo = onInfo,
                    onDelete = onDelete,
                    onDownload = onDownload,
                )
            }
        }
    }
}

@Composable
private fun SafEntryGridItem(
    entry: SafEntry,
    showThumbnails: Boolean,
    iconScalePercent: Int,
    gridStyle: DirectoryGridStyle,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onInfo: () -> Unit,
    onDelete: () -> Unit,
    onDownload: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val iconSize = (72f * iconScalePercent / 100f).dp
    Card(
        onClick = onOpen,
        modifier = Modifier.fillMaxWidth(),
        shape = if (gridStyle == DirectoryGridStyle.CLASSIC) androidx.compose.foundation.shape.RoundedCornerShape(4.dp) else androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = if (gridStyle == DirectoryGridStyle.CLASSIC) MaterialTheme.colorScheme.surface.copy(alpha = 0f) else MaterialTheme.colorScheme.surfaceContainer,
        ),
    ) {
        DirectoryGridItemContent(
            title = entry.name,
            metadata = if (entry.directory) null else FileSystemRules.humanBytes(entry.sizeBytes),
            visualHeight = iconSize,
            innerPadding = 8.dp,
            visual = {
                SafFileVisual(
                    entry = entry,
                    targetWidth = iconSize,
                    targetHeight = iconSize,
                    showThumbnails = showThumbnails,
                    modifier = Modifier.fillMaxSize(),
                )
            },
            actions = {
                IconButton(onClick = { menu = true }, modifier = Modifier.align(Alignment.TopEnd)) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Actions"))
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    SafEntryMenuItems(
                        entry = entry,
                        dismiss = { menu = false },
                        onOpen = onOpen,
                        onRename = onRename,
                        onInfo = onInfo,
                        onDelete = onDelete,
                        onDownload = onDownload,
                    )
                }
            },
        )
    }
}

@Composable
private fun SafEntryMenuItems(
    entry: SafEntry,
    dismiss: () -> Unit,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onInfo: () -> Unit,
    onDelete: () -> Unit,
    onDownload: () -> Unit,
) {
    DropdownMenuItem(
        text = { LText(if (entry.directory) "Open folder" else "Preview here") },
        leadingIcon = { Icon(if (entry.directory) Icons.Rounded.Folder else Icons.Rounded.Visibility, contentDescription = null) },
        onClick = { dismiss(); onOpen() },
    )
    DropdownMenuItem(
        text = { LText("Copy to active pane") },
        leadingIcon = { Icon(Icons.Rounded.FileDownload, contentDescription = null) },
        onClick = { dismiss(); onDownload() },
    )
    HorizontalDivider()
    DropdownMenuItem(
        text = { LText("Rename") },
        leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
        enabled = entry.canWrite,
        onClick = { dismiss(); onRename() },
    )
    DropdownMenuItem(
        text = { LText("Info") },
        leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
        onClick = { dismiss(); onInfo() },
    )
    DropdownMenuItem(
        text = { LText("Delete") },
        leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null) },
        enabled = entry.canWrite,
        onClick = { dismiss(); onDelete() },
    )
}

private fun safLocationLabel(state: SafBrowserUiState): String = buildString {
    append(state.location?.title ?: state.title)
    state.backStack.drop(1).forEach { (_, title) -> append(" / ").append(title) }
    if (state.backStack.isNotEmpty()) append(" / ").append(state.title)
}

private fun orderSafEntries(
    entries: List<SafEntry>,
    mode: SortMode,
    direction: SortDirection,
): List<SafEntry> {
    val ascending = when (mode) {
        SortMode.NAME -> compareBy<SafEntry> { it.name.lowercase(Locale.ROOT) }
        SortMode.SIZE -> compareBy<SafEntry> { it.sizeBytes }.thenBy { it.name.lowercase(Locale.ROOT) }
        SortMode.MODIFIED -> compareBy<SafEntry> { it.modifiedAtMillis }.thenBy { it.name.lowercase(Locale.ROOT) }
        SortMode.TYPE -> compareBy<SafEntry> { it.kind }.thenBy { it.name.lowercase(Locale.ROOT) }
    }
    val comparator = if (direction == SortDirection.ASCENDING) ascending else ascending.reversed()
    val (directories, files) = entries.partition(SafEntry::directory)
    return directories.sortedWith(comparator) + files.sortedWith(comparator)
}

@Composable
internal fun SafInfoDialog(entry: SafEntry, onDismiss: () -> Unit) {
    val dateFormat = rememberLocalizedDateTimeFormat(DateFormat.MEDIUM, DateFormat.SHORT)
    ShovelModalDialog(
        onDismissRequest = onDismiss,
        icon = Icons.Rounded.Info,
        title = entry.name,
        translateTitle = false,
        showFooter = false,
        modifier = Modifier.testTag("saf_info_dialog"),
        actions = {},
    ) {
        Column(modifier = Modifier.verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LText(if (entry.directory) "Folder" else entry.mimeType ?: "File")
            if (!entry.directory) SafInfoLine("Size", FileSystemRules.humanBytes(entry.sizeBytes))
            entry.modifiedAtMillis.takeIf { it > 0L }?.let { SafInfoLine("Modified", dateFormat.format(Date(it))) }
            Text(entry.uri, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun SafInfoLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        LText(label, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Text(value, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
internal fun SafCreateDialog(onDismiss: () -> Unit, onFolder: (String) -> Unit, onFile: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    ShovelModalDialog(
        onDismissRequest = onDismiss,
        icon = Icons.Rounded.CreateNewFolder,
        title = "Create",
        modifier = Modifier.testTag("saf_create_dialog"),
        actions = {
            TextButton(onClick = onDismiss) { LText("Cancel") }
            OutlinedButton(onClick = { onFile(name) }, enabled = name.isNotBlank()) { LText("File") }
            Button(onClick = { onFolder(name) }, enabled = name.isNotBlank()) { LText("Folder") }
        },
    ) {
        OutlinedTextField(
            value = name, onValueChange = { name = it }, label = { LText("Name") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(18.dp),
        )
    }
}

@Composable
internal fun SafNameDialog(
    title: String,
    initial: String,
    confirm: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var name by remember(initial) { mutableStateOf(initial) }
    ShovelModalDialog(
        onDismissRequest = onDismiss,
        title = title,
        icon = Icons.Rounded.Edit,
        modifier = Modifier.testTag("saf_name_dialog"),
        actions = {
            TextButton(onClick = onDismiss) { LText("Cancel") }
            Button(onClick = { onConfirm(name) }, enabled = name.isNotBlank()) { LText(confirm) }
        },
    ) {
        OutlinedTextField(
            value = name, onValueChange = { name = it }, label = { LText("Name") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(18.dp),
        )
    }
}
