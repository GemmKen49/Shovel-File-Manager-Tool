package com.shovel.filemanager.ui.preview

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.CircularProgressIndicator
import com.shovel.filemanager.ui.theme.ShovelDropdownMenu as DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.shovel.filemanager.ui.localization.LText
import com.shovel.filemanager.ui.localization.uiText

/** One header menu for every preview source, including temporary remote working copies. */
@Composable
internal fun PreviewActionsMenu(
    sourceKey: String,
    editEnabled: Boolean,
    hashRunning: Boolean,
    onOpenWith: () -> Unit,
    onEditWith: (() -> Unit)?,
    onSignPdf: (() -> Unit)?,
    onShare: () -> Unit,
    onCalculateHash: () -> Unit,
    onDetails: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
) {
    var expanded by remember(sourceKey) { mutableStateOf(false) }
    fun invoke(action: () -> Unit) { expanded = false; action() }
    Box {
        IconButton(onClick = { expanded = true }, modifier = Modifier.testTag("preview_actions_menu")) {
            Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Actions"))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            onDetails?.let { action ->
                DropdownMenuItem(text = { LText("Info") },
                    leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
                    onClick = { invoke(action) }, modifier = Modifier.testTag("preview_details_action"))
            }
            DropdownMenuItem(
                text = { LText("Open with another app") },
                leadingIcon = { Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null) },
                onClick = { invoke(onOpenWith) }, modifier = Modifier.testTag("open-with-action"),
            )
            onSignPdf?.let { action ->
                DropdownMenuItem(
                    text = { LText("Sign PDF") },
                    leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
                    enabled = editEnabled, onClick = { invoke(action) }, modifier = Modifier.testTag("sign-pdf-action"),
                )
            }
            onEditWith?.let { action ->
                DropdownMenuItem(
                    text = { LText("Edit with another app") },
                    leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
                    enabled = editEnabled, onClick = { invoke(action) }, modifier = Modifier.testTag("edit-with-action"),
                )
            }
            DropdownMenuItem(
                text = { LText("Share") },
                leadingIcon = { Icon(Icons.Rounded.Share, contentDescription = null) },
                onClick = { invoke(onShare) }, modifier = Modifier.testTag("preview_share_action"),
            )
            DropdownMenuItem(
                text = { LText("SHA-256") },
                leadingIcon = {
                    if (hashRunning) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Rounded.Calculate, contentDescription = null)
                },
                enabled = !hashRunning, onClick = { invoke(onCalculateHash) }, modifier = Modifier.testTag("preview_hash_action"),
            )
            onDelete?.let { action ->
                DropdownMenuItem(
                    text = { LText("Delete") },
                    leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null) },
                    enabled = editEnabled,
                    onClick = { invoke(action) },
                    modifier = Modifier.testTag("preview_delete_action"),
                )
            }
        }
    }
}
