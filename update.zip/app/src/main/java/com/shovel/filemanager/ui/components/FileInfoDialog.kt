package com.shovel.filemanager.ui.components

import com.shovel.filemanager.model.EntryKind
import com.shovel.filemanager.data.sizeText
import com.shovel.filemanager.data.itemsText
import com.shovel.filemanager.data.FolderStats
import android.widget.Toast

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shovel.filemanager.core.FileSystemRules
import com.shovel.filemanager.cleanup.ApplicationActions
import com.shovel.filemanager.data.FileSelectionSummary
import com.shovel.filemanager.model.FileEntry
import com.shovel.filemanager.ui.localization.LText
import com.shovel.filemanager.ui.localization.rememberLocalizedDateTimeFormat
import com.shovel.filemanager.ui.localization.uiText
import java.text.DateFormat
import java.util.Date

@Composable
fun FileInfoDialog(entry: FileEntry, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val settingsError = uiText("Could not open app settings")
    val dateFormat = rememberLocalizedDateTimeFormat(DateFormat.MEDIUM, DateFormat.SHORT)
    ShovelModalDialog(
        title = entry.name,
        translateTitle = false,
        icon = Icons.Rounded.Info,
        modifier = Modifier.testTag("file_info_dialog"),
        onDismissRequest = onDismiss,
        showFooter = entry.packageName != null,
        actions = {
            entry.packageName?.let { packageName ->
                TextButton(onClick = {
                    runCatching { context.startActivity(ApplicationActions.settingsIntent(packageName)) }
                        .onFailure { Toast.makeText(context, settingsError, Toast.LENGTH_LONG).show() }
                }, modifier = Modifier.testTag("open_app_settings")) { LText("Open app settings") }
            }
        },
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            InfoLine("Type", if (entry.isDirectory) uiText("Folder") else entry.extension.uppercase().ifBlank { entry.kind.name })
            if (!entry.isDirectory || entry.sizeBytes > 0L) InfoLine("Size", FileSystemRules.humanBytes(entry.sizeBytes))
            if (entry.modifiedAtMillis > 0L) InfoLine("Modified", dateFormat.format(Date(entry.modifiedAtMillis)))
            entry.packageName?.let { InfoLine("Package", it) }
            entry.appVersionName?.takeIf(String::isNotBlank)?.let { InfoLine("Version", it) }
            if (entry.packageName != null) InfoLine("App type", uiText(if (entry.isSystemApp) "System" else "User"))
            InfoLine(
                "Access",
                listOfNotNull(
                    uiText("Readable").takeIf { entry.isReadable },
                    uiText("Writable").takeIf { entry.isWritable },
                ).ifEmpty { listOf(uiText("Unavailable")) }.joinToString(" · "),
            )
            LText("Path", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
            Text(entry.absolutePath, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun FileInfoDialog(
    entries: List<FileEntry>,
    loadSummary: suspend (Collection<String>) -> Result<FileSelectionSummary>,
    onDismiss: () -> Unit,
    loadFolderStats: (suspend (FileEntry) -> FolderStats?)? = null,
) {
    val context = LocalContext.current
    val settingsError = uiText("Could not open app settings")
    val stableEntries = remember(entries) { entries.distinctBy(FileEntry::absolutePath) }
    val paths = remember(stableEntries) { stableEntries.map(FileEntry::absolutePath) }
    val single = stableEntries.singleOrNull()
    val dateFormat = rememberLocalizedDateTimeFormat(DateFormat.MEDIUM, DateFormat.SHORT)
    var loading by remember(paths) { mutableStateOf(true) }
    var summary by remember(paths) { mutableStateOf<FileSelectionSummary?>(null) }
    var error by remember(paths) { mutableStateOf<String?>(null) }
    var folderStats by remember(paths) { mutableStateOf<FolderStats?>(null) }

    LaunchedEffect(paths) {
        folderStats = null
        val target = single
        if (target != null && loadFolderStats != null && (target.isDirectory || target.kind == EntryKind.ARCHIVE)) {
            folderStats = loadFolderStats(target)
        }
    }

    LaunchedEffect(paths) {
        loading = true
        summary = null
        error = null
        loadSummary(paths).fold(
            onSuccess = { summary = it },
            onFailure = { error = it.message ?: "Could not calculate file information" },
        )
        loading = false
    }

    ShovelModalDialog(
        title = single?.name ?: "Info",
        translateTitle = single == null,
        icon = Icons.Rounded.Info,
        modifier = Modifier.testTag("file_info_dialog"),
        onDismissRequest = onDismiss,
        showFooter = single?.packageName != null,
        actions = {
            single?.packageName?.let { packageName ->
                TextButton(onClick = {
                    runCatching { context.startActivity(ApplicationActions.settingsIntent(packageName)) }
                        .onFailure { Toast.makeText(context, settingsError, Toast.LENGTH_LONG).show() }
                }, modifier = Modifier.testTag("open_app_settings")) { LText("Open app settings") }
            }
        },
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
                if (single == null) InfoLine("Selected", stableEntries.size.toString())
                single?.let { entry ->
                    InfoLine("Type", if (entry.isDirectory) uiText("Folder") else entry.extension.uppercase().ifBlank { entry.kind.name })
                    if (entry.modifiedAtMillis > 0L) InfoLine("Modified", dateFormat.format(Date(entry.modifiedAtMillis)))
                    entry.packageName?.let { InfoLine("Package", it) }
                    entry.appVersionName?.takeIf(String::isNotBlank)?.let { InfoLine("Version", it) }
                    if (entry.packageName != null) InfoLine("App type", uiText(if (entry.isSystemApp) "System" else "User"))
                    InfoLine(
                        "Access",
                        listOfNotNull(
                            uiText("Readable").takeIf { entry.isReadable },
                            uiText("Writable").takeIf { entry.isWritable },
                        ).ifEmpty { listOf(uiText("Unavailable")) }.joinToString(" · "),
                    )
                    folderStats?.let { stats ->
                        InfoLine("Items", stats.itemsText(), Modifier.testTag("file_info_visible_items"))
                        InfoLine(
                            "Visible size",
                            when {
                                !stats.sizeAvailable -> "Not calculated for system folders"
                                entry.isDirectory -> stats.sizeText()
                                else -> "${stats.sizeText()} unpacked"
                            },
                            Modifier.testTag("file_info_visible_size"),
                        )
                    }
                }
                when {
                    loading -> Row(
                        modifier = Modifier.fillMaxWidth().testTag("file_info_loading"),
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                    }
                    error != null -> LText(
                        error.orEmpty(),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.testTag("file_info_error"),
                    )
                    summary != null -> summary?.let { result ->
                        InfoLine("Files", result.fileCount.toString(), Modifier.testTag("file_info_files"))
                        InfoLine("Folders", result.folderCount.toString(), Modifier.testTag("file_info_folders"))
                        InfoLine("Size", FileSystemRules.humanBytes(result.totalBytes), Modifier.testTag("file_info_size"))
                        if (!result.complete) {
                            LText(
                                "Some contents or folder sizes are partial because the safe scan limit was reached.",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.testTag("file_info_partial"),
                            )
                        }
                    }
                }
                if (single != null) {
                    LText("Path", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                    Text(single.absolutePath, style = MaterialTheme.typography.bodySmall)
                }
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        LText(label, modifier = Modifier.width(88.dp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Text(value, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
    }
}
