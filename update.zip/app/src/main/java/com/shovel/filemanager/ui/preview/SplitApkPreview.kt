package com.shovel.filemanager.ui.preview

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import com.shovel.filemanager.ui.theme.ShovelButton as Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.shovel.filemanager.apk.SplitApkArchive
import com.shovel.filemanager.apk.SplitApkInstallActivity
import com.shovel.filemanager.apk.SplitApkPlan
import com.shovel.filemanager.apk.ApkInstallMetadataReader
import com.shovel.filemanager.ui.localization.LText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
internal fun SplitApkPreview(file: File, onExtract: () -> Unit) {
    val context = LocalContext.current
    val result by produceState<Result<SplitApkPlan>?>(null, file.path) {
        value = withContext(Dispatchers.IO) { runCatching { SplitApkArchive.plan(file) } }
    }
    var selected by remember(file.path) { mutableStateOf<Set<String>?>(null) }
    var error by remember(file.path) { mutableStateOf<String?>(null) }
    var confirmInstall by remember(file.path) { mutableStateOf(false) }
    var showContents by remember(file.path) { mutableStateOf(false) }
    val plan = result?.getOrNull()
    val chosen = selected ?: plan?.parts?.map { it.name }?.toSet().orEmpty()
    Column(Modifier.fillMaxSize().padding(14.dp).testTag("split_apk_preview")) {
        LText("APK bundle", style = MaterialTheme.typography.titleLarge)
        LText("Installs the original signed parts. Merging them into one APK would change the signature.", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = onExtract, modifier = Modifier.testTag("split_apk_extract")) { LText("Extract original parts") }
        OutlinedButton(onClick = { showContents = true }, modifier = Modifier.testTag("split_apk_open_contents")) {
            LText("Open archive")
        }
        if (result == null) CircularProgressIndicator()
        result?.exceptionOrNull()?.let { LText(it.message ?: "Invalid APK bundle", color = MaterialTheme.colorScheme.error) }
        if (plan != null) {
            if (plan.hasExtraData) LText("Additional OBB data is not installed automatically. You can extract it separately.")
            Button(onClick = { confirmInstall = true }, modifier = Modifier.testTag("split_apk_install")) {
                LText("Open installer")
            }
            error?.let { LText(it, color = MaterialTheme.colorScheme.error) }
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                items(plan.parts, key = { it.name }) { part ->
                    val required = part == plan.base
                    Row(Modifier.fillMaxWidth().clickable(enabled = !required) {
                        selected = if (part.name in chosen) chosen - part.name else chosen + part.name
                    }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = part.name in chosen, enabled = !required,
                            onCheckedChange = { enabled -> selected = if (enabled) chosen + part.name else chosen - part.name })
                        Text(part.name, Modifier.weight(1f))
                    }
                }
            }
        }
    }
    if (showContents) ApkContentsDialog(file, onDismiss = { showContents = false })
    val installPlan = plan
    if (confirmInstall && installPlan != null) ApkInstallConfirmationDialog(
        cacheKey = "${file.path}:${file.lastModified()}:${chosen.sorted()}",
        load = { ApkInstallMetadataReader.bundle(context, file, installPlan, chosen) },
        onDismiss = { confirmInstall = false },
        onInstall = {
            runCatching {
                if (!context.packageManager.canRequestPackageInstalls()) {
                    context.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${context.packageName}")))
                } else {
                    context.startActivity(Intent(context, SplitApkInstallActivity::class.java)
                        .putExtra("archive", file.path).putStringArrayListExtra("parts", ArrayList(chosen)))
                    confirmInstall = false
                }
            }.onFailure { error = it.message ?: "Installation failed" }
        },
    )
}
