package com.shovel.filemanager.ui.screens

import com.shovel.filemanager.ui.localization.LText
import com.shovel.filemanager.ui.localization.uiText
import com.shovel.filemanager.ui.localization.rememberLocalizedDateTimeFormat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.Schedule
import com.shovel.filemanager.ui.theme.ShovelButton as Button
import com.shovel.filemanager.ui.theme.ShovelCard as Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import com.shovel.filemanager.ui.theme.ShovelDropdownMenu as DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import com.shovel.filemanager.ui.theme.ShovelSurface as Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import com.shovel.filemanager.ui.theme.ShovelDialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shovel.filemanager.core.FileSystemRules
import com.shovel.filemanager.data.TrashBrowserEntry
import com.shovel.filemanager.data.TrashRetentionPeriod
import com.shovel.filemanager.data.DirectoryDisplaySettings
import com.shovel.filemanager.data.DirectoryGridStyle
import com.shovel.filemanager.data.DirectoryLayoutMode
import com.shovel.filemanager.model.SortDirection
import com.shovel.filemanager.model.SortMode
import com.shovel.filemanager.ui.MainViewModel
import com.shovel.filemanager.ui.TrashBrowserUiState
import com.shovel.filemanager.ui.components.DirectoryBrowserToolbar
import com.shovel.filemanager.ui.components.ShovelModalDialog
import com.shovel.filemanager.ui.components.DirectoryDisplayMenuItems
import com.shovel.filemanager.ui.components.DirectoryEntryFilter
import com.shovel.filemanager.ui.components.DirectoryEntryFilterDialog
import com.shovel.filemanager.ui.components.DirectoryEntryFilterRules
import com.shovel.filemanager.ui.components.DirectoryDisplaySettingsDialog
import com.shovel.filemanager.ui.components.DirectoryQuickSearchField
import com.shovel.filemanager.ui.components.ShovelPullToRefresh
import com.shovel.filemanager.ui.components.LocalFileVisual
import com.shovel.filemanager.ui.components.LazyListFastScroller
import com.shovel.filemanager.ui.components.LazyGridFastScroller
import com.shovel.filemanager.ui.components.DeleteConfirmationDialog
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun TrashBrowserDialog(
    state: TrashBrowserUiState,
    itemCount: Int,
    viewModel: MainViewModel,
) {
    val cleanupItemCount = maxOf(itemCount, state.storedItemCount)
    val cleanupAvailable = cleanupItemCount > 0 || !state.storedItemCountComplete
    val preview by viewModel.preview.collectAsStateWithLifecycle()
    var confirmEmpty by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<TrashBrowserEntry?>(null) }
    var searchVisible by remember(state.itemId, state.relativePath) { mutableStateOf(false) }
    var searchQuery by remember(state.itemId, state.relativePath) { mutableStateOf("") }
    var entryFilters by remember(state.itemId, state.relativePath) { mutableStateOf<Set<DirectoryEntryFilter>>(emptySet()) }
    var showEntryFilter by remember(state.itemId, state.relativePath) { mutableStateOf(false) }
    var menu by remember(state.itemId, state.relativePath) { mutableStateOf(false) }
    var showDisplaySettings by remember(state.itemId, state.relativePath) { mutableStateOf(false) }
    var showRetention by remember { mutableStateOf(false) }
    val listState = androidx.compose.runtime.key(state.itemId, state.relativePath) { rememberLazyListState() }
    val gridState = androidx.compose.runtime.key(state.itemId, state.relativePath) { rememberLazyGridState() }
    LaunchedEffect(state.itemId, state.relativePath) {
        searchVisible = false
        searchQuery = ""
    }
    var displayedEntries by remember(state.itemId, state.relativePath) { mutableStateOf<List<TrashBrowserEntry>>(emptyList()) }
    var transforming by remember(state.itemId, state.relativePath) { mutableStateOf(false) }
    LaunchedEffect(state.entries, searchQuery, entryFilters, state.sortMode, state.sortDirection) {
        val entries = state.entries
        val query = searchQuery.trim()
        transforming = true
        displayedEntries = emptyList()
        displayedEntries = withContext(Dispatchers.Default) {
            val ordered = orderTrashEntries(entries, state.sortMode, state.sortDirection)
            ordered.filter { entry ->
                (query.isEmpty() || entry.name.contains(query, ignoreCase = true)) &&
                    DirectoryEntryFilterRules.matches(entry.kind, entryFilters)
            }
        }
        transforming = false
    }

    ShovelDialog(
        onDismissRequest = { if (preview == null) viewModel.navigateTrashBack() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        com.shovel.filemanager.ui.theme.AppearancePage(
            modifier = Modifier.fillMaxSize().testTag("trash-browser-dialog"),
        ) {
            Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                DirectoryBrowserToolbar(
                    title = state.rootName ?: uiText("Trash"),
                    path = trashLocationLabel(state),
                    backEnabled = true,
                    forwardEnabled = false,
                    upEnabled = state.itemId != null,
                    searchActive = searchVisible,
                    grid = state.grid,
                    testTagPrefix = "trash",
                    onBack = { viewModel.navigateTrashBack() },
                    onForward = {},
                    onUp = { viewModel.navigateTrashBack() },
                    onToggleSearch = {
                        searchVisible = !searchVisible
                        if (!searchVisible) searchQuery = ""
                    },
                    onToggleLayout = viewModel::toggleTrashLayout,
                    onOpenSettings = { showDisplaySettings = true },
                ) {
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Folder actions"))
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DirectoryDisplayMenuItems(
                                grid = state.grid,
                                includeHidden = false,
                                hiddenFilesAvailable = false,
                                showThumbnails = state.showThumbnails,
                                thumbnailsAvailable = true,
                                sortMode = state.sortMode,
                                sortDirection = state.sortDirection,
                                displaySettingsTestTag = "trash_display_settings",
                                onToggleHidden = {},
                                onToggleLayout = viewModel::toggleTrashLayout,
                                onToggleThumbnails = viewModel::toggleTrashThumbnails,
                                onOpenSettings = { showDisplaySettings = true },
                                onSort = { mode -> viewModel.setTrashSort(mode, state.sortDirection) },
                                onDismissMenu = { menu = false },
                                filterActive = entryFilters.isNotEmpty(),
                                onOpenFilter = { showEntryFilter = true },
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { LText("Refresh") },
                                leadingIcon = { Icon(Icons.Rounded.Refresh, contentDescription = null) },
                                enabled = !state.loading && !state.emptying,
                                onClick = { menu = false; viewModel.refreshTrashBrowser() },
                            )
                            if (state.itemId == null) {
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            LText("Automatic Trash cleanup")
                                            LText(
                                                trashRetentionLabel(state.retentionPeriod),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    },
                                    leadingIcon = { Icon(Icons.Rounded.Schedule, contentDescription = null) },
                                    modifier = Modifier.testTag("trash_retention_settings"),
                                    onClick = { menu = false; showRetention = true },
                                )
                            }
                            DropdownMenuItem(
                                text = { LText("Empty trash") },
                                leadingIcon = { Icon(Icons.Rounded.DeleteForever, contentDescription = null) },
                                enabled = cleanupAvailable && !state.emptying,
                                modifier = Modifier.testTag("trash_empty_all"),
                                onClick = { menu = false; confirmEmpty = true },
                            )
                        }
                    }
                }
                if (searchVisible) {
                    DirectoryQuickSearchField(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        onClose = { searchVisible = false; searchQuery = "" },
                        filterActive = entryFilters.isNotEmpty(),
                        onOpenFilter = { showEntryFilter = true },
                        modifier = Modifier.testTag("directory_search_field_trash"),
                    )
                }
                HorizontalDivider()
                if (state.loading || state.emptying) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

                ShovelPullToRefresh(
                    isRefreshing = state.loading || state.emptying,
                    onRefresh = viewModel::refreshTrashBrowser,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    testTag = "pull_to_refresh_trash",
                ) {
                    when {
                        state.error != null -> TrashEmptyState("Could not open the folder", state.error)
                        state.loading && state.entries.isEmpty() -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                        transforming && displayedEntries.isEmpty() -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                        state.entries.isEmpty() -> TrashEmptyState(
                            if (state.itemId == null) "Trash is empty" else "Folder is empty",
                            if (state.itemId == null) "Deleted items appear here." else "There are no files in this folder.",
                        )
                        displayedEntries.isEmpty() -> TrashEmptyState("No matches found", "Try another name")
                        state.grid -> LazyVerticalGrid(
                            columns = GridCells.Fixed(state.gridColumns.coerceIn(1, 6)),
                            state = gridState,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy((8f * state.spacingScalePercent / 100f).dp),
                            verticalArrangement = Arrangement.spacedBy((8f * state.spacingScalePercent / 100f).dp),
                        ) {
                            gridItems(displayedEntries, key = { "${it.itemId}|${it.relativePath}|${it.storedPath}" }) { entry ->
                                TrashBrowserGridItem(
                                    entry = entry,
                                    showThumbnails = state.showThumbnails,
                                    iconScalePercent = state.iconScalePercent,
                                    gridStyle = state.gridStyle,
                                    onOpen = { viewModel.openTrashEntry(entry) },
                                    onRestore = { viewModel.restoreTrash(entry.itemId) },
                                    onDelete = { deleteTarget = entry },
                                )
                            }
                        }
                        else -> LazyColumn(
                            state = listState,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(7.dp),
                        ) {
                            items(displayedEntries, key = { "${it.itemId}|${it.relativePath}|${it.storedPath}" }) { entry ->
                                TrashBrowserRow(
                                    entry = entry,
                                    showThumbnails = state.showThumbnails,
                                    iconScalePercent = state.iconScalePercent,
                                    spacingScalePercent = state.spacingScalePercent,
                                    onOpen = { viewModel.openTrashEntry(entry) },
                                    onRestore = { viewModel.restoreTrash(entry.itemId) },
                                    onDelete = { deleteTarget = entry },
                                )
                            }
                        }
                    }
                    if (displayedEntries.isNotEmpty()) {
                        if (state.grid) LazyGridFastScroller(gridState) else LazyListFastScroller(listState)
                    }
                }
            }
        }
    }

    if (confirmEmpty) {
        val roots = state.entries.filter(TrashBrowserEntry::topLevel)
        DeleteConfirmationDialog(
            names = roots.map(TrashBrowserEntry::name), permanent = true,
            title = "Empty all trash?", confirmLabel = "Delete all",
            onDismiss = { confirmEmpty = false },
            onConfirm = { confirmEmpty = false; viewModel.emptyTrash() },
            loadSummary = roots.takeIf { it.isNotEmpty() }?.let { items ->
                suspend { viewModel.loadFileSelectionInfo(items.map(TrashBrowserEntry::storedPath)) }
            },
            explanation = if (state.storedItemCountComplete && cleanupItemCount > 0) {
                "All $cleanupItemCount items in the trash will be deleted permanently and cannot be restored."
            } else {
                "This action cannot be undone."
            },
        )
    }

    deleteTarget?.let { entry ->
        DeleteConfirmationDialog(
            names = listOf(entry.name), permanent = true,
            onDismiss = { deleteTarget = null },
            onConfirm = { viewModel.deleteTrashForever(entry.itemId); deleteTarget = null },
            loadSummary = { viewModel.loadFileSelectionInfo(listOf(entry.storedPath)) },
            explanation = "The item can no longer be restored from the app Trash.",
        )
    }

    if (showDisplaySettings) {
        DirectoryDisplaySettingsDialog(
            initialSettings = DirectoryDisplaySettings(
                layoutMode = if (state.grid) DirectoryLayoutMode.GRID else DirectoryLayoutMode.LIST,
                iconScalePercent = state.iconScalePercent,
                spacingScalePercent = state.spacingScalePercent,
                gridColumns = state.gridColumns,
                gridStyle = state.gridStyle,
                showThumbnails = state.showThumbnails,
            ),
            thumbnailsAvailable = true,
            initialSortMode = state.sortMode,
            initialSortDirection = state.sortDirection,
            onDismiss = { showDisplaySettings = false },
            onApply = {
                viewModel.setTrashDisplaySettings(it)
                showDisplaySettings = false
            },
            onApplySort = viewModel::setTrashSort,
            onApplyToAll = { settings, mode, direction ->
                viewModel.applyDirectoryDisplaySettingsToAll(settings, mode, direction)
                showDisplaySettings = false
            },
        )
    }
    if (showEntryFilter) {
        DirectoryEntryFilterDialog(
            selected = entryFilters,
            onSelectedChange = { entryFilters = it },
            onDismiss = { showEntryFilter = false },
        )
    }
    if (showRetention) {
        var draft by remember(state.retentionPeriod) { mutableStateOf(state.retentionPeriod) }
        ShovelModalDialog(
            title = "Automatic Trash cleanup",
            subtitle = "Choose how long deleted items are kept.",
            icon = Icons.Rounded.Schedule,
            expandedContent = false,
            onDismissRequest = { showRetention = false },
            actions = {
                TextButton(onClick = { showRetention = false }) { LText("Cancel") }
                Button(
                    onClick = {
                        viewModel.setTrashRetentionPeriod(draft)
                        showRetention = false
                    },
                    modifier = Modifier.testTag("trash_retention_save"),
                ) { LText("Save") }
            },
        ) {
            LazyColumn(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                items(TrashRetentionPeriod.entries, key = TrashRetentionPeriod::name) { period ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { draft = period }
                            .padding(horizontal = 18.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        RadioButton(selected = draft == period, onClick = { draft = period })
                        LText(trashRetentionLabel(period))
                    }
                }
            }
        }
    }
}

private fun trashRetentionLabel(period: TrashRetentionPeriod): String = when (period) {
    TrashRetentionPeriod.ONE_DAY -> "After 1 day"
    TrashRetentionPeriod.THREE_DAYS -> "After 3 days"
    TrashRetentionPeriod.SEVEN_DAYS -> "After 7 days"
    TrashRetentionPeriod.FOURTEEN_DAYS -> "After 14 days"
    TrashRetentionPeriod.THIRTY_DAYS -> "After 30 days"
    TrashRetentionPeriod.SIXTY_DAYS -> "After 60 days"
    TrashRetentionPeriod.NINETY_DAYS -> "After 90 days"
    TrashRetentionPeriod.NEVER -> "Never delete automatically"
}

@Composable
private fun TrashBrowserRow(
    entry: TrashBrowserEntry,
    showThumbnails: Boolean,
    iconScalePercent: Int,
    spacingScalePercent: Int,
    onOpen: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit,
) {
    val fileEntry = remember(entry) { entry.toFileEntry() }
    val dateFormat = rememberLocalizedDateTimeFormat()
    val iconSize = (52f * iconScalePercent / 100f).dp
    val verticalPadding = (10f * spacingScalePercent / 100f).dp
    Card(
        onClick = onOpen,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = verticalPadding),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            LocalFileVisual(
                entry = fileEntry,
                targetWidth = iconSize,
                targetHeight = iconSize,
                showThumbnails = showThumbnails,
                modifier = Modifier.size(iconSize),
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    entry.name,
                    fontWeight = if (entry.isDirectory) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                LText(trashEntryMeta(entry, dateFormat), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                entry.originalPath?.let {
                    Text(it, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (entry.topLevel) {
                IconButton(onClick = onRestore) { Icon(Icons.Rounded.Restore, contentDescription = uiText("Restore ${entry.name}")) }
                IconButton(onClick = onDelete) { Icon(Icons.Rounded.DeleteForever, contentDescription = uiText("Delete ${entry.name} permanently")) }
            }
        }
    }
}

@Composable
private fun TrashBrowserGridItem(
    entry: TrashBrowserEntry,
    showThumbnails: Boolean,
    iconScalePercent: Int,
    gridStyle: DirectoryGridStyle,
    onOpen: () -> Unit,
    onRestore: () -> Unit,
    onDelete: () -> Unit,
) {
    val fileEntry = remember(entry) { entry.toFileEntry() }
    val iconSize = (72f * iconScalePercent / 100f).dp
    Card(
        onClick = onOpen,
        modifier = Modifier.fillMaxWidth().testTag("trash-grid-item-${entry.name}"),
        shape = if (gridStyle == DirectoryGridStyle.CLASSIC) androidx.compose.foundation.shape.RoundedCornerShape(4.dp) else androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (gridStyle == DirectoryGridStyle.CLASSIC) MaterialTheme.colorScheme.surface.copy(alpha = 0f) else MaterialTheme.colorScheme.surfaceContainer,
        ),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            LocalFileVisual(
                entry = fileEntry,
                targetWidth = iconSize,
                targetHeight = iconSize,
                showThumbnails = showThumbnails,
                modifier = Modifier.size(iconSize),
            )
            Text(
                entry.name,
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
            if (entry.topLevel) {
                Row {
                    IconButton(onClick = onRestore) {
                        Icon(Icons.Rounded.Restore, contentDescription = uiText("Restore ${entry.name}"))
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Rounded.DeleteForever, contentDescription = uiText("Delete ${entry.name} permanently"))
                    }
                }
            }
        }
    }
}

private fun orderTrashEntries(
    entries: List<TrashBrowserEntry>,
    mode: SortMode,
    direction: SortDirection,
): List<TrashBrowserEntry> {
    val ascending = when (mode) {
        SortMode.NAME -> compareBy<TrashBrowserEntry> { it.name.lowercase(Locale.ROOT) }
        SortMode.SIZE -> compareBy<TrashBrowserEntry> { it.sizeBytes }.thenBy { it.name.lowercase(Locale.ROOT) }
        SortMode.MODIFIED -> compareBy<TrashBrowserEntry> { it.modifiedAtMillis }.thenBy { it.name.lowercase(Locale.ROOT) }
        SortMode.TYPE -> compareBy<TrashBrowserEntry> { it.kind }.thenBy { it.name.lowercase(Locale.ROOT) }
    }
    val comparator = if (direction == SortDirection.ASCENDING) ascending else ascending.reversed()
    val (directories, files) = entries.partition(TrashBrowserEntry::isDirectory)
    return directories.sortedWith(comparator) + files.sortedWith(comparator)
}

@Composable
private fun trashLocationLabel(state: TrashBrowserUiState): String = buildString {
    append(uiText("Trash"))
    state.rootName?.let { append(" / ").append(it) }
    if (state.relativePath.isNotEmpty()) append(" / ").append(state.relativePath)
}

private fun trashEntryMeta(entry: TrashBrowserEntry, dateFormat: DateFormat): String = when {
    entry.deletedAtMillis != null -> buildString {
        append(if (entry.isDirectory) "Folder" else FileSystemRules.humanBytes(entry.sizeBytes))
        append(" · ")
        append(dateFormat.format(Date(entry.deletedAtMillis)))
    }
    entry.isDirectory -> "Folder"
    else -> FileSystemRules.humanBytes(entry.sizeBytes)
}

@Composable
private fun TrashEmptyState(title: String, description: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Rounded.Folder, contentDescription = null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(10.dp))
        LText(title, style = MaterialTheme.typography.titleMedium)
        LText(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
