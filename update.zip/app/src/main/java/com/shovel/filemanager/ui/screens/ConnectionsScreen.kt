package com.shovel.filemanager.ui.screens

import android.content.Intent
import android.net.Uri
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Visibility
import com.shovel.filemanager.ui.theme.ShovelAlertDialog as AlertDialog
import androidx.compose.material3.AssistChip
import com.shovel.filemanager.ui.theme.ShovelButton as Button
import com.shovel.filemanager.ui.theme.ShovelCard as Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import com.shovel.filemanager.ui.theme.ShovelDropdownMenu as DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.onLongClick
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shovel.filemanager.core.FileSystemRules
import com.shovel.filemanager.data.DirectoryDisplaySettings
import com.shovel.filemanager.data.FileEntryOrdering
import com.shovel.filemanager.data.DirectoryGridStyle
import com.shovel.filemanager.data.DirectoryLayoutMode
import com.shovel.filemanager.model.FileEntry
import com.shovel.filemanager.model.ClipboardMode
import com.shovel.filemanager.model.SortMode
import com.shovel.filemanager.model.SortDirection
import com.shovel.filemanager.network.NetworkProfile
import com.shovel.filemanager.network.NetworkProfileRules
import com.shovel.filemanager.network.NetworkProtocol
import com.shovel.filemanager.network.NetworkProvider
import com.shovel.filemanager.network.RemoteEntry
import com.shovel.filemanager.network.RemoteErrorInfo
import com.shovel.filemanager.ui.MainViewModel
import com.shovel.filemanager.ui.NextcloudLoginPhase
import com.shovel.filemanager.ui.NextcloudLoginUiState
import com.shovel.filemanager.data.OptionalFeature
import com.shovel.filemanager.ui.components.featureVisible
import com.shovel.filemanager.ui.RemoteBrowserRules
import com.shovel.filemanager.ui.components.RemoteFileVisual
import com.shovel.filemanager.ui.components.ShovelModalDialog
import com.shovel.filemanager.ui.components.DirectoryGridItemContent
import com.shovel.filemanager.ui.components.DirectoryDisplayMenuItems
import com.shovel.filemanager.ui.components.DirectoryEntryFilter
import com.shovel.filemanager.ui.components.DirectoryEntryFilterDialog
import com.shovel.filemanager.ui.components.DirectoryEntryFilterRules
import com.shovel.filemanager.ui.components.DirectoryBrowserToolbar
import com.shovel.filemanager.ui.components.DirectoryLayoutButton
import com.shovel.filemanager.ui.components.DirectoryDisplaySettingsDialog
import com.shovel.filemanager.ui.components.DirectoryQuickSearchField
import com.shovel.filemanager.ui.components.DirectorySearchButton
import com.shovel.filemanager.ui.components.SelectionActionBar
import com.shovel.filemanager.ui.components.SelectionActionDock
import com.shovel.filemanager.ui.components.SelectionHeader
import com.shovel.filemanager.ui.components.longPressDragSelect
import com.shovel.filemanager.ui.components.ShovelPullToRefresh
import com.shovel.filemanager.ui.components.LazyListFastScroller
import com.shovel.filemanager.ui.components.LazyGridFastScroller
import com.shovel.filemanager.ui.components.DeleteConfirmationDialog
import com.shovel.filemanager.ui.localization.LText
import com.shovel.filemanager.ui.localization.uiText
import com.shovel.filemanager.ui.localization.rememberLocalizedDateTimeFormat
import com.shovel.filemanager.network.RemoteCopyEngine
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
fun ConnectionsScreen(viewModel: MainViewModel, contentPadding: PaddingValues) {
    val nextcloudBrowser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    val state by viewModel.networkState.collectAsStateWithLifecycle()
    val nextcloudLogin by viewModel.nextcloudLogin.collectAsStateWithLifecycle()
    val requestedEditor by viewModel.networkProfileEditor.collectAsStateWithLifecycle()
    val activePanel by viewModel.activePanel.collectAsStateWithLifecycle()
    val left by viewModel.leftPanel.collectAsStateWithLifecycle()
    val right by viewModel.rightPanel.collectAsStateWithLifecycle()
    val localClipboard by viewModel.clipboard.collectAsStateWithLifecycle()
    val remoteClipboard by viewModel.remoteClipboard.collectAsStateWithLifecycle()
    val shovelClipboard by viewModel.shovelClipboard.collectAsStateWithLifecycle()
    val activeLocalState = if (activePanel == com.shovel.filemanager.ui.PanelId.LEFT) left else right
    val activeSelection = activeLocalState.selectedPaths

    var showAdd by remember { mutableStateOf(false) }
    var editingProfile by remember { mutableStateOf<NetworkProfile?>(null) }
    androidx.compose.runtime.LaunchedEffect(requestedEditor) {
        requestedEditor?.let { editingProfile = it; viewModel.consumeNetworkProfileEditor() }
    }
    var deleteProfile by remember { mutableStateOf<NetworkProfile?>(null) }
    var createRemoteItem by remember { mutableStateOf(false) }
    var renameRemote by remember { mutableStateOf<RemoteEntry?>(null) }
    var deleteRemote by remember { mutableStateOf<List<RemoteEntry>?>(null) }
    var showUploadPicker by remember { mutableStateOf(false) }
    var showDisplaySettings by remember { mutableStateOf(false) }
    var remoteInfo by remember { mutableStateOf<RemoteEntry?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(contentPadding)) {
        if (state.connectedProfile == null) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    LText("Tinklas ir nuotolinės vietos", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    LText("SMB 2/3 · SFTP · WebDAV · FTP/FTPS", style = MaterialTheme.typography.bodySmall)
                }
                if (featureVisible(OptionalFeature.CLOUD)) OutlinedButton(
                    onClick = viewModel::openNextcloudSetup,
                    modifier = Modifier.testTag("add_nextcloud"),
                ) {
                    Icon(Icons.Rounded.Cloud, contentDescription = null)
                    LText("Nextcloud", modifier = Modifier.padding(start = 6.dp))
                }
            }
        }

        if (state.connectedProfile == null) {
            Box(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (state.profiles.isEmpty()) {
                        item {
                            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHighest)) {
                                Column(modifier = Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Rounded.Link, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                                    LText("Dar nėra jungčių", style = MaterialTheme.typography.titleMedium)
                                    LText("Pridėkite NAS, serverį arba WebDAV vietą.")
                                }
                            }
                        }
                    }
                    items(state.profiles, key = NetworkProfile::id) { profile ->
                        ProfileCard(
                            profile = profile,
                            loading = state.loading,
                            onConnect = { viewModel.connectNetwork(profile) },
                            onEdit = { editingProfile = profile },
                            onDelete = { deleteProfile = profile },
                        )
                    }
                    state.error?.let { error -> item { NetworkError(error) } }
                }
                FloatingActionButton(onClick = { showAdd = true }, modifier = Modifier.padding(20.dp).align(Alignment.BottomEnd)) {
                    Icon(Icons.Rounded.Add, contentDescription = uiText("Pridėti jungtį"))
                }
            }
        } else {
            Box(modifier = Modifier.fillMaxSize()) {
                RemoteBrowser(
                    state = state,
                    localDirectory = activeLocalState.path,
                    onBack = viewModel::navigateRemoteBack,
                    onForward = viewModel::navigateRemoteForward,
                    onUp = viewModel::navigateRemoteUp,
                    onRefresh = { viewModel.refreshRemote() },
                    onOpen = viewModel::openRemoteEntry,
                    onDownload = viewModel::remoteDownload,
                    onToggleSelection = viewModel::toggleRemoteSelection,
                    onClearSelection = viewModel::clearRemoteSelection,
                    onSelectAll = viewModel::selectAllRemote,
                    onDownloadSelected = viewModel::remoteDownloadSelection,
                    onCopySelected = viewModel::copyRemoteSelection,
                    canAddToRemoteClipboard = shovelClipboard != null,
                    onAddToRemoteClipboard = viewModel::addRemoteSelectionToClipboard,
                    localClipboardCount = localClipboard?.takeIf { it.mode == ClipboardMode.COPY }?.paths?.size ?: 0,
                    onPasteLocalClipboard = { viewModel.pasteLocalClipboardToRemote() },
                    onChooseUpload = { showUploadPicker = true },
                    onCreateFolder = { createRemoteItem = true },
                    onRename = { renameRemote = it },
                    onInfo = { remoteInfo = it },
                    onDelete = { deleteRemote = it },
                    onToggleHidden = viewModel::toggleRemoteHidden,
                    onToggleGrid = viewModel::toggleRemoteGrid,
                    onDisplaySettings = { showDisplaySettings = true },
                    onSort = viewModel::setRemoteSort,
                    onDisconnect = viewModel::disconnectNetwork,
                    onOpenOperations = { viewModel.setSection(com.shovel.filemanager.ui.AppSection.TOOLS) },
                    onSelectPaths = viewModel::selectRemotePaths,
                    onSetSelection = viewModel::setRemoteSelection,
                )
            }
        }
    }

    if (showAdd || editingProfile != null) {
        NetworkProfileDialog(
            existingProfile = editingProfile,
            onDismiss = {
                showAdd = false
                editingProfile = null
            },
            onSave = { profile, password, privateKey ->
                viewModel.saveNetworkProfile(profile, password, privateKey)
                showAdd = false
                editingProfile = null
            },
        )
    }
    if (nextcloudLogin.open) {
        NextcloudLoginDialog(
            state = nextcloudLogin,
            onServerChange = viewModel::updateNextcloudServer,
            onStart = {
                viewModel.startNextcloudLogin { url ->
                    nextcloudBrowser.launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            },
            onDismiss = viewModel::cancelNextcloudSetup,
        )
    }
    deleteProfile?.let { profile ->
        AlertDialog(
            onDismissRequest = { deleteProfile = null },
            title = { LText("Pašalinti jungtį?") },
            text = { LText("Bus pašalintas „${profile.name}“ profilis ir jo užšifruotas prisijungimo įrašas.") },
            confirmButton = {
                Button(onClick = { viewModel.removeNetworkProfile(profile.id); deleteProfile = null }) { LText("Pašalinti") }
            },
            dismissButton = { TextButton(onClick = { deleteProfile = null }) { LText("Atšaukti") } },
        )
    }
    if (createRemoteItem) {
        CreateItemDialog(
            onDismiss = { createRemoteItem = false },
            onCreateFolder = { name -> viewModel.remoteCreateDirectory(name); createRemoteItem = false },
            onCreateFile = { name -> viewModel.remoteCreateFile(name); createRemoteItem = false },
        )
    }
    renameRemote?.let { entry ->
        RemoteNameDialog("Pervadinti", "Pervadinti", entry.name, { renameRemote = null }) {
            viewModel.remoteRename(entry, it)
            renameRemote = null
        }
    }
    remoteInfo?.let { entry ->
        RemoteInfoDialog(entry = entry, onDismiss = { remoteInfo = null })
    }
    deleteRemote?.let { entries ->
        val single = entries.singleOrNull()
        DeleteConfirmationDialog(
            names = entries.map(RemoteEntry::name), permanent = true,
            title = when {
                entries.size > 1 -> "Ištrinti pasirinktus elementus?"
                single?.directory == true -> "Ištrinti aplanką ir jo turinį?"
                else -> "Ištrinti failą?"
            },
            confirmLabel = "Ištrinti",
            onDismiss = { deleteRemote = null },
            onConfirm = { viewModel.remoteDelete(entries); deleteRemote = null },
            loadSummary = { viewModel.loadRemoteSelectionInfo(entries) },
            explanation = "Elementai bus ištrinti nuotoliniame serveryje be vietinės šiukšlinės.",
        )
    }
    if (showUploadPicker && state.connectedProfile != null) {
        LocalUploadDialog(
            initialDirectoryPath = activeLocalState.path,
            remotePath = state.path,
            initialEntries = activeLocalState.entries,
            initiallySelected = activeSelection,
            loadDirectory = viewModel::listLocalDirectoryForUpload,
            onDismiss = { showUploadPicker = false },
            onCopy = { paths ->
                if (viewModel.remoteUpload(paths)) {
                    viewModel.clearSelection(activePanel)
                    showUploadPicker = false
                }
            },
        )
    }
    if (showDisplaySettings && state.connectedProfile != null) {
        DirectoryDisplaySettingsDialog(
            initialSettings = state.toDirectoryDisplaySettings(),
            thumbnailsAvailable = false,
            initialSortMode = state.sortMode,
            initialSortDirection = state.sortDirection,
            onDismiss = { showDisplaySettings = false },
            onApply = { settings ->
                viewModel.setRemoteDirectoryDisplaySettings(settings)
                showDisplaySettings = false
            },
            onApplySort = viewModel::setRemoteSort,
            onApplyToAll = { settings, mode, direction ->
                viewModel.applyDirectoryDisplaySettingsToAll(settings, mode, direction)
                showDisplaySettings = false
            },
        )
    }
}

@Composable
private fun NextcloudLoginDialog(
    state: NextcloudLoginUiState,
    onServerChange: (String) -> Unit,
    onStart: () -> Unit,
    onDismiss: () -> Unit,
) {
    ShovelModalDialog(
        title = "Pridėti Nextcloud",
        icon = Icons.Rounded.Cloud,
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("nextcloud_login_dialog"),
        actions = {
            TextButton(onClick = onDismiss) { LText(if (state.running) "Atšaukti" else "Uždaryti") }
            Button(
                onClick = onStart,
                enabled = !state.running && state.server.isNotBlank(),
                modifier = Modifier.testTag("nextcloud_login_start"),
            ) {
                if (state.running) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                } else {
                    LText("Prisijungti naršyklėje")
                }
            }
        },
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            LText(
                "Įrašykite savo Nextcloud serverio adresą. Shovel atidarys numatytąją naršyklę ir gaus tik šiai programėlei skirtą atšaukiamą slaptažodį.",
                style = MaterialTheme.typography.bodyMedium,
            )
            OutlinedTextField(
                value = state.server,
                onValueChange = onServerChange,
                enabled = !state.running,
                singleLine = true,
                label = { LText("Nextcloud serveris") },
                placeholder = { LText("https://cloud.example.com") },
                modifier = Modifier.fillMaxWidth().testTag("nextcloud_server"),
                isError = state.error != null,
            )
            if (state.server.trim().startsWith("http://", ignoreCase = true)) {
                LText(
                    "HTTP ryšys nešifruotas. Naudokite jį tik patikimame vietiniame tinkle.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            when (state.phase) {
                NextcloudLoginPhase.IDLE -> Unit
                NextcloudLoginPhase.STARTING -> LText("Ruošiamas saugus Nextcloud prisijungimas")
                NextcloudLoginPhase.WAITING_FOR_BROWSER -> LText("Užbaikite prisijungimą naršyklėje. Shovel laukia patvirtinimo.")
                NextcloudLoginPhase.SAVING -> LText("Saugomas Nextcloud ryšys")
            }
            state.error?.let {
                LText(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.testTag("nextcloud_login_error"))
            }
        }
    }
}

@Composable
internal fun ProfileCard(
    profile: NetworkProfile,
    loading: Boolean,
    onConnect: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val normalized = NetworkProfileRules.normalize(profile)
    val profileProblem = runCatching { NetworkProfileRules.validate(normalized) }.exceptionOrNull()?.message
    val safeName = if (NetworkProfileRules.nameError(profile.name) == null) normalized.name else "Jungtis"
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (profile.provider == NetworkProvider.NEXTCLOUD) Icons.Rounded.Cloud else Icons.Rounded.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(34.dp),
            )
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(safeName, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (profileProblem == null) {
                    Text(
                        "${if (profile.provider == NetworkProvider.NEXTCLOUD) "Nextcloud" else profile.protocol.name} · ${normalized.host}:${profile.port}",
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                } else {
                    LText("${profile.protocol} · Neteisingi jungties duomenys", style = MaterialTheme.typography.bodySmall)
                }
                if (profileProblem != null) {
                    LText(
                        "$profileProblem. Paspauskite pieštuką.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (profile.protocol == NetworkProtocol.SFTP) {
                    LText(
                        profile.expectedHostKeySha256?.let { "SSH ${it.take(22)}…" } ?: "Pirmasis raktas bus aiškiai patikėtas",
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }
        }
        FlowRow(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End,
            itemVerticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onEdit, modifier = Modifier.testTag("profile_edit_${profile.id}")) { Icon(Icons.Rounded.Edit, contentDescription = uiText("Redaguoti jungtį")) }
            IconButton(onClick = onDelete, modifier = Modifier.testTag("profile_remove_${profile.id}")) { Icon(Icons.Rounded.Delete, contentDescription = uiText("Pašalinti")) }
            Button(onClick = onConnect, enabled = !loading, modifier = Modifier.testTag("profile_connect_${profile.id}")) {
                if (loading) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp) else LText("Jungtis")
            }
        }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun RemoteBrowser(
    state: com.shovel.filemanager.ui.NetworkUiState,
    localDirectory: String,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onUp: () -> Unit,
    onRefresh: () -> Unit,
    onOpen: (RemoteEntry) -> Unit,
    onDownload: (RemoteEntry) -> Unit,
    onToggleSelection: (String) -> Unit,
    onClearSelection: () -> Unit,
    onSelectAll: () -> Unit,
    onDownloadSelected: () -> Unit,
    onCopySelected: () -> Unit,
    canAddToRemoteClipboard: Boolean = false,
    onAddToRemoteClipboard: () -> Unit = {},
    localClipboardCount: Int,
    onPasteLocalClipboard: () -> Unit,
    onChooseUpload: () -> Unit,
    onCreateFolder: () -> Unit,
    onRename: (RemoteEntry) -> Unit,
    onDelete: (List<RemoteEntry>) -> Unit,
    onToggleHidden: () -> Unit,
    onToggleGrid: () -> Unit,
    onDisplaySettings: () -> Unit = {},
    onSort: (SortMode) -> Unit,
    onDisconnect: () -> Unit,
    onOpenOperations: () -> Unit = {},
    onInfo: (RemoteEntry) -> Unit = {},
    onSelectPaths: (List<String>) -> Unit = { onSelectAll() },
    onSetSelection: (List<String>, Boolean) -> Unit = { _, _ -> },
) {
    var searchVisible by remember(state.connectedProfile?.id) { mutableStateOf(false) }
    var searchQuery by remember(state.connectedProfile?.id) { mutableStateOf("") }
    var entryFilters by remember(state.connectedProfile?.id, state.path) { mutableStateOf<Set<DirectoryEntryFilter>>(emptySet()) }
    var showEntryFilter by remember(state.connectedProfile?.id, state.path) { mutableStateOf(false) }
    LaunchedEffect(state.path) {
        searchVisible = false
        searchQuery = ""
    }
    val orderedEntries = remember(state.entries, state.includeHidden, state.sortMode, state.sortDirection) {
        RemoteBrowserRules.displayEntries(
            entries = state.entries,
            includeHidden = state.includeHidden,
            sortMode = state.sortMode,
            sortDirection = state.sortDirection,
        )
    }
    val displayedEntries = remember(orderedEntries, searchQuery, entryFilters) {
        val query = searchQuery.trim()
        orderedEntries.filter { entry ->
            (query.isEmpty() || entry.name.contains(query, ignoreCase = true)) &&
                DirectoryEntryFilterRules.matches(
                    FileSystemRules.detectKind(entry.name, mimeType = null, isDirectory = entry.directory),
                    entryFilters,
                )
        }
    }
    val selectableEntries = remember(displayedEntries) {
        displayedEntries.take(RemoteCopyEngine.MAX_SELECTED_ROOTS)
    }
    val allSelected = remember(selectableEntries, state.selectedPaths) {
        state.selectedPaths.isNotEmpty() && selectableEntries.all { it.path in state.selectedPaths }
    }
    val selectedEntries = remember(displayedEntries, state.selectedPaths) {
        if (state.selectedPaths.isEmpty()) emptyList()
        else displayedEntries.filter { it.path in state.selectedPaths }
    }
    Column(modifier = Modifier.fillMaxSize()) {
        if (state.selectedPaths.isNotEmpty()) {
            SelectionHeader(
                count = state.selectedPaths.size,
                allSelected = allSelected,
                onClose = onClearSelection,
                onToggleSelectAll = {
                    if (allSelected) onClearSelection() else onSelectPaths(selectableEntries.map(RemoteEntry::path))
                },
            )
        } else {
            RemoteFolderToolbar(
                state = state,
                localDirectory = localDirectory,
                localClipboardCount = localClipboardCount,
                onBack = onBack,
                onForward = onForward,
                onUp = onUp,
                onRefresh = onRefresh,
                onPasteLocalClipboard = onPasteLocalClipboard,
                onChooseUpload = onChooseUpload,
                onToggleHidden = onToggleHidden,
                onToggleGrid = onToggleGrid,
                onDisplaySettings = onDisplaySettings,
                onSort = onSort,
                onDisconnect = onDisconnect,
                onOpenOperations = onOpenOperations,
                searchActive = searchVisible,
                onToggleSearch = {
                    searchVisible = !searchVisible
                    if (!searchVisible) searchQuery = ""
                },
                filterActive = entryFilters.isNotEmpty(),
                onOpenFilter = { showEntryFilter = true },
            )
        }
        if (searchVisible) {
            DirectoryQuickSearchField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                onClose = { searchVisible = false; searchQuery = "" },
                filterActive = entryFilters.isNotEmpty(),
                onOpenFilter = { showEntryFilter = true },
                modifier = Modifier.testTag("directory_search_field_remote"),
            )
        }
        RemoteBreadcrumbs(state.path) { onPath ->
            if (onPath != state.path) {
                val entry = RemoteEntry(onPath.substringAfterLast('/').ifBlank { "/" }, onPath, true, 0, null)
                onOpen(entry)
            }
        }
        if (state.loading) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
        state.error?.let { NetworkError(it) }
        ShovelPullToRefresh(
            isRefreshing = state.loading,
            onRefresh = onRefresh,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            testTag = "pull_to_refresh_remote",
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                when {
                    state.error != null && displayedEntries.isEmpty() -> Unit
                    state.loading && orderedEntries.isEmpty() -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                    orderedEntries.isEmpty() -> RemoteEmptyPanel()
                    displayedEntries.isEmpty() -> RemoteEmptyPanel("Atitikmenų nerasta", "Pabandykite kitą pavadinimą")
                    state.grid -> RemoteEntryGrid(
                    entries = displayedEntries,
                    loading = state.loading,
                    selectedPaths = state.selectedPaths,
                    selectionActive = state.selectedPaths.isNotEmpty(),
                    openingPath = state.openingPath,
                    iconScalePercent = state.iconScalePercent,
                    spacingScalePercent = state.spacingScalePercent,
                    gridColumns = state.gridColumns,
                    gridStyle = state.gridStyle,
                    onOpen = onOpen,
                    onDownload = onDownload,
                    onToggleSelection = onToggleSelection,
                    onSetSelection = onSetSelection,
                    onRename = onRename,
                    onInfo = onInfo,
                    onDelete = { onDelete(listOf(it)) },
                )
                    else -> RemoteEntryList(
                    entries = displayedEntries,
                    loading = state.loading,
                    selectedPaths = state.selectedPaths,
                    selectionActive = state.selectedPaths.isNotEmpty(),
                    openingPath = state.openingPath,
                    iconScalePercent = state.iconScalePercent,
                    spacingScalePercent = state.spacingScalePercent,
                    onOpen = onOpen,
                    onDownload = onDownload,
                    onToggleSelection = onToggleSelection,
                    onSetSelection = onSetSelection,
                    onRename = onRename,
                    onInfo = onInfo,
                    onDelete = { onDelete(listOf(it)) },
                )
                }
                if (state.selectedPaths.isNotEmpty()) {
                    SelectionActionDock(modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp)) {
                    IconButton(onClick = onCopySelected, enabled = !state.loading) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = uiText("Kopijuoti"))
                    }
                    IconButton(onClick = onDownloadSelected, enabled = !state.loading) {
                        Icon(Icons.Rounded.CloudDownload, contentDescription = uiText("Kopijuoti į aktyvų vietinį aplanką"))
                    }
                    IconButton(
                        onClick = { selectedEntries.singleOrNull()?.let(onRename) },
                        enabled = !state.loading && selectedEntries.size == 1,
                    ) {
                        Icon(Icons.Rounded.Edit, contentDescription = uiText("Pervadinti"))
                    }
                    IconButton(
                        onClick = { onDelete(selectedEntries) },
                        enabled = !state.loading && selectedEntries.isNotEmpty(),
                    ) {
                        Icon(Icons.Rounded.Delete, contentDescription = uiText("Ištrinti"), tint = MaterialTheme.colorScheme.error)
                    }
                    }
                } else {
                    FloatingActionButton(
                        onClick = onCreateFolder,
                        modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp).testTag("remote_create_item"),
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = uiText("Sukurti"))
                    }
                }
            }
        }
    }
    if (showEntryFilter) {
        DirectoryEntryFilterDialog(
            selected = entryFilters,
            onSelectedChange = { entryFilters = it },
            onDismiss = { showEntryFilter = false },
        )
    }
}

@Composable
private fun RemoteFolderToolbar(
    state: com.shovel.filemanager.ui.NetworkUiState,
    localDirectory: String,
    localClipboardCount: Int,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onUp: () -> Unit,
    onRefresh: () -> Unit,
    onPasteLocalClipboard: () -> Unit,
    onChooseUpload: () -> Unit,
    onToggleHidden: () -> Unit,
    onToggleGrid: () -> Unit,
    onDisplaySettings: () -> Unit,
    onSort: (SortMode) -> Unit,
    onDisconnect: () -> Unit,
    onOpenOperations: () -> Unit,
    searchActive: Boolean,
    onToggleSearch: () -> Unit,
    filterActive: Boolean,
    onOpenFilter: () -> Unit,
) {
    DirectoryBrowserToolbar(
        title = state.path.substringAfterLast('/').ifBlank { state.connectedProfile?.name.orEmpty() },
        path = state.path,
        backEnabled = state.backHistory.isNotEmpty(),
        forwardEnabled = state.forwardHistory.isNotEmpty(),
        upEnabled = state.path != "/",
        searchActive = searchActive,
        grid = state.grid,
        testTagPrefix = "remote",
        onBack = onBack,
        onForward = onForward,
        onUp = onUp,
        onToggleSearch = onToggleSearch,
        onToggleLayout = onToggleGrid,
        onOpenSettings = onDisplaySettings,
    ) {
        RemoteFolderActionsMenu(
            state = state,
            localDirectory = localDirectory,
            localClipboardCount = localClipboardCount,
            onPasteLocalClipboard = onPasteLocalClipboard,
            onChooseUpload = onChooseUpload,
            onToggleHidden = onToggleHidden,
            onToggleGrid = onToggleGrid,
            onDisplaySettings = onDisplaySettings,
            onSort = onSort,
            onRefresh = onRefresh,
            onDisconnect = onDisconnect,
            onOpenOperations = onOpenOperations,
            filterActive = filterActive,
            onOpenFilter = onOpenFilter,
        )
    }
}

@Composable
private fun RemoteFolderActionsMenu(
    state: com.shovel.filemanager.ui.NetworkUiState,
    localDirectory: String,
    localClipboardCount: Int,
    onPasteLocalClipboard: () -> Unit,
    onChooseUpload: () -> Unit,
    onToggleHidden: () -> Unit,
    onToggleGrid: () -> Unit,
    onDisplaySettings: () -> Unit,
    onSort: (SortMode) -> Unit,
    onRefresh: () -> Unit,
    onDisconnect: () -> Unit,
    onOpenOperations: () -> Unit,
    filterActive: Boolean,
    onOpenFilter: () -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        IconButton(onClick = { expanded = true }) {
            Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Aplanko veiksmai"))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            if (localClipboardCount > 0) {
                DropdownMenuItem(
                    text = { LText("Įklijuoti ($localClipboardCount)") },
                    leadingIcon = { Icon(Icons.Rounded.ContentPaste, contentDescription = null) },
                    enabled = !state.loading,
                    modifier = Modifier.testTag("remote_paste_local"),
                    onClick = { expanded = false; onPasteLocalClipboard() },
                )
            }
            DropdownMenuItem(
                text = { LText("Pasirinkti iš telefono") },
                leadingIcon = { Icon(Icons.Rounded.CloudUpload, contentDescription = null) },
                enabled = !state.loading,
                modifier = Modifier.testTag("remote_upload_choose"),
                onClick = { expanded = false; onChooseUpload() },
            )
            DropdownMenuItem(
                text = { LText("Operacijų centras") },
                leadingIcon = { Icon(Icons.Rounded.SwapHoriz, contentDescription = null) },
                modifier = Modifier.testTag("remote_open_operations"),
                onClick = { expanded = false; onOpenOperations() },
            )
            HorizontalDivider()
            DirectoryDisplayMenuItems(
                grid = state.grid,
                includeHidden = state.includeHidden,
                showThumbnails = false,
                thumbnailsAvailable = false,
                sortMode = state.sortMode,
                sortDirection = state.sortDirection,
                displaySettingsTestTag = "remote_display_settings",
                onToggleHidden = onToggleHidden,
                onToggleLayout = onToggleGrid,
                onToggleThumbnails = {},
                onOpenSettings = onDisplaySettings,
                onSort = onSort,
                onDismissMenu = { expanded = false },
                filterActive = filterActive,
                onOpenFilter = onOpenFilter,
            )
            HorizontalDivider()
            DropdownMenuItem(
                text = { LText("Atnaujinti") },
                leadingIcon = { Icon(Icons.Rounded.Refresh, contentDescription = null) },
                onClick = { expanded = false; onRefresh() },
            )
            DropdownMenuItem(
                text = { LText("Iš serverio → $localDirectory") },
                enabled = false,
                onClick = {},
            )
            DropdownMenuItem(
                text = { LText("Atjungti") },
                leadingIcon = { Icon(Icons.Rounded.CloudOff, contentDescription = null) },
                onClick = { expanded = false; onDisconnect() },
            )
        }
    }
}

@Composable
private fun RemoteBreadcrumbs(path: String, onNavigate: (String) -> Unit) {
    val paths = remember(path) {
        buildList {
            add("/")
            var current = ""
            path.split('/').filter(String::isNotBlank).forEach { part ->
                current += "/$part"
                add(current)
            }
        }
    }
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 3.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        paths.forEach { itemPath ->
            AssistChip(
                onClick = { onNavigate(itemPath) },
                label = { Text(itemPath.substringAfterLast('/').ifBlank { "/" }, maxLines = 1) },
            )
        }
    }
}

@Composable
private fun RemoteEntryList(
    entries: List<RemoteEntry>,
    loading: Boolean,
    selectedPaths: Set<String>,
    selectionActive: Boolean,
    openingPath: String?,
    iconScalePercent: Int,
    spacingScalePercent: Int,
    onOpen: (RemoteEntry) -> Unit,
    onDownload: (RemoteEntry) -> Unit,
    onToggleSelection: (String) -> Unit,
    onSetSelection: (List<String>, Boolean) -> Unit,
    onRename: (RemoteEntry) -> Unit,
    onInfo: (RemoteEntry) -> Unit,
    onDelete: (RemoteEntry) -> Unit,
) {
    val dateFormat = rememberLocalizedDateTimeFormat(DateFormat.SHORT, DateFormat.SHORT)
    val listState = rememberLazyListState()
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .longPressDragSelect(
                    state = listState,
                    itemCount = entries.size,
                    isSelected = { index -> entries.getOrNull(index)?.path in selectedPaths },
                    onSelectionChange = { indices, selected ->
                        onSetSelection(indices.mapNotNull { index -> entries.getOrNull(index)?.path }, selected)
                    },
                )
                .testTag("remote_list"),
            contentPadding = PaddingValues(bottom = 88.dp),
        ) {
            items(entries, key = RemoteEntry::path) { entry ->
                RemoteEntryRow(
                    entry = entry,
                    metadata = remoteEntryMeta(entry, dateFormat),
                    selected = entry.path in selectedPaths,
                    selectionActive = selectionActive,
                    opening = entry.path == openingPath,
                    iconScalePercent = iconScalePercent,
                    spacingScalePercent = spacingScalePercent,
                    onOpen = { onOpen(entry) },
                    onDownload = { onDownload(entry) },
                    onToggleSelection = { onToggleSelection(entry.path) },
                    onRename = { onRename(entry) },
                    onInfo = { onInfo(entry) },
                    onDelete = { onDelete(entry) },
                )
            }
        }
        if (!loading) Spacer(Modifier.size(1.dp).testTag("remote_list_ready"))
        LazyListFastScroller(listState)
    }
}

@Composable
private fun RemoteEntryGrid(
    entries: List<RemoteEntry>,
    loading: Boolean,
    selectedPaths: Set<String>,
    selectionActive: Boolean,
    openingPath: String?,
    iconScalePercent: Int,
    spacingScalePercent: Int,
    gridColumns: Int,
    gridStyle: DirectoryGridStyle,
    onOpen: (RemoteEntry) -> Unit,
    onDownload: (RemoteEntry) -> Unit,
    onToggleSelection: (String) -> Unit,
    onSetSelection: (List<String>, Boolean) -> Unit,
    onRename: (RemoteEntry) -> Unit,
    onInfo: (RemoteEntry) -> Unit,
    onDelete: (RemoteEntry) -> Unit,
) {
    val gridState = rememberLazyGridState()
    Box(modifier = Modifier.fillMaxSize()) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(gridColumns.coerceIn(1, 6)),
            state = gridState,
            modifier = Modifier
                .fillMaxSize()
                .longPressDragSelect(
                    state = gridState,
                    itemCount = entries.size,
                    isSelected = { index -> entries.getOrNull(index)?.path in selectedPaths },
                    onSelectionChange = { indices, selected ->
                        onSetSelection(indices.mapNotNull { index -> entries.getOrNull(index)?.path }, selected)
                    },
                )
                .testTag("remote_grid"),
            contentPadding = PaddingValues(8.dp, 6.dp, 8.dp, 88.dp),
            horizontalArrangement = Arrangement.spacedBy((5f * spacingScalePercent / 100f).dp),
            verticalArrangement = Arrangement.spacedBy((5f * spacingScalePercent / 100f).dp),
        ) {
            items(entries, key = RemoteEntry::path) { entry ->
                RemoteEntryTile(
                    entry = entry,
                    selected = entry.path in selectedPaths,
                    selectionActive = selectionActive,
                    opening = entry.path == openingPath,
                    iconScalePercent = iconScalePercent,
                    spacingScalePercent = spacingScalePercent,
                    gridStyle = gridStyle,
                    onOpen = { onOpen(entry) },
                    onDownload = { onDownload(entry) },
                    onToggleSelection = { onToggleSelection(entry.path) },
                    onRename = { onRename(entry) },
                    onInfo = { onInfo(entry) },
                    onDelete = { onDelete(entry) },
                )
            }
        }
        if (!loading) Spacer(Modifier.size(1.dp).testTag("remote_grid_ready"))
        LazyGridFastScroller(gridState)
    }
}

@Composable
private fun RemoteEntryRow(
    entry: RemoteEntry,
    metadata: String,
    selected: Boolean,
    selectionActive: Boolean,
    opening: Boolean,
    iconScalePercent: Int,
    spacingScalePercent: Int,
    onOpen: () -> Unit,
    onDownload: () -> Unit,
    onToggleSelection: () -> Unit,
    onRename: () -> Unit,
    onInfo: () -> Unit,
    onDelete: () -> Unit,
) {
    val selectionShape = RoundedCornerShape(8.dp)
    val iconSize = (42f * iconScalePercent / 100f).dp
    val itemSpacing = (12f * spacingScalePercent / 100f).dp
    val verticalPadding = (9f * spacingScalePercent / 100f).dp
    com.shovel.filemanager.ui.theme.AppearanceContentOn(if (selected) MaterialTheme.colorScheme.primaryContainer else androidx.compose.ui.graphics.Color.Transparent) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("remote_entry_${entry.path}")
            .then(
                if (selected) {
                    Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer, selectionShape)
                        .border(1.5.dp, MaterialTheme.colorScheme.primary, selectionShape)
                } else {
                    Modifier
                },
            )
            .semantics { onLongClick { onToggleSelection(); true } }
            .clickable(
                enabled = !opening,
                onClick = { if (selectionActive) onToggleSelection() else onOpen() },
            )
            .padding(horizontal = 12.dp, vertical = verticalPadding),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(itemSpacing),
    ) {
        if (opening) {
            CircularProgressIndicator(
                modifier = Modifier.size(iconSize.coerceAtMost(40.dp)).testTag("remote_opening_${entry.path}"),
                strokeWidth = 3.dp,
            )
        } else {
            RemoteFileVisual(entry = entry, modifier = Modifier.size(iconSize))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(entry.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = if (entry.directory) FontWeight.SemiBold else FontWeight.Normal)
            LText(metadata, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        RemoteEntryActionsButton(entry, onOpen, onDownload, onToggleSelection, onRename, onInfo, onDelete)
    }
    }
    HorizontalDivider(
        modifier = Modifier.padding(start = iconSize + itemSpacing + 12.dp),
        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
    )
}

@Composable
private fun RemoteEntryTile(
    entry: RemoteEntry,
    selected: Boolean,
    selectionActive: Boolean,
    opening: Boolean,
    iconScalePercent: Int,
    spacingScalePercent: Int,
    gridStyle: DirectoryGridStyle,
    onOpen: () -> Unit,
    onDownload: () -> Unit,
    onToggleSelection: () -> Unit,
    onRename: () -> Unit,
    onInfo: () -> Unit,
    onDelete: () -> Unit,
) {
    val selectionShape = RoundedCornerShape(12.dp)
    val visualHeight = (76f * iconScalePercent / 100f).dp
    val innerPadding = (9f * spacingScalePercent / 100f).dp
    Card(
        modifier = Modifier
            .testTag("remote_entry_${entry.path}")
            .then(if (selected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, selectionShape) else Modifier)
            .semantics { onLongClick { onToggleSelection(); true } }
            .clickable(
                enabled = !opening,
                onClick = { if (selectionActive) onToggleSelection() else onOpen() },
            ),
        shape = if (gridStyle == DirectoryGridStyle.CLASSIC) RoundedCornerShape(4.dp) else selectionShape,
        colors = CardDefaults.cardColors(
            containerColor = when {
                selected -> MaterialTheme.colorScheme.primaryContainer
                gridStyle == DirectoryGridStyle.CLASSIC -> MaterialTheme.colorScheme.surface.copy(alpha = 0f)
                else -> MaterialTheme.colorScheme.surfaceContainer
            },
        ),
    ) {
        DirectoryGridItemContent(
            title = entry.name,
            metadata = if (entry.directory) null else FileSystemRules.humanBytes(entry.sizeBytes),
            visualHeight = visualHeight,
            innerPadding = innerPadding,
            visual = {
                if (opening) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(visualHeight.coerceAtMost(58.dp)).testTag("remote_opening_${entry.path}"),
                        strokeWidth = 4.dp,
                    )
                } else {
                    RemoteFileVisual(entry = entry, modifier = Modifier.fillMaxSize())
                }
            },
            actions = {
                RemoteEntryActionsButton(entry, onOpen, onDownload, onToggleSelection, onRename, onInfo, onDelete)
            },
        )
    }
}

@Composable
private fun RemoteEntryActionsButton(
    entry: RemoteEntry,
    onOpen: () -> Unit,
    onDownload: () -> Unit,
    onToggleSelection: () -> Unit,
    onRename: () -> Unit,
    onInfo: () -> Unit,
    onDelete: () -> Unit,
) {
    var expanded by remember(entry.path) { mutableStateOf(false) }
    Box {
        IconButton(onClick = { expanded = true }) {
            Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Failo veiksmai: ${entry.name}"))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(
                text = { LText(if (entry.directory) "Atidaryti aplanką" else "Peržiūrėti čia") },
                leadingIcon = { Icon(if (entry.directory) Icons.Rounded.Folder else Icons.Rounded.Visibility, contentDescription = null) },
                onClick = { expanded = false; onOpen() },
            )
            if (!entry.directory) {
                DropdownMenuItem(
                    text = { LText("Kopijuoti į telefoną") },
                    leadingIcon = { Icon(Icons.Rounded.CloudDownload, contentDescription = null) },
                    onClick = { expanded = false; onDownload() },
                )
            }
            DropdownMenuItem(
                text = { LText("Pasirinkti") },
                leadingIcon = { Icon(Icons.Rounded.CheckCircle, contentDescription = null) },
                onClick = { expanded = false; onToggleSelection() },
            )
            HorizontalDivider()
            DropdownMenuItem(
                text = { LText("Pervadinti") },
                leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
                onClick = { expanded = false; onRename() },
            )
            DropdownMenuItem(
                text = { LText("Informacija") },
                leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
                onClick = { expanded = false; onInfo() },
            )
            DropdownMenuItem(
                text = { LText("Ištrinti") },
                leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                onClick = { expanded = false; onDelete() },
            )
        }
    }
}

@Composable
private fun RemoteEmptyPanel(
    title: String = "Aplankas tuščias",
    description: String = "Čia dar nėra failų",
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Rounded.Folder, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.height(10.dp))
        LText(title, style = MaterialTheme.typography.titleMedium)
        LText(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun RemoteInfoDialog(entry: RemoteEntry, onDismiss: () -> Unit) {
    val dateFormat = rememberLocalizedDateTimeFormat(DateFormat.MEDIUM, DateFormat.SHORT)
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Info, contentDescription = null) },
        title = { Text(entry.name, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RemoteInfoLine("Tipas", if (entry.directory) uiText("Aplankas") else entry.name.substringAfterLast('.', "").uppercase().ifBlank { uiText("Failas") })
                if (!entry.directory) RemoteInfoLine("Dydis", FileSystemRules.humanBytes(entry.sizeBytes))
                entry.modifiedAtMillis?.takeIf { it > 0L }?.let { RemoteInfoLine("Pakeista", dateFormat.format(Date(it))) }
                LText("Kelias", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                Text(entry.path, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { LText("Uždaryti") } },
    )
}

@Composable
private fun RemoteInfoLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        LText(label, modifier = Modifier.size(width = 88.dp, height = 24.dp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
        Text(value, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
    }
}

private fun remoteEntryMeta(entry: RemoteEntry, dateFormat: DateFormat): String {
    val date = entry.modifiedAtMillis?.takeIf { it > 0 }?.let { dateFormat.format(Date(it)) }
    return listOfNotNull(if (entry.directory) "Aplankas" else FileSystemRules.humanBytes(entry.sizeBytes), date).joinToString(" · ")
}

private fun com.shovel.filemanager.ui.NetworkUiState.toDirectoryDisplaySettings(): DirectoryDisplaySettings =
    DirectoryDisplaySettings(
        layoutMode = if (grid) DirectoryLayoutMode.GRID else DirectoryLayoutMode.LIST,
        iconScalePercent = iconScalePercent,
        spacingScalePercent = spacingScalePercent,
        gridColumns = gridColumns,
        gridStyle = gridStyle,
        showThumbnails = false,
    )

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun LocalUploadDialog(
    initialDirectoryPath: String,
    remotePath: String,
    initialEntries: List<FileEntry>,
    initiallySelected: Set<String>,
    loadDirectory: suspend (String) -> Result<List<FileEntry>>,
    onDismiss: () -> Unit,
    onCopy: (List<String>) -> Unit,
    title: String = "Kopijuoti į serverį",
    confirmLabel: String = "Kopijuoti",
    filesOnly: Boolean = false,
    allowMultiple: Boolean = true,
    selectionLimit: Int = RemoteCopyEngine.MAX_SELECTED_ROOTS,
    parentDirectory: (String) -> String? = { File(it).parentFile?.absolutePath },
    message: String? = null,
    confirming: Boolean = false,
) {
    val maxSelection = if (allowMultiple) selectionLimit.coerceIn(1, RemoteCopyEngine.MAX_SELECTED_ROOTS) else 1
    var navigation by remember(initialDirectoryPath, remotePath) {
        mutableStateOf(LocalUploadNavigationState(initialDirectoryPath))
    }
    val currentPath = navigation.currentPath
    var entries by remember(initialDirectoryPath, remotePath) { mutableStateOf(initialEntries) }
    var searchQuery by remember(currentPath) { mutableStateOf("") }
    var searchVisible by remember { mutableStateOf(false) }
    var pickerMenu by remember { mutableStateOf(false) }
    var showOnlyFolders by remember { mutableStateOf(false) }
    var showOnlyFiles by remember { mutableStateOf(false) }
    var pickerSort by remember { mutableStateOf(SortMode.NAME) }
    var displayedEntries by remember(currentPath) { mutableStateOf(initialEntries) }
    LaunchedEffect(currentPath, entries, searchQuery, showOnlyFolders, showOnlyFiles, pickerSort) {
        val source = entries
        val query = searchQuery.trim().take(200)
        displayedEntries = withContext(Dispatchers.Default) {
            FileEntryOrdering.order(source.filter {
                ensureActive()
                (query.isBlank() || it.name.contains(query, ignoreCase = true)) &&
                    (!showOnlyFolders || it.isDirectory) && (!showOnlyFiles || !it.isDirectory)
            }, pickerSort, SortDirection.ASCENDING)
        }
    }
    var loading by remember(initialDirectoryPath, remotePath) { mutableStateOf(false) }
    var error by remember(initialDirectoryPath, remotePath) { mutableStateOf<String?>(null) }
    var refreshToken by remember(initialDirectoryPath, remotePath) { mutableStateOf(0) }
    var selected: Set<String> by remember(initialDirectoryPath, remotePath) {
        mutableStateOf(initiallySelected.take(maxSelection).toCollection(linkedSetOf()))
    }

    LaunchedEffect(currentPath, refreshToken) {
        loading = true
        error = null
        if (currentPath != initialDirectoryPath) entries = emptyList()
        loadDirectory(currentPath).fold(
            onSuccess = { loaded -> entries = loaded },
            onFailure = { failure ->
                entries = emptyList()
                error = failure.message ?: "Katalogo atverti nepavyko"
            },
        )
        loading = false
    }

    fun toggle(path: String) {
        selected = if (path in selected) {
            selected - path
        } else if (!allowMultiple) {
            setOf(path)
        } else if (selected.size < maxSelection) {
            selected + path
        } else {
            selected
        }
    }

    fun navigateTo(path: String) {
        navigation = navigation.navigateTo(path)
    }

    fun navigateBack() {
        navigation = navigation.navigateBack()
    }

    val parentPath = parentDirectory(currentPath)
    val visiblePaths = remember(displayedEntries, filesOnly, maxSelection) {
        displayedEntries.asSequence().filter { !filesOnly || !it.isDirectory }
            .take(maxSelection).map(FileEntry::absolutePath).toList()
    }
    val allSelected = visiblePaths.isNotEmpty() && visiblePaths.all(selected::contains)

    com.shovel.filemanager.ui.components.ShovelModalDialog(
        onDismissRequest = { if (navigation.canNavigateBack) navigateBack() else onDismiss() },
        onClose = onDismiss,
        icon = if (filesOnly) Icons.Rounded.FolderOpen else Icons.Rounded.CloudUpload,
        title = title,
        expandedContent = true,
        modifier = Modifier.testTag("local_upload_dialog"),
        actions = {
            TextButton(onClick = onDismiss) { LText("Atšaukti") }
            Button(
                onClick = { onCopy(selected.toList()) },
                enabled = selected.isNotEmpty() && !confirming,
            ) { Text("${uiText(confirmLabel)} (${selected.size})") }
        },
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (featureVisible(OptionalFeature.TOOLBAR_UP)) IconButton(
                    onClick = { parentPath?.let(::navigateTo) },
                    enabled = parentPath != null && !loading,
                    modifier = Modifier.testTag("local_upload_up"),
                ) { Icon(Icons.Rounded.ArrowUpward, contentDescription = uiText("Aukštyn")) }
                Text(currentPath.ifEmpty { uiText("Saugykla") }, modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (searchVisible || featureVisible(OptionalFeature.TOOLBAR_SEARCH)) IconButton(onClick = { searchVisible = !searchVisible; if (!searchVisible) searchQuery = "" },
                    modifier = Modifier.testTag("local_upload_search_toggle")) {
                    Icon(Icons.Rounded.Search, contentDescription = uiText(if (searchVisible) "Slėpti paiešką" else "Ieškoti"))
                }
                Box {
                    IconButton(onClick = { pickerMenu = true }, modifier = Modifier.testTag("local_upload_more")) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Daugiau veiksmų"))
                    }
                    DropdownMenu(expanded = pickerMenu, onDismissRequest = { pickerMenu = false }) {
                        DropdownMenuItem(text = { LText("Visi elementai") }, onClick = {
                            showOnlyFolders = false; showOnlyFiles = false; pickerMenu = false
                        }, leadingIcon = if (!showOnlyFolders && !showOnlyFiles) ({ Icon(Icons.Rounded.CheckCircle, contentDescription = null) }) else null)
                        DropdownMenuItem(text = { LText("Tik aplankai") }, onClick = {
                            showOnlyFolders = true; showOnlyFiles = false; pickerMenu = false
                        }, leadingIcon = if (showOnlyFolders) ({ Icon(Icons.Rounded.CheckCircle, contentDescription = null) }) else null)
                        DropdownMenuItem(text = { LText("Tik failai") }, onClick = {
                            showOnlyFiles = true; showOnlyFolders = false; pickerMenu = false
                        }, leadingIcon = if (showOnlyFiles) ({ Icon(Icons.Rounded.CheckCircle, contentDescription = null) }) else null)
                        HorizontalDivider()
                        SortMode.entries.forEach { mode ->
                            DropdownMenuItem(text = { LText(when (mode) {
                                SortMode.NAME -> "Pavadinimas"; SortMode.SIZE -> "Dydis";
                                SortMode.MODIFIED -> "Pakeista"; SortMode.TYPE -> "Tipas"
                            }) }, onClick = { pickerSort = mode; pickerMenu = false },
                                leadingIcon = if (pickerSort == mode) ({ Icon(Icons.Rounded.CheckCircle, contentDescription = null) }) else null)
                        }
                    }
                }
            }
            if (remotePath.isNotBlank()) LText("Į: $remotePath", style = MaterialTheme.typography.bodySmall)
            if (searchVisible) OutlinedTextField(
                value = searchQuery, onValueChange = { searchQuery = it.take(200) },
                label = { LText("Ieškoti šiame sąraše") }, singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("local_upload_search"),
            )
            if (selected.isNotEmpty()) SelectionActionBar(
                count = selected.size,
                allSelected = allSelected,
                onClose = { selected = emptySet() },
                onToggleSelectAll = {
                    selected = if (allSelected) selected - visiblePaths.toSet() else {
                        val available = maxSelection - selected.size
                        if (!allowMultiple) visiblePaths.take(1).toSet()
                        else selected + visiblePaths.filterNot(selected::contains).take(available)
                    }
                },
                modifier = Modifier.testTag("local_upload_selection_bar"),
            )
            message?.let { LText(it, color = MaterialTheme.colorScheme.error) }
            ShovelPullToRefresh(
                isRefreshing = loading,
                onRefresh = { refreshToken += 1 },
                modifier = Modifier.fillMaxWidth().weight(1f),
                testTag = "pull_to_refresh_local_upload",
            ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().testTag("local_upload_list"),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                if (loading) {
                    item {
                        Row(modifier = Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.Center) {
                            CircularProgressIndicator()
                        }
                    }
                } else if (error != null) {
                    item {
                        LText(
                            error.orEmpty(),
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                } else if (displayedEntries.isEmpty()) {
                    item { LText(if (searchQuery.isBlank()) "Katalogas tuščias" else "Atitinkančių failų nėra") }
                }
                items(displayedEntries, key = FileEntry::absolutePath) { entry ->
                    val entrySelected = entry.absolutePath in selected
                    val selectionShape = MaterialTheme.shapes.medium
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("local_upload_entry_${entry.absolutePath}")
                            .border(if (entrySelected) 1.5.dp else 1.dp,
                                if (entrySelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                selectionShape)
                            .combinedClickable(
                                onClick = {
                                    if (entry.isDirectory && (filesOnly || selected.isEmpty())) {
                                        navigateTo(entry.absolutePath)
                                    } else {
                                        toggle(entry.absolutePath)
                                    }
                                },
                                onLongClick = { if (!filesOnly || !entry.isDirectory) toggle(entry.absolutePath) },
                            ),
                        shape = selectionShape,
                        colors = CardDefaults.cardColors(
                            containerColor = if (entrySelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
                        ),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (!filesOnly || !entry.isDirectory) Checkbox(
                                checked = entrySelected,
                                onCheckedChange = { toggle(entry.absolutePath) },
                            )
                            Icon(
                                if (entry.isDirectory) Icons.Rounded.Folder else Icons.AutoMirrored.Rounded.InsertDriveFile,
                                contentDescription = null,
                            )
                            Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                                Text(entry.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (entry.isDirectory) {
                                    LText("Aplankas", style = MaterialTheme.typography.labelSmall)
                                } else {
                                    Text(FileSystemRules.humanBytes(entry.sizeBytes), style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            if (entry.isDirectory) {
                                IconButton(
                                    onClick = { navigateTo(entry.absolutePath) },
                                    modifier = Modifier.testTag("local_upload_open_${entry.absolutePath}"),
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = uiText("Atidaryti aplanką"))
                                }
                            }
                        }
                    }
                }
            }
            }
        }
    }
}

internal data class LocalUploadNavigationState(
    val currentPath: String,
    val backStack: List<String> = emptyList(),
) {
    val canNavigateBack: Boolean get() = backStack.isNotEmpty()

    fun navigateTo(path: String): LocalUploadNavigationState = if (path == currentPath) {
        this
    } else {
        copy(currentPath = path, backStack = (backStack + currentPath).takeLast(64))
    }

    fun navigateBack(): LocalUploadNavigationState = backStack.lastOrNull()?.let { previous ->
        copy(currentPath = previous, backStack = backStack.dropLast(1))
    } ?: this
}

@Composable
private fun RemoteNameDialog(
    title: String,
    confirmLabel: String,
    initial: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var name by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { LText(title) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, label = { LText("Pavadinimas") }, singleLine = true) },
        confirmButton = {
            Button(onClick = { onConfirm(name.trim()) }, enabled = name.isNotBlank() && '/' !in name && '\\' !in name) { LText(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { LText("Atšaukti") } },
    )
}


@Composable
internal fun NetworkProfileDialog(
    existingProfile: NetworkProfile?,
    onDismiss: () -> Unit,
    onSave: (NetworkProfile, CharArray?, CharArray?) -> Unit,
    onAutofillViewReady: (View) -> Unit = {},
) {
    val stateKey = existingProfile?.id ?: "new"
    var protocol by remember(stateKey) { mutableStateOf(existingProfile?.protocol ?: NetworkProtocol.SFTP) }
    var webDavUseTls by remember(stateKey) { mutableStateOf(existingProfile?.webDavUseTls ?: true) }
    var name by remember(stateKey) { mutableStateOf(existingProfile?.name.orEmpty().firstInputLine()) }
    var host by remember(stateKey) {
        mutableStateOf(NetworkProfileRules.sanitizeHostInput(existingProfile?.host.orEmpty().firstInputLine()))
    }
    var port by remember(stateKey) { mutableStateOf((existingProfile?.port ?: defaultPort(protocol, webDavUseTls)).toString()) }
    var username by remember(stateKey) { mutableStateOf(existingProfile?.username.orEmpty().firstInputLine()) }
    var password by remember(stateKey) { mutableStateOf("") }
    var privateKeyPem by remember(stateKey) { mutableStateOf("") }
    var usePrivateKey by remember(stateKey) { mutableStateOf(false) }
    var basePath by remember(stateKey) { mutableStateOf((existingProfile?.basePath ?: "/").firstInputLine()) }
    var domain by remember(stateKey) { mutableStateOf(existingProfile?.domain.orEmpty().firstInputLine()) }
    var share by remember(stateKey) { mutableStateOf(existingProfile?.smbShare.orEmpty().firstInputLine()) }
    var fingerprint by remember(stateKey) { mutableStateOf(existingProfile?.expectedHostKeySha256.orEmpty().firstInputLine()) }
    var trustFirstUse by remember(stateKey) { mutableStateOf(existingProfile?.allowFirstUseTrust ?: true) }
    val hasNewSecret = password.isNotEmpty() || (protocol == NetworkProtocol.SFTP && usePrivateKey && privateKeyPem.isNotBlank())
    val nameProblem = NetworkProfileRules.nameError(name)
    val hostProblem = if (protocol == NetworkProtocol.WEBDAV) {
        NetworkProfileRules.webDavServerError(host)
    } else {
        NetworkProfileRules.hostError(host)
    }
    val usernameProblem = NetworkProfileRules.usernameError(username)
    val basePathProblem = NetworkProfileRules.basePathError(basePath)
    val portValue = port.toIntOrNull()
    val portProblem = if (portValue == null) "Netinkamas prievadas" else NetworkProfileRules.portError(portValue)
    val profileFieldsValid = nameProblem == null && hostProblem == null && usernameProblem == null &&
        basePathProblem == null && portProblem == null &&
        (protocol != NetworkProtocol.SMB || share.isNotBlank()) &&
        (protocol != NetworkProtocol.SFTP || trustFirstUse || fingerprint.startsWith("SHA256:"))

    ShovelModalDialog(
        title = if (existingProfile == null) "Nauja jungtis" else "Redaguoti jungtį",
        icon = Icons.Rounded.Link,
        onDismissRequest = onDismiss,
        expandedContent = true,
        modifier = Modifier.testTag("network_profile_dialog"),
        actions = {
            TextButton(onClick = onDismiss) { LText("Atšaukti") }
            Button(
                onClick = {
                    val profile = NetworkProfileRules.normalize(NetworkProfile(
                        id = existingProfile?.id.orEmpty(),
                        name = name,
                        protocol = protocol,
                        host = host,
                        port = port.toIntOrNull() ?: defaultPort(protocol, webDavUseTls),
                        username = username,
                        basePath = basePath.ifBlank { "/" },
                        domain = domain,
                        smbShare = share,
                        expectedHostKeySha256 = fingerprint.ifBlank { null },
                        allowFirstUseTrust = protocol == NetworkProtocol.SFTP && trustFirstUse,
                        webDavUseTls = webDavUseTls,
                    ))
                    onSave(
                        profile,
                        password.takeIf(String::isNotEmpty)?.toCharArray(),
                        privateKeyPem.takeIf { usePrivateKey && it.isNotBlank() }?.toCharArray(),
                    )
                    password = ""
                    privateKeyPem = ""
                },
                enabled = profileFieldsValid && (existingProfile != null || hasNewSecret),
            ) { LText("Išsaugoti") }
        },
    ) {
        Box(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp)) {
                ExcludeDialogFromAutofill(onAutofillViewReady)
                LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        NetworkProtocol.entries.forEach { candidate ->
                            AssistChip(
                                onClick = {
                                    val previousDefault = defaultPort(protocol, webDavUseTls).toString()
                                    protocol = candidate
                                    if (port == previousDefault) port = defaultPort(candidate, webDavUseTls).toString()
                                },
                                label = { Text(candidate.name) },
                            )
                        }
                    }
                    LText("Pasirinkta: ${protocol.name}", style = MaterialTheme.typography.labelMedium)
                }
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { LText("Jungties pavadinimas") },
                        singleLine = true,
                        isError = nameProblem != null,
                        supportingText = { nameProblem?.let { LText(it) } },
                    )
                }
                item {
                    OutlinedTextField(
                        value = host,
                        onValueChange = { host = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("network_host")
                            .onFocusChanged { focus ->
                                if (!focus.isFocused) {
                                    val endpoint = if (protocol == NetworkProtocol.WEBDAV) {
                                        NetworkProfileRules.parseWebDavEndpoint(host)
                                    } else {
                                        null
                                    }
                                    if (endpoint != null) {
                                        host = endpoint.host
                                        port = endpoint.port.toString()
                                        basePath = endpoint.basePath
                                        webDavUseTls = endpoint.useTls
                                    } else {
                                        host = NetworkProfileRules.sanitizeHostInput(host)
                                    }
                                }
                            },
                        label = { LText(if (protocol == NetworkProtocol.WEBDAV) "Serveris arba WebDAV URL" else "Serveris") },
                        singleLine = true,
                        isError = hostProblem != null,
                        supportingText = { hostProblem?.let { LText(it) } },
                    )
                }
                item {
                    OutlinedTextField(
                        value = port,
                        onValueChange = { port = it.filter(Char::isDigit) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { LText("Prievadas") },
                        singleLine = true,
                        isError = portProblem != null,
                        supportingText = { portProblem?.let { LText(it) } },
                    )
                }
                item {
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { LText("Naudotojas") },
                        singleLine = true,
                        isError = usernameProblem != null,
                        supportingText = { usernameProblem?.let { LText(it) } },
                    )
                }
                item {
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { LText(if (existingProfile == null) "Slaptažodis" else "Naujas slaptažodis (nebūtinas)") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                    )
                }
                if (existingProfile != null) {
                    item {
                        LText(
                            "Palikite slaptažodį ir privataus rakto lauką tuščius, kad išliktų dabartiniai užšifruoti prisijungimo duomenys.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = basePath,
                        onValueChange = { basePath = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { LText("Pradinis kelias") },
                        singleLine = true,
                        isError = basePathProblem != null,
                        supportingText = { basePathProblem?.let { LText(it) } },
                    )
                }
                if (protocol == NetworkProtocol.SMB) {
                    item { OutlinedTextField(value = share, onValueChange = { share = it }, label = { LText("Bendrinimo vardas") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(value = domain, onValueChange = { domain = it }, label = { LText("Domenas (nebūtinas)") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                }
                if (protocol == NetworkProtocol.SFTP) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = usePrivateKey, onCheckedChange = { usePrivateKey = it })
                            Column {
                                LText("Naudoti privatų SSH raktą")
                                LText("Raktas bus užšifruotas Android Keystore; slaptažodžio laukas taps rakto slaptafraze.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    if (usePrivateKey) {
                        item {
                            OutlinedTextField(
                                value = privateKeyPem,
                                onValueChange = { if (it.length <= 1_048_576) privateKeyPem = it },
                                modifier = Modifier.fillMaxWidth(),
                                label = { LText(if (existingProfile == null) "Privatus raktas PEM / OpenSSH" else "Naujas privatus raktas PEM / OpenSSH") },
                                minLines = 4,
                                maxLines = 8,
                            )
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = fingerprint,
                            onValueChange = { fingerprint = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { LText("SSH rakto SHA256 atspaudas") },
                            singleLine = true,
                            enabled = !trustFirstUse,
                        )
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = trustFirstUse, onCheckedChange = { trustFirstUse = it })
                            Column {
                                LText("Patikėti pirmą gautą raktą")
                                LText("Raktas bus įrašytas ir vėliau pasikeitęs bus blokuojamas.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (protocol == NetworkProtocol.WEBDAV) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = webDavUseTls,
                                onCheckedChange = { enabled ->
                                    val previousDefault = if (webDavUseTls) 443 else 80
                                    webDavUseTls = enabled
                                    if (port == previousDefault.toString()) port = (if (enabled) 443 else 80).toString()
                                },
                            )
                            Column {
                                LText("Naudoti HTTPS/TLS")
                                LText("Galite įklijuoti visą http:// arba https:// WebDAV adresą.", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    if (!webDavUseTls) {
                        item {
                            LText(
                                "HTTP ryšys nešifruotas. Naudokite jį tik patikimame vietiniame tinkle.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                            )
                        }
                    }
                }
                }
        }
    }
}

@Composable
private fun ExcludeDialogFromAutofill(onApplied: (View) -> Unit) {
    val dialogRoot = LocalView.current.rootView
    DisposableEffect(dialogRoot) {
        val previous = dialogRoot.importantForAutofill
        dialogRoot.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        onApplied(dialogRoot)
        onDispose { dialogRoot.importantForAutofill = previous }
    }
}

@Composable
internal fun NetworkError(error: RemoteErrorInfo) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(12.dp).testTag("network_error"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(
                Icons.Rounded.ErrorOutline,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.size(28.dp),
            )
            Column(modifier = Modifier.weight(1f).padding(start = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                LText(
                    error.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                )
                LText(error.detail, color = MaterialTheme.colorScheme.onErrorContainer)
                LText(
                    error.suggestion,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                )
                LText(
                    "Diagnostikos kodas: ${error.diagnosticCode}",
                    modifier = Modifier.testTag("network_error_code"),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                )
            }
        }
    }
}

private fun defaultPort(protocol: NetworkProtocol, webDavUseTls: Boolean = true): Int = when (protocol) {
    NetworkProtocol.SFTP -> 22
    NetworkProtocol.SMB -> 445
    NetworkProtocol.WEBDAV -> if (webDavUseTls) 443 else 80
    NetworkProtocol.FTP -> 21
    NetworkProtocol.FTPS -> 21
}

private fun String.firstInputLine(): String = lineSequence().firstOrNull().orEmpty().trim()
