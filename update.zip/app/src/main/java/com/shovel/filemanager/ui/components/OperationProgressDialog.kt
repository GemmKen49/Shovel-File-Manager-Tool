package com.shovel.filemanager.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shovel.filemanager.core.FileSystemRules
import com.shovel.filemanager.operations.OperationSnapshot
import com.shovel.filemanager.operations.OperationStatus
import com.shovel.filemanager.ui.localization.LText
import com.shovel.filemanager.ui.theme.ShovelButton as Button

@Composable
internal fun OperationProgressDialog(
    operation: OperationSnapshot,
    onCancel: () -> Unit,
    onHide: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
) {
    val progress = when {
        operation.totalBytes != null && operation.totalBytes > 0 ->
            (operation.completedBytes.toFloat() / operation.totalBytes).coerceIn(0f, 1f)
        operation.totalItems != null && operation.totalItems > 0 ->
            (operation.completedItems.toFloat() / operation.totalItems).coerceIn(0f, 1f)
        else -> null
    }
    ShovelModalDialog(
        title = operation.title,
        icon = Icons.Rounded.Sync,
        onDismissRequest = onHide,
        modifier = Modifier.testTag("operation_progress_dialog"),
        actions = {
            TextButton(onClick = onHide, modifier = Modifier.testTag("hide_operation")) { LText("Hide") }
            if (operation.status == OperationStatus.PAUSED) {
                TextButton(onClick = onResume, modifier = Modifier.testTag("resume_operation")) { LText("Resume") }
            } else if (operation.status == OperationStatus.RUNNING) {
                TextButton(onClick = onPause, modifier = Modifier.testTag("pause_operation")) { LText("Pause") }
            }
            Button(onClick = onCancel, modifier = Modifier.testTag("cancel_operation")) { LText("Cancel") }
        },
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            if (progress == null) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            else LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
            operation.currentName?.let {
                Text(java.io.File(it).name, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall, modifier = Modifier.testTag("operation_current_name"))
            }
            operation.totalBytes?.let { total ->
                Text("${FileSystemRules.humanBytes(operation.completedBytes)} / ${FileSystemRules.humanBytes(total)}",
                    style = MaterialTheme.typography.bodyMedium, modifier = Modifier.testTag("operation_bytes"))
            }
            operation.totalItems?.let { total ->
                LText("${operation.completedItems} of $total done", style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.testTag("operation_items"))
            }
            operation.message?.let { LText(it, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant) }
            LText("When hidden, the operation continues in the background and appears in Android notifications.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
