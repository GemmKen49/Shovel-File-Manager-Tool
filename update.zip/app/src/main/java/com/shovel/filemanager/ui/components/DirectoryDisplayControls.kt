package com.shovel.filemanager.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.automirrored.rounded.List
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FilterAlt
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shovel.filemanager.model.SortDirection
import com.shovel.filemanager.model.SortMode
import com.shovel.filemanager.ui.localization.LText
import com.shovel.filemanager.ui.localization.uiText
import com.shovel.filemanager.data.OptionalFeature

/**
 * Shared navigation chrome for every place that behaves like a file browser.
 * Unsupported navigation directions stay visible but disabled so the controls
 * do not jump around when the backing storage changes.
 */
@Composable
fun DirectoryBrowserToolbar(
    title: String,
    path: String,
    backEnabled: Boolean,
    forwardEnabled: Boolean,
    upEnabled: Boolean,
    searchActive: Boolean,
    grid: Boolean,
    testTagPrefix: String,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onUp: () -> Unit,
    onToggleSearch: () -> Unit,
    onToggleLayout: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
    actions: @Composable () -> Unit,
) {
    com.shovel.filemanager.ui.theme.AppearanceContentOn(MaterialTheme.colorScheme.surfaceContainer) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp, vertical = 3.dp)
            .background(MaterialTheme.colorScheme.surfaceContainer, RoundedCornerShape(22.dp))
            .padding(horizontal = 2.dp)
            .testTag("directory_toolbar_$testTagPrefix"),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (featureVisible(OptionalFeature.TOOLBAR_BACK)) IconButton(onClick = onBack, enabled = backEnabled) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = uiText("Back"))
        }
        if (featureVisible(OptionalFeature.TOOLBAR_FORWARD)) IconButton(onClick = onForward, enabled = forwardEnabled) {
            Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = uiText("Forward"))
        }
        if (featureVisible(OptionalFeature.TOOLBAR_UP)) IconButton(onClick = onUp, enabled = upEnabled) {
            Icon(Icons.Rounded.ArrowUpward, contentDescription = uiText("Up"))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = path,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        DirectorySearchButton(
            active = searchActive,
            testTag = "directory_search_$testTagPrefix",
            onClick = onToggleSearch,
        )
        DirectoryLayoutButton(
            grid = grid,
            testTag = "directory_layout_$testTagPrefix",
            onToggleLayout = onToggleLayout,
            onOpenSettings = onOpenSettings,
        )
        actions()
    }
    }
}

/**
 * The same view-mode control is used for every local and remote directory.
 * A tap switches between list and grid; a long press opens the full settings.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DirectoryLayoutButton(
    grid: Boolean,
    testTag: String,
    onToggleLayout: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!featureVisible(OptionalFeature.TOOLBAR_LAYOUT)) return
    val toggleLabel = uiText(if (grid) "Show list" else "Show grid")
    Box(
        modifier = modifier
            .size(48.dp)
            .testTag(testTag)
            .clip(CircleShape)
            .combinedClickable(
                onClickLabel = toggleLabel,
                onLongClickLabel = uiText("Display settings"),
                onClick = onToggleLayout,
                onLongClick = onOpenSettings,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = if (grid) Icons.AutoMirrored.Rounded.List else Icons.Rounded.GridView,
            contentDescription = toggleLabel,
        )
    }
}

@Composable
fun DirectorySearchButton(
    active: Boolean,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (!active && !featureVisible(OptionalFeature.TOOLBAR_SEARCH)) return
    IconButton(onClick = onClick, modifier = modifier.testTag(testTag)) {
        Icon(
            Icons.Rounded.Search,
            contentDescription = uiText(if (active) "Close quick search" else "Quick search in this folder"),
        )
    }
}

@Composable
fun DirectoryQuickSearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    onClose: () -> Unit,
    filterActive: Boolean = false,
    onOpenFilter: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        trailingIcon = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onOpenFilter != null) {
                    IconButton(onClick = onOpenFilter) {
                        Icon(
                            Icons.Rounded.FilterAlt,
                            contentDescription = uiText(if (filterActive) "Filter active" else "Filter"),
                            tint = if (filterActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.Close, contentDescription = uiText("Close quick search"))
                }
            }
        },
        placeholder = { LText("Filter this folder") },
        singleLine = true,
    )
}

/** Common directory-view actions shared by local and remote folder menus. */
@Composable
fun DirectoryDisplayMenuItems(
    grid: Boolean,
    includeHidden: Boolean,
    hiddenFilesAvailable: Boolean = true,
    showThumbnails: Boolean,
    thumbnailsAvailable: Boolean,
    sortMode: SortMode,
    sortDirection: SortDirection,
    displaySettingsTestTag: String,
    onToggleHidden: () -> Unit,
    onToggleLayout: () -> Unit,
    onToggleThumbnails: () -> Unit,
    onOpenSettings: () -> Unit,
    onSort: (SortMode) -> Unit,
    onDismissMenu: () -> Unit,
    filterActive: Boolean = false,
    onOpenFilter: (() -> Unit)? = null,
) {
    if (onOpenFilter != null) {
        DropdownMenuItem(
            text = { LText(if (filterActive) "Filter active" else "Filter") },
            leadingIcon = {
                Icon(
                    Icons.Rounded.FilterAlt,
                    contentDescription = null,
                    tint = if (filterActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            },
            onClick = {
                onDismissMenu()
                onOpenFilter()
            },
        )
    }
    if (hiddenFilesAvailable) {
        DropdownMenuItem(
            text = { LText(if (includeHidden) "Hide hidden files" else "Show hidden files") },
            leadingIcon = {
                Icon(if (includeHidden) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff, contentDescription = null)
            },
            onClick = {
                onDismissMenu()
                onToggleHidden()
            },
        )
    }
    DropdownMenuItem(
        text = { LText(if (grid) "Show list" else "Show grid") },
        leadingIcon = {
            Icon(if (grid) Icons.AutoMirrored.Rounded.List else Icons.Rounded.GridView, contentDescription = null)
        },
        onClick = {
            onDismissMenu()
            onToggleLayout()
        },
    )
    if (thumbnailsAvailable) {
        DropdownMenuItem(
            text = { LText(if (showThumbnails) "Show icons" else "Show thumbnails") },
            leadingIcon = {
                Icon(
                    if (showThumbnails) Icons.AutoMirrored.Rounded.InsertDriveFile else Icons.Rounded.PhotoLibrary,
                    contentDescription = null,
                )
            },
            onClick = {
                onDismissMenu()
                onToggleThumbnails()
            },
        )
    }
    DropdownMenuItem(
        text = {
            Column {
                LText("Display settings")
                Text(
                    directorySortSummary(sortMode, sortDirection),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        leadingIcon = {
            Icon(Icons.AutoMirrored.Rounded.Sort, contentDescription = null)
        },
        modifier = Modifier.testTag(displaySettingsTestTag),
        onClick = {
            onDismissMenu()
            onOpenSettings()
        },
    )
}

@Composable
private fun directorySortSummary(mode: SortMode, direction: SortDirection): String {
    val modeLabel = when (mode) {
        SortMode.NAME -> "By name"
        SortMode.MODIFIED -> "By date"
        SortMode.SIZE -> "By size"
        SortMode.TYPE -> "By type"
    }
    val directionLabel = if (direction == SortDirection.ASCENDING) "Ascending" else "Descending"
    return "${uiText(modeLabel)} · ${uiText(directionLabel)}"
}
