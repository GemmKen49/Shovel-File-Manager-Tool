package com.shovel.filemanager.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Refresh
import com.shovel.filemanager.data.OptionalFeature
import com.shovel.filemanager.ui.components.featureVisible
import com.shovel.filemanager.ui.theme.ShovelAlertDialog as AlertDialog
import com.shovel.filemanager.ui.theme.ShovelButton as Button
import com.shovel.filemanager.ui.theme.ShovelCard as Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import com.shovel.filemanager.ui.theme.ShovelDropdownMenu as DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import com.shovel.filemanager.ui.theme.ShovelSurface as Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import com.shovel.filemanager.ui.theme.ShovelDialog
import com.shovel.filemanager.advanced.AdvancedAccessBackend
import com.shovel.filemanager.advanced.AdvancedAccessState
import com.shovel.filemanager.core.FileSystemRules
import com.shovel.filemanager.model.ClipboardMode
import com.shovel.filemanager.model.ClipboardSource
import com.shovel.filemanager.model.ClipboardState
import com.shovel.filemanager.model.FileEntry
import com.shovel.filemanager.model.SortDirection
import com.shovel.filemanager.model.SortMode
import com.shovel.filemanager.ui.AdvancedBrowserUiState
import com.shovel.filemanager.ui.MainViewModel
import com.shovel.filemanager.ui.components.DirectoryDisplayMenuItems
import com.shovel.filemanager.ui.components.DirectoryEntryFilter
import com.shovel.filemanager.ui.components.DirectoryEntryFilterDialog
import com.shovel.filemanager.ui.components.DirectoryEntryFilterRules
import com.shovel.filemanager.ui.components.DirectoryBrowserToolbar
import com.shovel.filemanager.ui.components.DirectoryDisplaySettingsDialog
import com.shovel.filemanager.ui.components.DirectoryQuickSearchField
import com.shovel.filemanager.data.DirectoryDisplaySettings
import com.shovel.filemanager.data.DirectoryGridStyle
import com.shovel.filemanager.data.DirectoryLayoutMode
import com.shovel.filemanager.ui.components.PrivilegedFileVisual
import com.shovel.filemanager.ui.components.SelectionActionBar
import com.shovel.filemanager.ui.components.ShovelPullToRefresh
import com.shovel.filemanager.ui.components.LazyListFastScroller
import com.shovel.filemanager.ui.components.LazyGridFastScroller
import com.shovel.filemanager.ui.components.DeleteConfirmationDialog
import com.shovel.filemanager.ui.localization.LText
import com.shovel.filemanager.ui.localization.uiText

@Composable
fun AdvancedStorageBrowserDialog(
    state: AdvancedBrowserUiState,
    access: AdvancedAccessState,
    clipboard: ClipboardState?,
    viewModel: MainViewModel,
) {
    if (!state.open) return
    var menu by remember { mutableStateOf(false) }
    var createDirectory by remember { mutableStateOf(false) }
    var createFile by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<FileEntry?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var showDisplaySettings by remember { mutableStateOf(false) }
    var searchVisible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var entryFilters by remember(state.path) { mutableStateOf<Set<DirectoryEntryFilter>>(emptySet()) }
    var showEntryFilter by remember(state.path) { mutableStateOf(false) }
    LaunchedEffect(state.path) {
        searchVisible = false
        searchQuery = ""
    }
    val displayedEntries = remember(state.entries, searchQuery, entryFilters) {
        val query = searchQuery.trim()
        state.entries.filter { entry ->
            (query.isEmpty() || entry.name.contains(query, ignoreCase = true)) &&
                DirectoryEntryFilterRules.matches(entry.kind, entryFilters)
        }
    }
    val allSelected = displayedEntries.isNotEmpty() && displayedEntries.all { it.absolutePath in state.selectedPaths }

    ShovelDialog(
        onDismissRequest = { viewModel.navigateAdvancedBack() },
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        com.shovel.filemanager.ui.theme.AppearancePage(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                DirectoryBrowserToolbar(
                    title = uiText(state.title),
                    path = state.path.ifBlank { uiText("Jungiama") },
                    backEnabled = true,
                    forwardEnabled = false,
                    upEnabled = viewModel.canNavigateAdvancedUp(),
                    searchActive = searchVisible,
                    grid = state.grid,
                    testTagPrefix = "advanced",
                    onBack = { viewModel.navigateAdvancedBack() },
                    onForward = {},
                    onUp = { viewModel.navigateAdvancedUp() },
                    onToggleSearch = {
                        searchVisible = !searchVisible
                        if (!searchVisible) searchQuery = ""
                    },
                    onToggleLayout = viewModel::toggleAdvancedLayout,
                    onOpenSettings = { showDisplaySettings = true },
                ) {
                    Box {
                        IconButton(onClick = { menu = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Aplanko veiksmai"))
                        }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(
                                text = { LText("Naujas aplankas") },
                                leadingIcon = { Icon(Icons.Rounded.CreateNewFolder, contentDescription = null) },
                                onClick = { menu = false; createDirectory = true },
                            )
                            DropdownMenuItem(
                                text = { LText("Naujas failas") },
                                leadingIcon = { Icon(Icons.AutoMirrored.Rounded.InsertDriveFile, contentDescription = null) },
                                onClick = { menu = false; createFile = true },
                            )
                            DropdownMenuItem(
                                text = { LText("Įklijuoti") },
                                leadingIcon = { Icon(Icons.Rounded.ContentPaste, contentDescription = null) },
                                enabled = clipboard != null && state.path.isNotBlank(),
                                onClick = { menu = false; viewModel.pasteIntoAdvanced() },
                            )
                            HorizontalDivider()
                            DirectoryDisplayMenuItems(
                                grid = state.grid,
                                includeHidden = state.includeHidden,
                                showThumbnails = false,
                                thumbnailsAvailable = false,
                                sortMode = state.sortMode,
                                sortDirection = state.sortDirection,
                                displaySettingsTestTag = "advanced_display_settings",
                                onToggleHidden = viewModel::toggleAdvancedHidden,
                                onToggleLayout = viewModel::toggleAdvancedLayout,
                                onToggleThumbnails = {},
                                onOpenSettings = { showDisplaySettings = true },
                                onSort = { mode ->
                                    val direction = if (state.sortMode == mode) {
                                        if (state.sortDirection == SortDirection.ASCENDING) SortDirection.DESCENDING else SortDirection.ASCENDING
                                    } else SortDirection.ASCENDING
                                    viewModel.setAdvancedSort(mode, direction)
                                },
                                onDismissMenu = { menu = false },
                                filterActive = entryFilters.isNotEmpty(),
                                onOpenFilter = { showEntryFilter = true },
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { LText("Atnaujinti") },
                                leadingIcon = { Icon(Icons.Rounded.Refresh, contentDescription = null) },
                                enabled = !state.loading,
                                onClick = { menu = false; viewModel.refreshAdvancedBrowser() },
                            )
                        }
                    }
                }
                LText(
                    advancedBackendLabel(access.activeBackend),
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                )

                if (searchVisible) {
                    DirectoryQuickSearchField(
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        onClose = { searchVisible = false; searchQuery = "" },
                        filterActive = entryFilters.isNotEmpty(),
                        onOpenFilter = { showEntryFilter = true },
                        modifier = Modifier.testTag("directory_search_field_advanced"),
                    )
                }

                if (state.selectedPaths.isNotEmpty()) {
                    SelectionActionBar(
                        count = state.selectedPaths.size,
                        allSelected = allSelected,
                        onClose = viewModel::clearAdvancedSelection,
                        onToggleSelectAll = {
                            if (allSelected) viewModel.clearAdvancedSelection()
                            else displayedEntries.forEach { entry ->
                                if (entry.absolutePath !in state.selectedPaths) viewModel.toggleAdvancedSelection(entry.absolutePath)
                            }
                        },
                        modifier = Modifier.testTag("advanced_selection_bar"),
                    ) {
                        IconButton(onClick = { viewModel.copyAdvancedSelection(move = false) }) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = uiText("Kopijuoti"))
                        }
                        IconButton(onClick = { viewModel.copyAdvancedSelection(move = true) }) {
                            Icon(Icons.Rounded.ContentCut, contentDescription = uiText("Perkelti"))
                        }
                        if (state.selectedPaths.size == 1) {
                            IconButton(onClick = { renameTarget = state.entries.firstOrNull { it.absolutePath in state.selectedPaths } }) {
                                Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = uiText("Pervadinti"))
                            }
                        }
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Rounded.DeleteForever, contentDescription = uiText("Ištrinti visam laikui"), tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }

                ShovelPullToRefresh(
                    isRefreshing = state.loading,
                    onRefresh = viewModel::refreshAdvancedBrowser,
                    modifier = Modifier.weight(1f),
                    testTag = "pull_to_refresh_advanced",
                ) {
                    when {
                        state.loading && state.entries.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                        state.error != null && state.entries.isEmpty() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                LText("Aplanko atidaryti nepavyko", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
                                LText(state.error, style = MaterialTheme.typography.bodySmall)
                                Button(onClick = viewModel::refreshAdvancedBrowser) { LText("Bandyti dar kartą") }
                            }
                        }
                        state.entries.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            LText("Aplankas tuščias")
                        }
                        displayedEntries.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            LText("Atitikmenų nerasta")
                        }
                        state.grid -> AdvancedGrid(
                            state = state,
                            displayedEntries = displayedEntries,
                            viewModel = viewModel,
                        )
                        else -> AdvancedList(
                            state = state,
                            displayedEntries = displayedEntries,
                            viewModel = viewModel,
                        )
                    }
                }
            }
        }
    }

    if (createDirectory) NameDialog("Naujas aplankas", "Aplanko pavadinimas", { createDirectory = false }) { name ->
        createDirectory = false
        viewModel.createAdvancedDirectory(name)
    }
    if (createFile) NameDialog("Naujas failas", "Failo pavadinimas", { createFile = false }) { name ->
        createFile = false
        viewModel.createAdvancedFile(name)
    }
    renameTarget?.let { entry ->
        NameDialog("Pervadinti", "Naujas pavadinimas", { renameTarget = null }, initial = entry.name) { name ->
            renameTarget = null
            viewModel.renameAdvanced(entry.absolutePath, name)
        }
    }
    if (confirmDelete) {
        val entries = state.entries.filter { it.absolutePath in state.selectedPaths }
        DeleteConfirmationDialog(
            names = entries.map(FileEntry::name), permanent = true,
            onDismiss = { confirmDelete = false },
            onConfirm = { confirmDelete = false; viewModel.deleteAdvancedSelectionPermanently() },
            loadSummary = { viewModel.loadAdvancedSelectionInfo(state.selectedPaths) },
            explanation = "Šių apsaugotų failų nebus galima atkurti iš Shovel šiukšlinės.",
        )
    }
    if (showDisplaySettings) {
        DirectoryDisplaySettingsDialog(
            initialSettings = DirectoryDisplaySettings(
                layoutMode = if (state.grid) DirectoryLayoutMode.GRID else DirectoryLayoutMode.LIST,
                iconScalePercent = state.iconScalePercent,
                spacingScalePercent = state.spacingScalePercent,
                gridColumns = state.gridColumns,
                gridStyle = state.gridStyle,
                showThumbnails = false,
            ),
            thumbnailsAvailable = false,
            onDismiss = { showDisplaySettings = false },
            onApply = {
                viewModel.setAdvancedDisplaySettings(it)
                showDisplaySettings = false
            },
            onApplySort = viewModel::setAdvancedSort,
            initialSortMode = state.sortMode,
            initialSortDirection = state.sortDirection,
            onApplyToAll = { settings, mode, direction ->
                viewModel.applyDirectoryDisplaySettingsToAll(settings, mode, direction)
                showDisplaySettings = false
            },
        )
    }
    if (showEntryFilter) {
        DirectoryEntryFilterDialog(
            selected = entryFilters,
            onSelectedChange = { entryFilters = it },
            onDismiss = { showEntryFilter = false },
        )
    }
}

@Composable
private fun AdvancedList(
    state: AdvancedBrowserUiState,
    displayedEntries: List<FileEntry>,
    viewModel: MainViewModel,
) {
    val initialPosition = remember(state.path, state.grid) { viewModel.advancedScrollPosition(state.path, grid = false) }
    val initialIndex = initialPosition.firstVisibleItemIndex.coerceAtMost(displayedEntries.lastIndex.coerceAtLeast(0))
    val listState = key(state.path) {
        rememberLazyListState(
            initialFirstVisibleItemIndex = initialIndex,
            initialFirstVisibleItemScrollOffset = if (initialIndex == initialPosition.firstVisibleItemIndex) {
                initialPosition.firstVisibleItemScrollOffset
            } else {
                0
            },
        )
    }
    DisposableEffect(state.path, listState) {
        onDispose {
            viewModel.saveAdvancedScrollPosition(
                state.path,
                grid = false,
                listState.firstVisibleItemIndex,
                listState.firstVisibleItemScrollOffset,
            )
        }
    }
    Box(Modifier.fillMaxSize()) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().testTag("advanced_list"),
        contentPadding = PaddingValues(bottom = 24.dp),
    ) {
        items(displayedEntries, key = FileEntry::absolutePath) { entry ->
            AdvancedListEntry(
                parentPath = state.path,
                entry = entry,
                selected = entry.absolutePath in state.selectedPaths,
                selectionActive = state.selectedPaths.isNotEmpty(),
                iconScalePercent = state.iconScalePercent,
                spacingScalePercent = state.spacingScalePercent,
                viewModel = viewModel,
            )
            HorizontalDivider()
        }
    }
    LazyListFastScroller(listState)
    }
}

@Composable
private fun AdvancedGrid(
    state: AdvancedBrowserUiState,
    displayedEntries: List<FileEntry>,
    viewModel: MainViewModel,
) {
    val initialPosition = remember(state.path, state.grid) { viewModel.advancedScrollPosition(state.path, grid = true) }
    val initialIndex = initialPosition.firstVisibleItemIndex.coerceAtMost(displayedEntries.lastIndex.coerceAtLeast(0))
    val gridState = key(state.path) {
        rememberLazyGridState(
            initialFirstVisibleItemIndex = initialIndex,
            initialFirstVisibleItemScrollOffset = if (initialIndex == initialPosition.firstVisibleItemIndex) {
                initialPosition.firstVisibleItemScrollOffset
            } else {
                0
            },
        )
    }
    DisposableEffect(state.path, gridState) {
        onDispose {
            viewModel.saveAdvancedScrollPosition(
                state.path,
                grid = true,
                gridState.firstVisibleItemIndex,
                gridState.firstVisibleItemScrollOffset,
            )
        }
    }
    Box(Modifier.fillMaxSize()) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(state.gridColumns.coerceIn(1, 6)),
        state = gridState,
        modifier = Modifier.fillMaxSize().testTag("advanced_grid"),
        contentPadding = PaddingValues(10.dp, 8.dp, 10.dp, 24.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(displayedEntries, key = FileEntry::absolutePath) { entry ->
            AdvancedGridEntry(
                parentPath = state.path,
                entry = entry,
                selected = entry.absolutePath in state.selectedPaths,
                selectionActive = state.selectedPaths.isNotEmpty(),
                iconScalePercent = state.iconScalePercent,
                spacingScalePercent = state.spacingScalePercent,
                gridStyle = state.gridStyle,
                viewModel = viewModel,
            )
        }
    }
    LazyGridFastScroller(gridState)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AdvancedListEntry(
    parentPath: String,
    entry: FileEntry,
    selected: Boolean,
    selectionActive: Boolean,
    iconScalePercent: Int,
    spacingScalePercent: Int,
    viewModel: MainViewModel,
) {
    val iconSize = (48f * iconScalePercent / 100f).dp
    val verticalPadding = (7f * spacingScalePercent / 100f).dp
    Row(
        modifier = Modifier.fillMaxWidth().combinedClickable(
            onClick = { if (selectionActive) viewModel.toggleAdvancedSelection(entry.absolutePath) else viewModel.openAdvancedEntry(entry) },
            onLongClick = { viewModel.toggleAdvancedSelection(entry.absolutePath) },
        ).padding(horizontal = 10.dp, vertical = verticalPadding),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = selected, onCheckedChange = { viewModel.toggleAdvancedSelection(entry.absolutePath) })
        PrivilegedFileVisual(parentPath, entry, iconSize, iconSize, modifier = Modifier.size(iconSize))
        Column(modifier = Modifier.weight(1f).padding(start = 10.dp)) {
            Text(entry.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            LText(entryMeta(entry), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AdvancedGridEntry(
    parentPath: String,
    entry: FileEntry,
    selected: Boolean,
    selectionActive: Boolean,
    iconScalePercent: Int,
    spacingScalePercent: Int,
    gridStyle: DirectoryGridStyle,
    viewModel: MainViewModel,
) {
    val iconSize = (72f * iconScalePercent / 100f).dp
    val padding = (8f * spacingScalePercent / 100f).dp
    Card(
        modifier = Modifier.fillMaxWidth().combinedClickable(
            onClick = { if (selectionActive) viewModel.toggleAdvancedSelection(entry.absolutePath) else viewModel.openAdvancedEntry(entry) },
            onLongClick = { viewModel.toggleAdvancedSelection(entry.absolutePath) },
        ),
        shape = if (gridStyle == DirectoryGridStyle.CLASSIC) androidx.compose.foundation.shape.RoundedCornerShape(4.dp) else androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else if (gridStyle == DirectoryGridStyle.CLASSIC) MaterialTheme.colorScheme.surface.copy(alpha = 0f) else MaterialTheme.colorScheme.surfaceContainer,
        ),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(padding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Checkbox(checked = selected, onCheckedChange = { viewModel.toggleAdvancedSelection(entry.absolutePath) }, modifier = Modifier.align(Alignment.End))
            PrivilegedFileVisual(parentPath, entry, iconSize, iconSize, modifier = Modifier.size(iconSize))
            Text(entry.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            LText(entryMeta(entry), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NameDialog(title: String, label: String, onDismiss: () -> Unit, initial: String = "", onConfirm: (String) -> Unit) {
    var value by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { LText(title) },
        text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { LText(label) }, singleLine = true) },
        confirmButton = { Button(onClick = { onConfirm(value) }, enabled = value.isNotBlank()) { LText("Patvirtinti") } },
        dismissButton = { TextButton(onClick = onDismiss) { LText("Atšaukti") } },
    )
}

private fun entryMeta(entry: FileEntry): String = if (entry.isDirectory) "Aplankas" else FileSystemRules.humanBytes(entry.sizeBytes)

private fun advancedBackendLabel(backend: AdvancedAccessBackend): String = when (backend) {
    AdvancedAccessBackend.NONE -> "Prieiga neaktyvi"
    AdvancedAccessBackend.SHIZUKU_SHELL -> "Shizuku · shell prieiga"
    AdvancedAccessBackend.SHIZUKU_ROOT -> "Shizuku · root prieiga"
    AdvancedAccessBackend.ROOT -> "Root prieiga"
}
