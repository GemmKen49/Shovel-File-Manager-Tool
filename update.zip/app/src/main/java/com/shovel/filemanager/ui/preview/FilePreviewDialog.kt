package com.shovel.filemanager.ui.preview

import com.shovel.filemanager.ui.localization.appString

import com.shovel.filemanager.ui.localization.LText
import com.shovel.filemanager.ui.localization.uiText
import com.shovel.filemanager.ui.localization.rememberLocalizedDateTimeFormat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.graphics.ImageDecoder
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.view.View
import android.widget.TextView
import android.widget.ImageView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.SaveAs
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Info
import com.shovel.filemanager.ui.theme.ShovelAlertDialog as AlertDialog
import com.shovel.filemanager.ui.theme.ShovelButton as Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import com.shovel.filemanager.ui.theme.ShovelDropdownMenu as DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import com.shovel.filemanager.ui.theme.ShovelFilterChip as FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import com.shovel.filemanager.ui.theme.ShovelSurface as Surface
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.SemanticsPropertyKey
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.times
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import androidx.compose.ui.window.DialogProperties
import com.shovel.filemanager.ui.theme.ShovelDialog
import com.shovel.filemanager.archive.ArchiveEntryInfo
import com.shovel.filemanager.archive.ArchiveBrowserIndex
import com.shovel.filemanager.archive.ArchiveBrowserItem
import com.shovel.filemanager.archive.ArchiveMutationRules
import com.shovel.filemanager.MainActivity
import com.shovel.filemanager.R
import com.shovel.filemanager.BuildConfig
import com.shovel.filemanager.core.FileSystemRules
import com.shovel.filemanager.editing.EditConflict
import com.shovel.filemanager.editing.EditExistingPolicy
import com.shovel.filemanager.editing.EditOrigin
import com.shovel.filemanager.editing.EditSaveAsConflict
import com.shovel.filemanager.editing.EditSession
import com.shovel.filemanager.editing.EditabilityRules
import com.shovel.filemanager.editing.FileRevision
import com.shovel.filemanager.editing.LineEnding
import com.shovel.filemanager.editing.TextEncoding
import com.shovel.filemanager.model.EntryKind
import com.shovel.filemanager.model.FileEntry
import com.shovel.filemanager.model.SortDirection
import com.shovel.filemanager.model.SortMode
import com.shovel.filemanager.media.BackgroundPlaybackService
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shovel.filemanager.ui.components.BackgroundPlaybackBar
import com.shovel.filemanager.ui.components.ShovelActionRow
import com.shovel.filemanager.ui.components.ShovelModalDialog
import com.shovel.filemanager.data.DirectoryDisplaySettings
import com.shovel.filemanager.data.DirectoryDisplayDefaults
import com.shovel.filemanager.data.DirectoryGridStyle
import com.shovel.filemanager.data.DirectoryLayoutMode
import com.shovel.filemanager.pdfsigning.PdfSignaturePlacement
import com.shovel.filemanager.pdfsigning.SignatureDrawing
import com.shovel.filemanager.ui.PreviewTarget
import com.shovel.filemanager.ui.FileEditUiState
import com.shovel.filemanager.ui.SignatureLibraryUiState
import com.shovel.filemanager.ui.editor.EditSaveAsDialog
import com.shovel.filemanager.ui.editor.FullTextEditor
import com.shovel.filemanager.ui.components.DirectoryBrowserToolbar
import com.shovel.filemanager.ui.components.DirectoryDisplayMenuItems
import com.shovel.filemanager.ui.components.DirectoryEntryFilter
import com.shovel.filemanager.ui.components.DirectoryEntryFilterDialog
import com.shovel.filemanager.ui.components.DirectoryEntryFilterRules
import com.shovel.filemanager.ui.components.DirectoryDisplaySettingsDialog
import com.shovel.filemanager.ui.components.DirectoryQuickSearchField
import com.shovel.filemanager.ui.components.ShovelPullToRefresh
import com.shovel.filemanager.ui.components.SelectionActionBar
import com.shovel.filemanager.ui.components.LocalFileVisual
import com.shovel.filemanager.ui.components.DeleteConfirmationDialog
import com.shovel.filemanager.ui.components.LazyGridFastScroller
import com.shovel.filemanager.ui.components.LazyListFastScroller
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.text.DateFormat
import java.util.Date
import java.util.Locale

internal val pdfRenderPermits = Semaphore(1)

internal data class PdfDocumentInfo(val pages: List<PdfPageSize>) {
    val pageCount: Int get() = pages.size
}

internal data class PdfViewportSnapshot(
    val scale: Float,
    val horizontalScroll: Int,
    val pageIndex: Int,
    val verticalScroll: Int,
    val visiblePages: List<PdfVisiblePage>,
)

internal val PdfViewportSemanticsKey = SemanticsPropertyKey<PdfViewportSnapshot>("PdfViewport")

internal data class PdfTextSelectionSnapshot(
    val text: String,
    val boundsCount: Int,
    val startHandle: PdfDisplayPoint,
    val stopHandle: PdfDisplayPoint,
)

internal val PdfTextSelectionSemanticsKey =
    SemanticsPropertyKey<PdfTextSelectionSnapshot>("PdfTextSelection")

private data class PdfSelectionRequest(
    val pageIndex: Int,
    val start: PdfTextBoundary,
    val stop: PdfTextBoundary,
    val clearOnEmpty: Boolean,
    val showProgress: Boolean,
)

private data class PdfSelectionDragPreview(
    val handle: PdfSelectionHandle,
    val point: PdfPagePoint,
)

private data class MediaPreviewInfo(
    val durationMillis: Long,
    val mimeType: String?,
    val bitRate: String?,
    val artwork: Bitmap?,
)

private class PdfPinchAnchor {
    var active = false
    var pageIndex = 0
    var documentX = 0f
    var documentY = 0f
}

private data class PdfZoomScrollRequest(
    val horizontal: Float,
    val pageIndex: Int,
    val vertical: Float,
)

@Composable
fun FilePreviewDialog(
    target: PreviewTarget,
    editState: FileEditUiState,
    signatureLibrary: SignatureLibraryUiState,
    archiveDisplayDefaults: DirectoryDisplayDefaults,
    onApplyArchiveDisplayToAll: (DirectoryDisplaySettings, SortMode?, SortDirection) -> Unit,
    onClose: () -> Unit,
    onDelete: (() -> Unit)?,
    onPrepareEdit: () -> Unit,
    onApplyPdfSignature: (SignatureDrawing, PdfSignaturePlacement) -> Unit,
    onRefreshSignatureLibrary: () -> Unit,
    onSaveSignature: (String, SignatureDrawing) -> Unit,
    onDeleteSavedSignature: (String) -> Unit,
    onEditTextChanged: (String) -> Unit,
    onEditEncodingChanged: (TextEncoding) -> Unit,
    onEditLineEndingChanged: (LineEnding) -> Unit,
    onSaveEdit: (Boolean) -> Unit,
    onSaveEditAs: (Uri) -> Unit,
    onSaveEditAsLocal: (String, String) -> Unit,
    onResolveSaveAsConflict: (EditExistingPolicy) -> Unit,
    onDismissSaveAsConflict: () -> Unit,
    initialLocalSavePath: String,
    loadLocalSaveDirectory: suspend (String) -> Result<List<FileEntry>>,
    onExternalEditorReturned: () -> Unit,
    onDismissEditConflict: () -> Unit,
    onKeepEditing: () -> Unit,
    onDiscardEditAndClose: () -> Unit,
    onCopyArchiveEntry: (String) -> Unit,
    onCopyArchiveEntries: (Set<String>) -> Unit,
    onOpenArchiveEntry: (String) -> Unit,
    onShareArchiveEntries: (Set<String>) -> Unit,
    onExtractArchiveEntries: (Set<String>, String, CharArray?) -> Unit,
    onRenameArchiveEntry: (String, String) -> Unit,
    onDeleteArchiveEntries: (Set<String>) -> Unit,
    onMoveArchiveEntries: (Set<String>) -> Unit,
    onRefreshArchive: () -> Unit,
    loadArchiveThumbnail: suspend (String) -> Result<File>,
    onExtract: (FileEntry, String, CharArray?) -> Unit,
    canNavigateMedia: Boolean,
    onPreviousMedia: () -> Unit,
    onNextMedia: () -> Unit,
    backgroundPlaylist: List<com.shovel.filemanager.media.BackgroundMediaItem> = emptyList(),
) {
    val context = LocalContext.current
    val summaryDateFormat = rememberLocalizedDateTimeFormat(DateFormat.SHORT, DateFormat.SHORT)
    val source = target.previewSource()
    var hash by remember(source.key) { mutableStateOf<String?>(null) }
    var hashRunning by remember { mutableStateOf(false) }
    var actionError by remember(source.key) { mutableStateOf<String?>(null) }
    var archivePath by remember(source.key) { mutableStateOf("") }
    var launchExternalEditorWhenReady by remember(source.key) { mutableStateOf(false) }
    var launchPdfSignerWhenReady by remember(source.key) { mutableStateOf(false) }
    var showPdfSigner by remember(source.key) { mutableStateOf(false) }
    var pdfApplyBaseline by remember(source.key) { mutableStateOf<String?>(null) }
    var showSaveAs by remember(source.key) { mutableStateOf(false) }
    var showDetails by remember(source.key) { mutableStateOf(false) }
    var confirmDelete by remember(source.key) { mutableStateOf(false) }
    var showSplitExtract by remember(source.key) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val archiveMaterializedEntry = target is PreviewTarget.ArchiveEntry
    val internalEditor = !archiveMaterializedEntry && EditabilityRules.supportsInternalText(source.name, source.mimeType(context), source.kind)
    val externalEditorAvailable = remember(source.key, archiveMaterializedEntry) {
        !archiveMaterializedEntry && canEditExternally(context, source)
    }
    val pdfSigningAvailable = remember(source.key, archiveMaterializedEntry) {
        !archiveMaterializedEntry && (source.extension == "pdf" || source.mimeType(context) == "application/pdf")
    }
    val activeEditState = editState.takeIf { it.sourceKey == source.key }
    val editSession = activeEditState?.session
    val actionSource = editSession
        ?.let { PreviewSource.Working(source, it) }
        ?: source
    val saveAsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        result.data?.data?.let(onSaveEditAs)
    }
    val externalEditorLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        onExternalEditorReturned()
    }
    val launchSystemSaveAs: () -> Unit = {
        val session = editSession
        if (session == null) {
            actionError = "The editable copy is not ready"
        } else {
            saveAsLauncher.launch(createSaveAsIntent(session))
        }
    }
    val launchSaveAs: () -> Unit = {
        if (editSession == null) actionError = "The editable copy is not ready"
        else showSaveAs = true
    }

    LaunchedEffect(source.key, internalEditor) {
        if (internalEditor) onPrepareEdit()
    }
    LaunchedEffect(
        launchExternalEditorWhenReady,
        editSession?.id,
        activeEditState?.preparing,
        activeEditState?.error,
    ) {
        if (!launchExternalEditorWhenReady) return@LaunchedEffect
        if (activeEditState?.error != null) {
            launchExternalEditorWhenReady = false
            return@LaunchedEffect
        }
        val session = editSession ?: return@LaunchedEffect
        launchExternalEditorWhenReady = false
        runCatching { externalEditorLauncher.launch(createExternalEditIntent(context, session)) }
            .onFailure { actionError = it.message ?: "Could not open the editor chooser" }
    }
    LaunchedEffect(
        launchPdfSignerWhenReady,
        editSession?.id,
        activeEditState?.preparing,
        activeEditState?.error,
    ) {
        if (!launchPdfSignerWhenReady) return@LaunchedEffect
        if (activeEditState?.error != null) {
            launchPdfSignerWhenReady = false
            return@LaunchedEffect
        }
        if (editSession == null) return@LaunchedEffect
        launchPdfSignerWhenReady = false
        showPdfSigner = true
    }
    LaunchedEffect(
        pdfApplyBaseline,
        activeEditState?.modifyingPdf,
        editSession?.workingRevision?.sha256,
        activeEditState?.error,
    ) {
        val baseline = pdfApplyBaseline ?: return@LaunchedEffect
        if (activeEditState?.modifyingPdf == true) return@LaunchedEffect
        if (activeEditState?.error == null && editSession?.workingRevision?.sha256 != baseline) {
            showPdfSigner = false
            pdfApplyBaseline = null
        }
    }
    val navigateBack: () -> Unit = {
        if (target is PreviewTarget.Archive && archivePath.isNotEmpty()) {
            archivePath = ArchiveBrowserIndex.parentOf(archivePath)
        } else {
            onClose()
        }
    }

    ShovelDialog(onDismissRequest = navigateBack, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        com.shovel.filemanager.ui.theme.AppearancePage(
            modifier = Modifier.fillMaxSize().testTag("file-preview-dialog"),
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp).testTag("preview_header"),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = navigateBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = uiText(if (archivePath.isEmpty()) "Close" else "Return to the previous archive folder"))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(editSession?.displayName ?: source.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(entrySummary(context, source, summaryDateFormat), style = MaterialTheme.typography.bodySmall,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (hashRunning) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    PreviewActionsMenu(
                        sourceKey = source.key,
                        editEnabled = activeEditState?.preparing != true && activeEditState?.saving != true && activeEditState?.modifyingPdf != true,
                        hashRunning = hashRunning,
                        onDetails = if (source.kind in setOf(EntryKind.IMAGE, EntryKind.AUDIO, EntryKind.VIDEO)) ({ showDetails = true }) else null,
                        onOpenWith = {
                            runCatching { openWith(context, actionSource) }
                                .onFailure { actionError = it.message ?: "Could not open the app chooser" }
                        },
                        onEditWith = if (!externalEditorAvailable) null else ({
                            if (editSession == null) {
                                launchExternalEditorWhenReady = true
                                onPrepareEdit()
                            } else {
                                runCatching { externalEditorLauncher.launch(createExternalEditIntent(context, editSession)) }
                                    .onFailure { actionError = it.message ?: "Could not open the editor chooser" }
                            }
                        }),
                        onSignPdf = if (!pdfSigningAvailable) null else ({
                            if (editSession == null) {
                                launchPdfSignerWhenReady = true
                                onPrepareEdit()
                            } else showPdfSigner = true
                        }),
                        onShare = {
                            runCatching { shareFile(context, actionSource) }
                                .onFailure { actionError = it.message ?: "Could not open the sharing app" }
                        },
                        onCalculateHash = {
                            hashRunning = true
                            scope.launch {
                                try {
                                    val result = withContext(Dispatchers.IO) { runCatching { sha256(context, actionSource) } }
                                    result.onSuccess { hash = it }.onFailure { actionError = it.message ?: "Could not calculate SHA-256" }
                                } finally {
                                    hashRunning = false
                                }
                            }
                        },
                        onDelete = onDelete?.let { action -> { confirmDelete = true } },
                    )
                }
                HorizontalDivider()
                BackgroundPlaybackBar(stopOnly = true)
                hash?.let {
                    LText("SHA-256  $it", modifier = Modifier.fillMaxWidth().padding(8.dp), style = MaterialTheme.typography.labelSmall)
                }
                actionError?.let {
                    LText(it, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                activeEditState?.let { state ->
                    FileEditActions(
                        state = state,
                        onSave = { onSaveEdit(false) },
                        onSaveAs = launchSaveAs,
                    )
                }

                when (target) {
                    is PreviewTarget.Archive -> ArchivePreview(
                        file = target.file,
                        entries = target.entries,
                        currentPath = archivePath,
                        onPathChanged = { archivePath = it },
                        onCopyEntry = onCopyArchiveEntry,
                        onCopyEntries = onCopyArchiveEntries,
                        onOpenEntry = onOpenArchiveEntry,
                        onShareEntries = onShareArchiveEntries,
                        onExtractEntries = onExtractArchiveEntries,
                        onRenameEntry = onRenameArchiveEntry,
                        onDeleteEntries = onDeleteArchiveEntries,
                        onMoveEntries = onMoveArchiveEntries,
                        onRefresh = onRefreshArchive,
                        loadThumbnail = loadArchiveThumbnail,
                        onExtract = onExtract,
                        initialExtractDirectory = target.file.file.parentFile?.absolutePath ?: initialLocalSavePath,
                        loadExtractDirectory = loadLocalSaveDirectory,
                        mutable = target.file.file.name.lowercase(Locale.ROOT).endsWith(".zip") && target.file.isWritable,
                        initialDisplayDefaults = archiveDisplayDefaults,
                        onApplyDisplayToAll = onApplyArchiveDisplayToAll,
                    )
                    is PreviewTarget.LocalFile,
                    is PreviewTarget.TrashFile,
                    is PreviewTarget.ContentFile,
                    is PreviewTarget.PrivilegedFile,
                    is PreviewTarget.ArchiveEntry,
                    -> FileContentPreview(
                        source = source,
                        editState = activeEditState,
                        onPrepareEdit = onPrepareEdit,
                        onEditTextChanged = onEditTextChanged,
                        onEditEncodingChanged = onEditEncodingChanged,
                        onEditLineEndingChanged = onEditLineEndingChanged,
                        onSave = { onSaveEdit(false) },
                        onSaveAs = launchSaveAs,
                        canNavigateMedia = canNavigateMedia,
                        onPreviousMedia = onPreviousMedia,
                        onNextMedia = onNextMedia,
                        onMinimizeMedia = onClose,
                        onExtractSplitApk = { showSplitExtract = true },
                        backgroundPlaylist = backgroundPlaylist,
                    )
                }
            }
        }
    }

    if (showDetails) MediaDetailsDialog(source, onDismiss = { showDetails = false })
    if (showSplitExtract) {
        val file = source.localFile
        if (file != null) ArchiveExtractionDialog(
            archiveName = source.name, selection = null, initialDirectory = initialLocalSavePath,
            loadDirectory = loadLocalSaveDirectory,
            onDismiss = { showSplitExtract = false },
            onConfirm = { directory, password ->
                showSplitExtract = false
                onExtract(FileEntry(file.path, source.name, EntryKind.APK, source.sizeBytes ?: 0L,
                    source.modifiedAtMillis ?: 0L, false, source.isReadable, source.isWritable), directory, password)
            },
        )
    }

    activeEditState?.conflict?.let { conflict ->
        EditConflictDialog(
            conflict = conflict,
            workingRevision = editSession?.workingRevision ?: conflict.expected,
            saving = activeEditState.saving,
            canMerge = false,
            onMerge = {},
            onOverwrite = { onSaveEdit(true) },
            onSaveAs = launchSaveAs,
            onKeepEditing = onDismissEditConflict,
        )
    }
    activeEditState?.saveAsConflict?.let { conflict ->
        EditSaveAsConflictDialog(
            conflict = conflict,
            saving = activeEditState.saving,
            onReplace = { onResolveSaveAsConflict(EditExistingPolicy.REPLACE) },
            onKeepBoth = { onResolveSaveAsConflict(EditExistingPolicy.KEEP_BOTH) },
            onChooseAnother = {
                onDismissSaveAsConflict()
                showSaveAs = true
            },
            onDismiss = onDismissSaveAsConflict,
        )
    }
    if (showSaveAs && editSession != null) {
        EditSaveAsDialog(
            initialFileName = editSession.displayName,
            initialLocalPath = if (target is PreviewTarget.LocalFile) {
                (editSession.origin as? EditOrigin.Local)
                    ?.path
                    ?.let(::File)
                    ?.parentFile
                    ?.absolutePath
                    ?: initialLocalSavePath
            } else {
                initialLocalSavePath
            },
            loadLocalDirectory = loadLocalSaveDirectory,
            onSaveLocal = { directory, name ->
                showSaveAs = false
                onSaveEditAsLocal(directory, name)
            },
            onOpenSystemPicker = {
                showSaveAs = false
                launchSystemSaveAs()
            },
            onDismiss = { showSaveAs = false },
        )
    }
    if (showPdfSigner && editSession != null) {
        PdfSignatureDialog(
            source = PreviewSource.Working(source, editSession),
            applying = activeEditState.modifyingPdf,
            error = activeEditState.error,
            signatureLibrary = signatureLibrary,
            onRefreshSignatureLibrary = onRefreshSignatureLibrary,
            onSaveSignature = onSaveSignature,
            onDeleteSavedSignature = onDeleteSavedSignature,
            onApply = { drawing, placement ->
                pdfApplyBaseline = editSession.workingRevision.sha256
                onApplyPdfSignature(drawing, placement)
            },
            onDismiss = {
                if (!activeEditState.modifyingPdf) {
                    showPdfSigner = false
                    pdfApplyBaseline = null
                }
            },
        )
    }
    if (confirmDelete && onDelete != null) {
        val permanent = target is PreviewTarget.TrashFile ||
            target is PreviewTarget.ContentFile ||
            (target is PreviewTarget.PrivilegedFile && !target.localOrigin)
        val explanation = when (target) {
            is PreviewTarget.ContentFile -> "The item will be deleted through Android's document provider and will not enter Shovel Trash."
            is PreviewTarget.PrivilegedFile -> if (target.localOrigin) "Items can be restored from Shovel Trash."
                else "These protected files cannot be restored from Shovel Trash."
            is PreviewTarget.TrashFile -> "The item can no longer be restored from the app Trash."
            else -> "Items can be restored from Shovel Trash."
        }
        DeleteConfirmationDialog(
            names = listOf(source.name),
            permanent = permanent,
            title = if (permanent) "Delete permanently?" else "Move to trash?",
            onDismiss = { confirmDelete = false },
            onConfirm = {
                confirmDelete = false
                onDelete()
            },
            explanation = explanation,
            fallbackFiles = 1,
            fallbackBytes = source.sizeBytes ?: 0L,
            confirmTestTag = "preview_confirm_delete",
        )
    }
    if (activeEditState?.confirmDiscard == true) {
        AlertDialog(
            onDismissRequest = onKeepEditing,
            title = { LText("Discard unsaved changes?") },
            text = { LText("The editable copy has changes that have not been saved anywhere. The original file has not been modified.") },
            confirmButton = {
                Button(onClick = onDiscardEditAndClose, modifier = Modifier.testTag("discard-edit-confirm")) {
                    LText("Discard changes")
                }
            },
            dismissButton = {
                TextButton(onClick = onKeepEditing) { LText("Keep editing") }
            },
        )
    }
}

@Composable
private fun FileContentPreview(
    source: PreviewSource,
    editState: FileEditUiState?,
    onPrepareEdit: () -> Unit,
    onEditTextChanged: (String) -> Unit,
    onEditEncodingChanged: (TextEncoding) -> Unit,
    onEditLineEndingChanged: (LineEnding) -> Unit,
    onSave: () -> Unit,
    onSaveAs: () -> Unit,
    canNavigateMedia: Boolean,
    onPreviousMedia: () -> Unit,
    onNextMedia: () -> Unit,
    onMinimizeMedia: () -> Unit,
    onExtractSplitApk: () -> Unit,
    backgroundPlaylist: List<com.shovel.filemanager.media.BackgroundMediaItem>,
) {
    val context = LocalContext.current
    val displayedSource = editState?.session
        ?.takeIf { it.sourceKey == source.key }
        ?.let { PreviewSource.Working(source, it) }
        ?: source
    when {
        source.kind == EntryKind.IMAGE -> ImagePreview(displayedSource, canNavigateMedia, onPreviousMedia, onNextMedia)
        source.extension == "pdf" || source.mimeType(context) == "application/pdf" -> PdfPreview(displayedSource)
        source.kind == EntryKind.VIDEO || source.kind == EntryKind.AUDIO -> MediaPreview(
            displayedSource,
            canNavigateMedia,
            onPreviousMedia,
            onNextMedia,
            onMinimizeMedia,
            backgroundPlaylist,
        )
        source.kind == EntryKind.APK && source.localFile != null -> {
            val file = requireNotNull(source.localFile)
            if (com.shovel.filemanager.apk.SplitApkArchive.isBundle(file)) SplitApkPreview(file, onExtractSplitApk)
            else ApkPreview(file)
        }
        EditabilityRules.supportsInternalText(source.name, source.mimeType(context), source.kind) -> TextPreview(
            state = editState,
            onPrepareEdit = onPrepareEdit,
            onTextChanged = onEditTextChanged,
            onEncodingChanged = onEditEncodingChanged,
            onLineEndingChanged = onEditLineEndingChanged,
            onSave = onSave,
            onSaveAs = onSaveAs,
        )
        else -> PropertiesPreview(displayedSource)
    }
}

@Composable
internal fun ImagePreview(source: PreviewSource, canNavigate: Boolean, onPrevious: () -> Unit, onNext: () -> Unit) {
    val context = LocalContext.current
    val result by produceState<Result<DecodedPreviewImage>?>(initialValue = null, source.key) {
        value = withContext(Dispatchers.IO) { runCatching { decodePreviewImage(context, source) } }
    }
    var scale by remember(source.key) { mutableFloatStateOf(PreviewZoomRules.MIN_SCALE) }
    var offset by remember(source.key) { mutableStateOf(Offset.Zero) }
    var viewportSize by remember(source.key) { mutableStateOf(IntSize.Zero) }
    val currentScale by rememberUpdatedState(scale)
    @Suppress("DEPRECATION")
    val transformState = rememberTransformableState { zoomChange, panChange, _ ->
        val nextScale = PreviewZoomRules.clamp(scale * zoomChange, PreviewZoomRules.IMAGE_MAX_SCALE)
        scale = nextScale
        offset = if (nextScale <= PreviewZoomRules.MIN_SCALE) Offset.Zero
        else boundedOffset(offset + panChange, viewportSize, nextScale)
    }
    val updateScale: (Float) -> Unit = { requested ->
        scale = PreviewZoomRules.clamp(requested, PreviewZoomRules.IMAGE_MAX_SCALE)
        offset = if (scale <= PreviewZoomRules.MIN_SCALE) Offset.Zero else boundedOffset(offset, viewportSize, scale)
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        ZoomControls(scale, PreviewZoomRules.IMAGE_MAX_SCALE, updateScale)
        when (val loaded = result) {
            null -> CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
            else -> {
                val decoded = loaded.getOrNull()
                if (decoded != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clipToBounds()
                            .background(MaterialTheme.colorScheme.surfaceContainer)
                            .testTag("image-zoom-viewport")
                            .onSizeChanged { viewportSize = it }
                            .pointerInput(source.key, canNavigate) {
                                awaitEachGesture {
                                    val first = awaitFirstDown(requireUnconsumed = false)
                                    var last = first.position
                                    var single = true
                                    var unconsumed = true
                                    do {
                                        val event = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Final)
                                        if (event.changes.size != 1) single = false
                                        // Tap/double-tap consumes release even for an abandoned tap.
                                        // Only consumed movement belongs to another pan/zoom gesture.
                                        if (event.changes.any { it.pressed && it.position != it.previousPosition && it.isConsumed }) unconsumed = false
                                        event.changes.firstOrNull { it.id == first.id }?.let { last = it.position }
                                    } while (event.changes.any { it.pressed })
                                    val movement = last - first.position
                                    if (canNavigate && single && unconsumed && currentScale <= PreviewZoomRules.MIN_SCALE &&
                                        kotlin.math.abs(movement.x) > maxOf(48.dp.toPx(), size.width * .18f) &&
                                        kotlin.math.abs(movement.y) < kotlin.math.abs(movement.x) * .6f) {
                                        if (movement.x < 0) onNext() else onPrevious()
                                    }
                                }
                            }
                            .pointerInput(source.key) {
                                detectTapGestures(
                                    onDoubleTap = {
                                        updateScale(if (currentScale > PreviewZoomRules.MIN_SCALE) PreviewZoomRules.MIN_SCALE else 2f)
                                    },
                                )
                            }
                            .transformable(
                                state = transformState,
                                canPan = { scale > PreviewZoomRules.MIN_SCALE },
                                lockRotationOnZoomPan = true,
                            ),
                    ) {
                        val imageModifier = Modifier.fillMaxSize().graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        }
                        when (decoded) {
                            is DecodedPreviewImage.Still -> Image(
                                bitmap = decoded.bitmap.asImageBitmap(),
                                contentDescription = source.name,
                                modifier = imageModifier,
                                contentScale = ContentScale.Fit,
                            )
                            is DecodedPreviewImage.DrawableImage -> {
                                DisposableEffect(decoded.drawable) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                                        decoded.drawable is AnimatedImageDrawable) decoded.drawable.start()
                                    onDispose {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
                                            decoded.drawable is AnimatedImageDrawable) decoded.drawable.stop()
                                    }
                                }
                                AndroidView(
                                    factory = { viewContext -> ImageView(viewContext).apply {
                                        scaleType = ImageView.ScaleType.FIT_CENTER
                                        contentDescription = source.name
                                        setImageDrawable(decoded.drawable)
                                    } },
                                    update = { image -> if (image.drawable !== decoded.drawable) image.setImageDrawable(decoded.drawable) },
                                    modifier = imageModifier.testTag("animated_image_preview"),
                                )
                            }
                        }
                    }
                } else {
                    PreviewLoadError(requireNotNull(loaded.exceptionOrNull()))
                }
            }
        }
    }
}

@Composable
private fun PdfPreview(source: PreviewSource) {
    val context = LocalContext.current
    val documentInfoResult by produceState<Result<PdfDocumentInfo>?>(initialValue = null, source.key) {
        value = withContext(Dispatchers.IO) { runCatching { pdfDocumentInfo(context, source) } }
    }
    var scale by remember(source.key) { mutableFloatStateOf(PreviewZoomRules.MIN_SCALE) }
    var renderScale by remember(source.key) { mutableFloatStateOf(PreviewZoomRules.MIN_SCALE) }
    val horizontalScroll = rememberScrollState()
    val listState = rememberLazyListState()
    val pinchAnchor = remember(source.key) { PdfPinchAnchor() }
    val zoomScrollRequests = remember(source.key) {
        MutableSharedFlow<PdfZoomScrollRequest>(
            extraBufferCapacity = 1,
            onBufferOverflow = BufferOverflow.DROP_OLDEST,
        )
    }
    val selectionRequests = remember(source.key) {
        Channel<PdfSelectionRequest>(Channel.CONFLATED)
    }
    DisposableEffect(selectionRequests) { onDispose { selectionRequests.close() } }
    val directSelectionSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM
    val selectionFailureText = uiText("Could not read the PDF")
    val copiedText = uiText("Copied")
    var directSelection by remember(source.key) { mutableStateOf<PdfPageTextSelection?>(null) }
    var selectionPendingPage by remember(source.key) { mutableStateOf<Int?>(null) }
    var selectionRevision by remember(source.key) { mutableLongStateOf(0L) }
    var textSelectionPage by remember(source.key) { mutableStateOf<Int?>(null) }
    val updateScale: (Float) -> Unit = { scale = PreviewZoomRules.clamp(it, PreviewZoomRules.PDF_MAX_SCALE) }
    LaunchedEffect(source.key) {
        zoomScrollRequests.collectLatest { request ->
            // Anchor the page during the scale remeasure. Scrolling the old layout first can
            // clamp against the old page height and move the point between the fingers.
            val verticalOffset = request.vertical.toInt()
            listState.requestScrollToItem(request.pageIndex, verticalOffset.coerceAtLeast(0))
            withFrameNanos { }
            if (verticalOffset < 0) listState.scrollBy(verticalOffset.toFloat())
            horizontalScroll.scrollTo(request.horizontal.toInt().coerceAtLeast(0))
        }
    }
    LaunchedEffect(scale) {
        if (scale <= PreviewZoomRules.MIN_SCALE) horizontalScroll.scrollTo(0)
        delay(140)
        renderScale = scale
    }
    LaunchedEffect(source.key, directSelectionSupported) {
        if (!directSelectionSupported) return@LaunchedEffect
        selectionRequests.receiveAsFlow().collectLatest { request ->
            if (request.showProgress) selectionPendingPage = request.pageIndex
            try {
                val selected = pdfRenderPermits.withPermit {
                    runInterruptible(Dispatchers.IO) {
                        selectPdfPageText(
                            context = context,
                            source = source,
                            pageIndex = request.pageIndex,
                            start = request.start,
                            stop = request.stop,
                        )
                    }
                }
                if (selected != null || request.clearOnEmpty) directSelection = selected
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
                Toast.makeText(context, selectionFailureText, Toast.LENGTH_SHORT).show()
            } finally {
                if (request.showProgress && selectionPendingPage == request.pageIndex) {
                    selectionPendingPage = null
                }
                selectionRevision++
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        ZoomControls(
            scale = scale,
            maximum = PreviewZoomRules.PDF_MAX_SCALE,
            onScaleChanged = updateScale,
            onSelectText = if (directSelectionSupported) null else ({
                val pageCount = documentInfoResult?.getOrNull()?.pageCount ?: 0
                if (pageCount > 0) {
                    val layout = listState.layoutInfo
                    val visiblePages = layout.visibleItemsInfo.map { item ->
                        PdfVisiblePage(index = item.index, offset = item.offset, size = item.size)
                    }
                    textSelectionPage = if (visiblePages.isEmpty()) {
                        listState.firstVisibleItemIndex
                    } else {
                        PdfTextRules.pageClosestToViewportCenter(
                            visiblePages = visiblePages,
                            viewportStart = layout.viewportStartOffset,
                            viewportEnd = layout.viewportEndOffset,
                        )
                    }.coerceIn(0, pageCount - 1)
                }
            }),
            onCopySelectedText = directSelection?.let { selected ->
                {
                    context.getSystemService(ClipboardManager::class.java)
                        .setPrimaryClip(ClipData.newPlainText(source.name, selected.text))
                    Toast.makeText(context, copiedText, Toast.LENGTH_SHORT).show()
                }
            },
            onClearSelectedText = directSelection?.let { { directSelection = null } },
        )
        when (val loaded = documentInfoResult) {
            null -> CircularProgressIndicator()
            else -> {
                val documentInfo = loaded.getOrNull()
                if (documentInfo == null) {
                    PreviewLoadError(requireNotNull(loaded.exceptionOrNull()))
                } else {
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxSize()
                            .clipToBounds()
                            .testTag("pdf-zoom-viewport")
                            .then(
                                if (BuildConfig.DEBUG) Modifier.semantics {
                                    this[PdfViewportSemanticsKey] = PdfViewportSnapshot(
                                        scale = scale,
                                        horizontalScroll = horizontalScroll.value,
                                        pageIndex = listState.firstVisibleItemIndex,
                                        verticalScroll = listState.firstVisibleItemScrollOffset,
                                        visiblePages = listState.layoutInfo.visibleItemsInfo.map { item ->
                                            PdfVisiblePage(index = item.index, offset = item.offset, size = item.size)
                                        },
                                    )
                                } else Modifier,
                            )
                            .pointerInput(source.key) {
                                awaitEachGesture {
                                    awaitFirstDown(requireUnconsumed = false)
                                    pinchAnchor.active = false
                                    var gestureScale = scale
                                    var pointersPressed = true
                                    while (pointersPressed) {
                                        val event = awaitPointerEvent(PointerEventPass.Initial)
                                        val pressedPointers = event.changes.count { it.pressed }
                                        val stablePinchPointers = event.changes.count {
                                            it.pressed && it.previousPressed
                                        }
                                        if (stablePinchPointers >= 2) {
                                            val centroid = event.calculateCentroid(useCurrent = true)
                                            if (centroid.x.isFinite() && centroid.y.isFinite()) {
                                                if (!pinchAnchor.active) {
                                                    val previousCentroid = event.calculateCentroid(useCurrent = false)
                                                    val anchorCentroid = if (
                                                        previousCentroid.x.isFinite() && previousCentroid.y.isFinite()
                                                    ) previousCentroid else centroid
                                                    pinchAnchor.active = true
                                                    gestureScale = scale
                                                    val anchorPage = PdfTextRules.pageAtViewportPosition(
                                                        visiblePages = listState.layoutInfo.visibleItemsInfo.map { item ->
                                                            PdfVisiblePage(
                                                                index = item.index,
                                                                offset = item.offset,
                                                                size = item.size,
                                                            )
                                                        },
                                                        position = anchorCentroid.y,
                                                    )
                                                    pinchAnchor.pageIndex = anchorPage.index
                                                    pinchAnchor.documentX =
                                                        (horizontalScroll.value + anchorCentroid.x) / gestureScale
                                                    pinchAnchor.documentY =
                                                        (anchorCentroid.y - anchorPage.offset)
                                                            .coerceIn(0f, anchorPage.size.toFloat()) / gestureScale
                                                }
                                                val nextScale = PreviewZoomRules.clamp(
                                                    gestureScale * event.calculateZoom(),
                                                    PreviewZoomRules.PDF_MAX_SCALE,
                                                )
                                                if (nextScale != gestureScale) {
                                                    gestureScale = nextScale
                                                    scale = nextScale
                                                    zoomScrollRequests.tryEmit(
                                                        PdfZoomScrollRequest(
                                                            horizontal = pinchAnchor.documentX * nextScale - centroid.x,
                                                            pageIndex = pinchAnchor.pageIndex,
                                                            vertical = pinchAnchor.documentY * nextScale - centroid.y,
                                                        ),
                                                    )
                                                }
                                                event.changes.forEach { change -> change.consume() }
                                            }
                                        } else if (pressedPointers < 2) {
                                            pinchAnchor.active = false
                                        }
                                        pointersPressed = event.changes.any { it.pressed }
                                    }
                                    pinchAnchor.active = false
                                }
                            },
                    ) {
                        val viewportWidthPx = with(LocalDensity.current) { maxWidth.roundToPx().coerceAtLeast(1) }
                        val contentWidth = maxWidth * scale
                        Row(modifier = Modifier.fillMaxSize().horizontalScroll(horizontalScroll)) {
                            LazyColumn(
                                state = listState,
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .width(contentWidth)
                                    .testTag("pdf-continuous-pages"),
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                items(count = documentInfo.pageCount, key = { it }) { pageIndex ->
                                    PdfPageItem(
                                        context = context,
                                        source = source,
                                        pageIndex = pageIndex,
                                        pageSize = documentInfo.pages[pageIndex],
                                        viewportWidthPx = viewportWidthPx,
                                        renderScale = renderScale,
                                        directSelectionEnabled = directSelectionSupported,
                                        selection = directSelection?.takeIf { it.pageIndex == pageIndex },
                                        selectionPending = selectionPendingPage == pageIndex,
                                        selectionRevision = selectionRevision,
                                        onSelectWord = { point ->
                                            directSelection = null
                                            selectionRequests.trySend(
                                                PdfSelectionRequest(
                                                    pageIndex = pageIndex,
                                                    start = PdfTextBoundary.AtPoint(point),
                                                    stop = PdfTextBoundary.AtPoint(point),
                                                    clearOnEmpty = true,
                                                    showProgress = true,
                                                ),
                                            )
                                        },
                                        onMoveSelectionBoundary = { start, stop ->
                                            selectionRequests.trySend(
                                                PdfSelectionRequest(
                                                    pageIndex = pageIndex,
                                                    start = start,
                                                    stop = stop,
                                                    clearOnEmpty = false,
                                                    showProgress = false,
                                                ),
                                            )
                                        },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    textSelectionPage?.let { pageIndex ->
        PdfTextSelectionDialog(
            source = source,
            pageIndex = pageIndex,
            onDismiss = { textSelectionPage = null },
        )
    }
}

internal sealed interface DecodedPreviewImage {
    data class Still(val bitmap: Bitmap) : DecodedPreviewImage
    data class DrawableImage(val drawable: Drawable) : DecodedPreviewImage
}

internal fun decodePreviewImage(context: android.content.Context, source: PreviewSource): DecodedPreviewImage {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
        source.extension.lowercase(java.util.Locale.ROOT) in setOf("gif", "webp", "apng")) {
        runCatching {
            val imageSource = source.localFile?.let { ImageDecoder.createSource(it) }
                ?: ImageDecoder.createSource(context.contentResolver, source.uri(context))
            ImageDecoder.decodeDrawable(imageSource) { decoder, info, _ ->
                var sample = 1
                while (info.size.width / sample > 2_048 || info.size.height / sample > 2_048) sample *= 2
                decoder.setTargetSampleSize(sample)
            }
        }.getOrNull()?.let { return DecodedPreviewImage.DrawableImage(it) }
    }
    return DecodedPreviewImage.Still(decodeBoundedBitmap(context, source))
}

@Composable
private fun PdfPageItem(
    context: android.content.Context,
    source: PreviewSource,
    pageIndex: Int,
    pageSize: PdfPageSize,
    viewportWidthPx: Int,
    renderScale: Float,
    directSelectionEnabled: Boolean,
    selection: PdfPageTextSelection?,
    selectionPending: Boolean,
    selectionRevision: Long,
    onSelectWord: (PdfPagePoint) -> Unit,
    onMoveSelectionBoundary: (PdfTextBoundary, PdfTextBoundary) -> Unit,
) {
    var bitmap by remember(source.key, pageIndex) { mutableStateOf<Bitmap?>(null) }
    var renderError by remember(source.key, pageIndex) { mutableStateOf<Throwable?>(null) }
    var rendering by remember(source.key, pageIndex) { mutableStateOf(true) }
    var displaySize by remember(source.key, pageIndex) { mutableStateOf(IntSize.Zero) }
    var dragPreview by remember(source.key, pageIndex) { mutableStateOf<PdfSelectionDragPreview?>(null) }
    val currentSelection by rememberUpdatedState(selection)
    val currentMoveSelectionBoundary by rememberUpdatedState(onMoveSelectionBoundary)
    val handleHitRadius = with(LocalDensity.current) { 28.dp.toPx() }
    val handleRadius = with(LocalDensity.current) { 7.dp.toPx() }
    val handleStem = with(LocalDensity.current) { 10.dp.toPx() }
    val selectionColor = MaterialTheme.colorScheme.primary
    val selectionHighlight = selectionColor.copy(alpha = 0.28f)
    LaunchedEffect(selectionRevision) { dragPreview = null }
    val selectionSnapshot = selection?.takeIf { displaySize.width > 0 && displaySize.height > 0 }?.let { selected ->
        val measured = PdfDisplaySize(displaySize.width.toFloat(), displaySize.height.toFloat())
        val preview = dragPreview
        PdfTextSelectionSnapshot(
            text = selected.text,
            boundsCount = selected.bounds.size,
            startHandle = PdfSelectionRules.displayPoint(
                preview?.point?.takeIf { preview.handle == PdfSelectionHandle.START } ?: selected.startHandle,
                measured,
                pageSize,
            ),
            stopHandle = PdfSelectionRules.displayPoint(
                preview?.point?.takeIf { preview.handle == PdfSelectionHandle.STOP } ?: selected.stopHandle,
                measured,
                pageSize,
            ),
        )
    }
    LaunchedEffect(source.key, pageIndex, viewportWidthPx, renderScale) {
        rendering = true
        val result = withContext(Dispatchers.IO) {
            runCatching {
                pdfRenderPermits.withPermit {
                    renderPdfPage(context, source, pageIndex, viewportWidthPx, renderScale)
                }
            }
        }
        result.onSuccess {
            bitmap = it
            renderError = null
        }.onFailure { renderError = it }
        rendering = false
    }
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 2.dp,
    ) {
        when (val loadedBitmap = bitmap) {
            null -> if (renderError == null || rendering) Box(
                modifier = Modifier.fillMaxWidth().aspectRatio(pageSize.aspectRatio),
                contentAlignment = Alignment.Center,
            ) { CircularProgressIndicator() } else PreviewLoadError(requireNotNull(renderError))
            else -> Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(loadedBitmap.width.toFloat() / loadedBitmap.height)
                    .onSizeChanged { displaySize = it }
                    .then(
                        if (directSelectionEnabled) Modifier.pointerInput(source.key, pageIndex, pageSize, handleHitRadius) {
                            awaitEachGesture {
                                val down = awaitFirstDown(
                                    requireUnconsumed = false,
                                    pass = PointerEventPass.Initial,
                                )
                                val selected = currentSelection
                                if (selected?.pageIndex != pageIndex || size.width <= 0 || size.height <= 0) {
                                    return@awaitEachGesture
                                }
                                val measured = PdfDisplaySize(size.width.toFloat(), size.height.toFloat())
                                val startHandle = PdfSelectionRules.displayPoint(selected.startHandle, measured, pageSize)
                                val stopHandle = PdfSelectionRules.displayPoint(selected.stopHandle, measured, pageSize)
                                val handle = PdfSelectionRules.handleAt(
                                    touch = PdfDisplayPoint(down.position.x, down.position.y),
                                    start = startHandle,
                                    stop = stopHandle,
                                    hitRadius = handleHitRadius,
                                ) ?: return@awaitEachGesture
                                val fixedBoundary = if (handle == PdfSelectionHandle.START) {
                                    PdfTextBoundary.AtPoint(selected.stopHandle)
                                } else {
                                    PdfTextBoundary.AtPoint(selected.startHandle)
                                }
                                down.consume()
                                var movingPoint: PdfPagePoint? = null
                                var commitSelection = false
                                while (true) {
                                    val event = awaitPointerEvent(PointerEventPass.Initial)
                                    if (event.changes.count { it.pressed } > 1) {
                                        dragPreview = null
                                        break
                                    }
                                    val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                    if (!change.pressed) {
                                        change.consume()
                                        commitSelection = movingPoint != null
                                        break
                                    }
                                    movingPoint = PdfSelectionRules.pagePoint(
                                        displayPoint = PdfDisplayPoint(change.position.x, change.position.y),
                                        displaySize = measured,
                                        pageSize = pageSize,
                                    )
                                    dragPreview = PdfSelectionDragPreview(handle, movingPoint)
                                    change.consume()
                                }
                                if (commitSelection) movingPoint?.let { finalPoint ->
                                    if (handle == PdfSelectionHandle.START) {
                                        currentMoveSelectionBoundary(PdfTextBoundary.AtPoint(finalPoint), fixedBoundary)
                                    } else {
                                        currentMoveSelectionBoundary(fixedBoundary, PdfTextBoundary.AtPoint(finalPoint))
                                    }
                                }
                            }
                        } else Modifier,
                    )
                    .then(
                        if (directSelectionEnabled) Modifier.pointerInput(source.key, pageIndex, pageSize) {
                            detectTapGestures(
                                onLongPress = { position ->
                                    if (size.width > 0 && size.height > 0) {
                                        onSelectWord(
                                            PdfSelectionRules.pagePoint(
                                                displayPoint = PdfDisplayPoint(position.x, position.y),
                                                displaySize = PdfDisplaySize(size.width.toFloat(), size.height.toFloat()),
                                                pageSize = pageSize,
                                            ),
                                        )
                                    }
                                },
                            )
                        } else Modifier,
                    )
                    .then(
                        if (BuildConfig.DEBUG && selectionSnapshot != null) Modifier.semantics {
                            this[PdfTextSelectionSemanticsKey] = selectionSnapshot
                        } else Modifier,
                    )
                    .testTag("pdf-page-$pageIndex"),
            ) {
                Image(
                    bitmap = loadedBitmap.asImageBitmap(),
                    contentDescription = uiText("PDF page ${pageIndex + 1}"),
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit,
                )
                selection?.let { selected ->
                    Canvas(modifier = Modifier.fillMaxSize().testTag("pdf-selection-highlight-$pageIndex")) {
                        val xScale = size.width / pageSize.width
                        val yScale = size.height / pageSize.height
                        selected.bounds.forEach { bounds ->
                            drawRect(
                                color = selectionHighlight,
                                topLeft = Offset(bounds.left * xScale, bounds.top * yScale),
                                size = Size(
                                    (bounds.right - bounds.left) * xScale,
                                    (bounds.bottom - bounds.top) * yScale,
                                ),
                            )
                        }
                        val preview = dragPreview
                        val startPoint = preview?.point
                            ?.takeIf { preview.handle == PdfSelectionHandle.START }
                            ?: selected.startHandle
                        val stopPoint = preview?.point
                            ?.takeIf { preview.handle == PdfSelectionHandle.STOP }
                            ?: selected.stopHandle
                        val start = Offset(startPoint.x * xScale, startPoint.y * yScale)
                        val stop = Offset(stopPoint.x * xScale, stopPoint.y * yScale)
                        val startKnob = start + Offset(0f, handleStem)
                        val stopKnob = stop + Offset(0f, handleStem)
                        drawLine(selectionColor, start, startKnob, strokeWidth = 3f)
                        drawLine(selectionColor, stop, stopKnob, strokeWidth = 3f)
                        drawCircle(selectionColor, radius = handleRadius, center = startKnob)
                        drawCircle(selectionColor, radius = handleRadius, center = stopKnob)
                    }
                }
                if (selectionPending) {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center).size(28.dp).testTag("pdf-selection-loading-$pageIndex"),
                        strokeWidth = 2.dp,
                    )
                }
            }
        }
    }
}

@Composable
private fun ZoomControls(
    scale: Float,
    maximum: Float,
    onScaleChanged: (Float) -> Unit,
    onSelectText: (() -> Unit)? = null,
    onCopySelectedText: (() -> Unit)? = null,
    onClearSelectedText: (() -> Unit)? = null,
) {
    val zoomOutDescription = uiText("Zoom out")
    val zoomInDescription = uiText("Zoom in")
    FlowRow(
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        itemVerticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(
            onClick = { onScaleChanged(PreviewZoomRules.zoomOut(scale, maximum)) },
            enabled = scale > PreviewZoomRules.MIN_SCALE,
            modifier = Modifier.semantics { contentDescription = zoomOutDescription },
        ) { LText("−", style = MaterialTheme.typography.headlineSmall) }
        LText(
            "${PreviewZoomRules.percent(scale)} %",
            modifier = Modifier.padding(horizontal = 12.dp).testTag("zoom-level"),
            style = MaterialTheme.typography.labelLarge,
        )
        IconButton(
            onClick = { onScaleChanged(PreviewZoomRules.zoomIn(scale, maximum)) },
            enabled = scale < maximum,
            modifier = Modifier.semantics { contentDescription = zoomInDescription },
        ) { LText("+", style = MaterialTheme.typography.headlineSmall) }
        TextButton(onClick = { onScaleChanged(PreviewZoomRules.MIN_SCALE) }, enabled = scale > PreviewZoomRules.MIN_SCALE) {
            LText("Reset")
        }
        onSelectText?.let { selectText ->
            IconButton(
                onClick = selectText,
                modifier = Modifier.testTag("pdf-select-text"),
            ) {
                Icon(
                    Icons.Rounded.ContentCopy,
                    contentDescription = uiText("Copy selected text"),
                )
            }
        }
        onCopySelectedText?.let { copySelectedText ->
            IconButton(
                onClick = copySelectedText,
                modifier = Modifier.testTag("pdf-copy-selection"),
            ) {
                Icon(
                    Icons.Rounded.ContentCopy,
                    contentDescription = uiText("Copy selected text"),
                )
            }
        }
        onClearSelectedText?.let { clearSelectedText ->
            IconButton(
                onClick = clearSelectedText,
                modifier = Modifier.testTag("pdf-clear-selection"),
            ) {
                Icon(Icons.Rounded.Close, contentDescription = uiText("Clear"))
            }
        }
    }
}

@Composable
private fun PdfTextSelectionDialog(
    source: PreviewSource,
    pageIndex: Int,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val textColor = MaterialTheme.colorScheme.onSurface.toArgb()
    val result by produceState<Result<String>?>(initialValue = null, source.key, pageIndex) {
        value = runCatching {
            pdfRenderPermits.withPermit {
                runInterruptible(Dispatchers.IO) { extractPdfPageText(context, source, pageIndex) }
            }
        }
    }
    ShovelModalDialog(
        title = "PDF page ${pageIndex + 1}",
        subtitle = "Copy selected text",
        icon = Icons.Rounded.ContentCopy,
        onDismissRequest = onDismiss,
        expandedContent = true,
        modifier = Modifier.testTag("pdf-text-selection-dialog"),
        actions = {
            TextButton(onClick = onDismiss, modifier = Modifier.testTag("pdf-text-close")) {
                LText("Close")
            }
        },
    ) {
        when (val loaded = result) {
            null -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            else -> loaded.fold(
                onSuccess = { text ->
                    if (text.isBlank()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            LText("No matches found")
                        }
                    } else {
                        AndroidView(
                            factory = { viewContext ->
                                TextView(viewContext).apply {
                                    tag = "pdf-selectable-text-view"
                                    setTextIsSelectable(true)
                                    isVerticalScrollBarEnabled = true
                                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
                                    setPadding(24, 20, 24, 20)
                                }
                            },
                            update = { view ->
                                view.text = text
                                view.setTextColor(textColor)
                            },
                            modifier = Modifier.fillMaxSize().testTag("pdf-selectable-text"),
                        )
                    }
                },
                onFailure = { PreviewLoadError(it) },
            )
        }
    }
}

@Composable
internal fun PreviewLoadError(error: Throwable) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(Icons.Rounded.Description, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.error)
        LText("Could not create the file preview", style = MaterialTheme.typography.titleMedium)
        error.message?.takeIf(String::isNotBlank)?.let {
            LText(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MediaPreview(
    source: PreviewSource,
    canNavigateMedia: Boolean,
    onPreviousMedia: () -> Unit,
    onNextMedia: () -> Unit,
    onMinimizeMedia: () -> Unit,
    backgroundPlaylist: List<com.shovel.filemanager.media.BackgroundMediaItem>,
) {
    val context = LocalContext.current
    val infoResult by produceState<Result<MediaPreviewInfo>?>(initialValue = null, source.key) {
        value = withContext(Dispatchers.IO) { runCatching { mediaPreviewInfo(context, source) } }
    }
    when (val loaded = infoResult) {
        null -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else -> {
            val info = loaded.getOrNull()
            if (info == null) {
                PreviewLoadError(requireNotNull(loaded.exceptionOrNull()))
            } else if (source.kind == EntryKind.AUDIO) {
                androidx.compose.runtime.key(source.key) {
                AudioPreview(source, info, canNavigateMedia, onPreviousMedia, onNextMedia, onMinimizeMedia, backgroundPlaylist)
                }
            } else {
                androidx.compose.runtime.key(source.key) {
                VideoPreview(source, info, canNavigateMedia, onPreviousMedia, onNextMedia, backgroundPlaylist)
                }
            }
        }
    }
}

@Composable
private fun AudioPreview(
    source: PreviewSource,
    info: MediaPreviewInfo,
    canNavigateMedia: Boolean,
    onPreviousMedia: () -> Unit,
    onNextMedia: () -> Unit,
    onMinimizeMedia: () -> Unit,
    backgroundPlaylist: List<com.shovel.filemanager.media.BackgroundMediaItem>,
) {
    val context = LocalContext.current
    val background by BackgroundPlaybackService.state.collectAsStateWithLifecycle()
    val sourceUri = remember(source.key) { runCatching { source.uri(context).toString() }.getOrNull() }
    val playingInBackground = background?.let { it.active && it.uri == sourceUri } == true
    var player by remember(source.key) { mutableStateOf<MediaPlayer?>(null) }
    var prepared by remember(source.key) { mutableStateOf(false) }
    var playing by remember(source.key) { mutableStateOf(false) }
    var positionMillis by remember(source.key) { mutableLongStateOf(0L) }
    var durationMillis by remember(source.key) { mutableLongStateOf(info.durationMillis) }
    var playbackError by remember(source.key) { mutableStateOf(false) }
    var loopEnabled by remember(source.key) { mutableStateOf(true) }
    var playbackSpeed by remember(source.key) { mutableFloatStateOf(1f) }
    var volume by remember(source.key) { mutableFloatStateOf(1f) }
    var backgroundPlaybackError by remember(source.key) { mutableStateOf(false) }
    var minimizeWhenReady by remember(source.key) { mutableStateOf(false) }
    val latestPlayingInBackground by rememberUpdatedState(playingInBackground)
    val startBackground: () -> Unit = {
        runCatching { BackgroundPlaybackService.play(context, source.uri(context), source.name, positionMillis,
            loopEnabled, playbackSpeed, volume, backgroundPlaylistForSource(context, source, backgroundPlaylist)) }
            .onSuccess {
                player?.let { active -> if (runCatching { active.isPlaying }.getOrDefault(false)) active.pause() }
                playing = false
                backgroundPlaybackError = false
            }.onFailure { backgroundPlaybackError = true; minimizeWhenReady = false }
    }
    val latestStartBackground by rememberUpdatedState(startBackground)
    LaunchedEffect(minimizeWhenReady, background?.phase, playingInBackground) {
        if (minimizeWhenReady && playingInBackground && background?.phase == com.shovel.filemanager.media.BackgroundPlaybackPhase.PLAYING) {
            minimizeWhenReady = false
            onMinimizeMedia()
        }
        if (minimizeWhenReady && background?.phase == com.shovel.filemanager.media.BackgroundPlaybackPhase.ERROR) {
            minimizeWhenReady = false
            backgroundPlaybackError = true
        }
    }

    DisposableEffect(source.key) {
        var owned: MediaPlayer? = null
        var disposed = false
        runCatching {
            val created = MediaPlayer().also { owned = it; player = it }
            setMediaDataSource(created, context, source)
            created.isLooping = true
            created.setOnPreparedListener { ready ->
                if (!disposed && player === ready) runCatching {
                    durationMillis = ready.duration.toLong().coerceAtLeast(info.durationMillis)
                    prepared = true
                    playbackError = false
                }.onFailure { prepared = false; playbackError = true }
            }
            created.setOnCompletionListener {
                playing = false
                positionMillis = durationMillis
            }
            created.setOnErrorListener { _, _, _ ->
                playing = false
                prepared = false
                playbackError = true
                true
            }
            created.prepareAsync()
        }.onFailure { playbackError = true }
        onDispose {
            disposed = true
            player = null
            owned?.let { created ->
                runCatching { created.setOnPreparedListener(null); created.setOnCompletionListener(null); created.setOnErrorListener(null) }
                runCatching { created.stop() }
                runCatching { created.release() }
            }
        }
    }
    LaunchedEffect(player, prepared, loopEnabled, volume) {
        if (!prepared) return@LaunchedEffect
        player?.let { active ->
            runCatching { active.isLooping = loopEnabled }
            runCatching { active.setVolume(volume, volume) }
        }
    }
    LaunchedEffect(player, prepared) {
        while (prepared) {
            player?.let { active ->
                positionMillis = runCatching { active.currentPosition.toLong() }.getOrDefault(positionMillis)
                playing = runCatching { active.isPlaying }.getOrDefault(false)
            }
            delay(if (playing) 250L else 600L)
        }
    }

    if (playbackError) {
        PreviewLoadError(IllegalStateException())
        return
    }
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp).testTag("audio_player"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top,
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(.82f).aspectRatio(1f).testTag("audio_artwork")
                .pointerInput(source.key) {
                    var dragged = 0f
                    detectVerticalDragGestures(
                        onDragStart = { dragged = 0f },
                        onVerticalDrag = { change, delta -> change.consume(); dragged += delta },
                        onDragEnd = {
                            if (dragged > 80.dp.toPx()) {
                                minimizeWhenReady = true
                                if (!latestPlayingInBackground) latestStartBackground()
                            }
                        },
                    )
                },
            shape = MaterialTheme.shapes.extraLarge,
            color = MaterialTheme.colorScheme.surfaceContainerHighest,
        ) {
            val artwork = info.artwork
            if (artwork != null) {
                Image(
                    bitmap = artwork.asImageBitmap(),
                    contentDescription = source.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.MusicNote, contentDescription = null, modifier = Modifier.size(92.dp), tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
        Text(
            source.name,
            modifier = Modifier.fillMaxWidth().padding(top = 14.dp),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        if (!playingInBackground) PlaybackControls(
            prefix = "audio",
            prepared = prepared,
            playing = playing,
            positionMillis = positionMillis,
            durationMillis = durationMillis,
            canNavigateMedia = canNavigateMedia,
            loopEnabled = loopEnabled,
            playbackSpeed = playbackSpeed,
            volume = volume,
            onPrevious = onPreviousMedia,
            onNext = onNextMedia,
            onToggle = {
                player?.let { active ->
                    runCatching {
                    if (playing) active.pause() else {
                        if (background?.active == true) BackgroundPlaybackService.stop(context)
                        if (positionMillis >= durationMillis && durationMillis > 0L) active.seekTo(0)
                        runCatching { active.playbackParams = active.playbackParams.setSpeed(playbackSpeed) }
                        active.start()
                    }
                    playing = active.isPlaying
                    }.onFailure { prepared = false; playing = false; playbackError = true }
                }
            },
            onSeek = { requested ->
                positionMillis = requested
                runCatching { player?.seekTo(requested.toInt()) }.onFailure { playbackError = true }
            },
            onLoopChanged = { loopEnabled = it },
            onSpeedChanged = { requested ->
                playbackSpeed = requested
                if (playing) player?.let { active ->
                    runCatching { active.playbackParams = active.playbackParams.setSpeed(requested) }
                }
            },
            onVolumeChanged = { volume = it },
            onPlayInBackground = startBackground,
        )
        if (backgroundPlaybackError) {
            Text(uiText("Could not start background playback"), color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun VideoPreview(
    source: PreviewSource,
    info: MediaPreviewInfo,
    canNavigateMedia: Boolean,
    onPreviousMedia: () -> Unit,
    onNextMedia: () -> Unit,
    backgroundPlaylist: List<com.shovel.filemanager.media.BackgroundMediaItem>,
) {
    val context = LocalContext.current
    val background by BackgroundPlaybackService.state.collectAsStateWithLifecycle()
    val sourceUri = remember(source.key) { runCatching { source.uri(context).toString() }.getOrNull() }
    val playingInBackground = background?.let { it.active && it.uri == sourceUri } == true
    var videoView by remember(source.key) { mutableStateOf<VideoView?>(null) }
    var prepared by remember(source.key) { mutableStateOf(false) }
    var playing by remember(source.key) { mutableStateOf(false) }
    var positionMillis by remember(source.key) { mutableLongStateOf(0L) }
    var durationMillis by remember(source.key) { mutableLongStateOf(info.durationMillis) }
    var playbackError by remember(source.key) { mutableStateOf(false) }
    var preparedPlayer by remember(source.key) { mutableStateOf<MediaPlayer?>(null) }
    var loopEnabled by remember(source.key) { mutableStateOf(true) }
    var playbackSpeed by remember(source.key) { mutableFloatStateOf(1f) }
    var volume by remember(source.key) { mutableFloatStateOf(1f) }
    var backgroundPlaybackError by remember(source.key) { mutableStateOf(false) }
    var controlsVisible by remember(source.key) { mutableStateOf(true) }
    var controlsInteraction by remember(source.key) { mutableLongStateOf(0L) }
    var controlsHeld by remember(source.key) { mutableStateOf(false) }
    LaunchedEffect(playing, controlsVisible, controlsInteraction, controlsHeld) {
        if (playing && controlsVisible && !controlsHeld) {
            delay(7_000L)
            controlsVisible = false
        }
    }

    DisposableEffect(source.key) {
        onDispose {
            preparedPlayer = null
            videoView?.let { view ->
                runCatching { view.setOnPreparedListener(null); view.setOnCompletionListener(null); view.setOnErrorListener(null) }
                runCatching { view.stopPlayback() }
            }
            videoView = null
        }
    }
    LaunchedEffect(preparedPlayer, loopEnabled, volume) {
        preparedPlayer?.let { active ->
            runCatching { active.isLooping = loopEnabled }
            runCatching { active.setVolume(volume, volume) }
        }
    }
    LaunchedEffect(videoView, prepared) {
        while (prepared) {
            videoView?.let { active ->
                positionMillis = runCatching { active.currentPosition.toLong() }.getOrDefault(positionMillis)
                playing = runCatching { active.isPlaying }.getOrDefault(false)
            }
            delay(if (playing) 250L else 600L)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().testTag("video_player")) {
    val videoHeight = if (controlsVisible) (maxHeight * 0.55f).coerceIn(120.dp, 480.dp) else maxHeight
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .pointerInput(source.key) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                controlsHeld = true
                try {
                    controlsInteraction++
                    do { val event = awaitPointerEvent() } while (event.changes.any { it.pressed })
                } finally {
                    controlsHeld = false
                    controlsInteraction++
                }
            }
        }) {
        Box(modifier = Modifier.fillMaxWidth().height(videoHeight).background(androidx.compose.ui.graphics.Color.Black)) {
            AndroidView(
                factory = { viewContext ->
                    VideoView(viewContext).apply {
                        videoView = this
                        setOnPreparedListener { ready ->
                            if (videoView !== this) return@setOnPreparedListener
                            runCatching {
                            preparedPlayer = ready
                            ready.isLooping = loopEnabled
                            ready.setVolume(volume, volume)
                            durationMillis = ready.duration.toLong().coerceAtLeast(info.durationMillis)
                            prepared = true
                            playbackError = false
                            seekTo(1)
                            }.onFailure { prepared = false; playbackError = true }
                        }
                        setOnCompletionListener {
                            playing = false
                            positionMillis = durationMillis
                        }
                        setOnErrorListener { _, _, _ ->
                            playing = false
                            prepared = false
                            playbackError = true
                            true
                        }
                        // Always let ContentResolver open the source. Passing an app-private
                        // cache path to the platform media process can fail on OEM builds,
                        // especially for files staged through Shizuku or root access.
                        runCatching { setVideoURI(source.uri(context)) }.onFailure { playbackError = true }
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
            if (!prepared && !playbackError) CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            if (playbackError) PreviewLoadError(IllegalStateException())
            VideoGestureOverlay(volume = volume, onVolume = { volume = it }, onTap = {
                controlsVisible = !controlsVisible
                controlsInteraction++
            })
        }
        if (!playingInBackground && controlsVisible) PlaybackControls(
            prefix = "video",
            prepared = prepared,
            playing = playing,
            positionMillis = positionMillis,
            durationMillis = durationMillis,
            canNavigateMedia = canNavigateMedia,
            loopEnabled = loopEnabled,
            playbackSpeed = playbackSpeed,
            volume = volume,
            onPrevious = onPreviousMedia,
            onNext = onNextMedia,
            onToggle = {
                videoView?.let { active ->
                    runCatching {
                    if (playing) active.pause() else {
                        if (background?.active == true) BackgroundPlaybackService.stop(context)
                        if (positionMillis >= durationMillis && durationMillis > 0L) active.seekTo(0)
                        preparedPlayer?.let { ready ->
                            runCatching { ready.playbackParams = ready.playbackParams.setSpeed(playbackSpeed) }
                        }
                        active.start()
                    }
                    playing = active.isPlaying
                    }.onFailure { prepared = false; playing = false; playbackError = true }
                }
            },
            onSeek = { requested ->
                positionMillis = requested
                runCatching { videoView?.seekTo(requested.toInt()) }.onFailure { playbackError = true }
            },
            onLoopChanged = { loopEnabled = it },
            onSpeedChanged = { requested ->
                playbackSpeed = requested
                if (playing) preparedPlayer?.let { active ->
                    runCatching { active.playbackParams = active.playbackParams.setSpeed(requested) }
                }
            },
            onVolumeChanged = { volume = it },
            onPlayInBackground = {
                runCatching {
                    BackgroundPlaybackService.play(
                        context,
                        source.uri(context),
                        source.name,
                        positionMillis,
                        loopEnabled,
                        playbackSpeed,
                        volume,
                        backgroundPlaylistForSource(context, source, backgroundPlaylist),
                    )
                }.onSuccess {
                    videoView?.pause()
                    playing = false
                    backgroundPlaybackError = false
                }.onFailure {
                    backgroundPlaybackError = true
                }
            },
        )
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
            if (backgroundPlaybackError) {
                Text(uiText("Could not start background playback"), color = MaterialTheme.colorScheme.error)
            }
        }
    }
    }
}

@Composable
internal fun PlaybackControls(
    prefix: String,
    prepared: Boolean,
    playing: Boolean,
    positionMillis: Long,
    durationMillis: Long,
    canNavigateMedia: Boolean,
    loopEnabled: Boolean,
    playbackSpeed: Float,
    volume: Float,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onToggle: () -> Unit,
    onSeek: (Long) -> Unit,
    onLoopChanged: (Boolean) -> Unit,
    onSpeedChanged: (Float) -> Unit,
    onVolumeChanged: (Float) -> Unit,
    onPlayInBackground: () -> Unit,
) {
    val progress = MediaPlaybackRules.progress(positionMillis, durationMillis)
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Slider(
            value = progress,
            onValueChange = { onSeek(MediaPlaybackRules.positionForProgress(it, durationMillis)) },
            enabled = prepared && durationMillis > 0L,
            modifier = Modifier.fillMaxWidth().testTag("${prefix}_seek"),
        )
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(MediaPlaybackRules.timeLabel(positionMillis), style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.weight(1f))
            Text(MediaPlaybackRules.timeLabel(durationMillis), style = MaterialTheme.typography.labelSmall)
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onPrevious, enabled = canNavigateMedia) {
                Icon(Icons.Rounded.SkipPrevious, contentDescription = uiText("Previous file"))
            }
            IconButton(
                onClick = { onSeek(MediaPlaybackRules.skippedPosition(positionMillis, durationMillis, -MediaPlaybackRules.SKIP_MILLIS)) },
                enabled = prepared,
            ) { Icon(Icons.Rounded.Replay10, contentDescription = uiText("Back")) }
            FilledTonalIconButton(
                onClick = onToggle,
                enabled = prepared,
                modifier = Modifier.size(48.dp).testTag("${prefix}_play_pause"),
            ) {
                Icon(
                    if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = uiText(if (playing) "Pause" else "Start"),
                )
            }
            IconButton(
                onClick = { onSeek(MediaPlaybackRules.skippedPosition(positionMillis, durationMillis, MediaPlaybackRules.SKIP_MILLIS)) },
                enabled = prepared,
            ) { Icon(Icons.Rounded.Forward10, contentDescription = uiText("Forward")) }
            IconButton(onClick = onNext, enabled = canNavigateMedia) {
                Icon(Icons.Rounded.SkipNext, contentDescription = uiText("Next file"))
            }
        }
        ShovelActionRow(modifier = Modifier.testTag("${prefix}_playback_options")) {
            FilterChip(
                selected = loopEnabled,
                onClick = { onLoopChanged(!loopEnabled) },
                label = { LText("Repeat") },
                leadingIcon = { Icon(Icons.Rounded.Repeat, contentDescription = null) },
            )
            var speedMenu by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { speedMenu = true }, enabled = prepared) {
                    Text("${playbackSpeed}×")
                }
                DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
                    listOf(0.5f, 1f, 1.5f, 2f).forEach { speed ->
                        DropdownMenuItem(
                            text = { Text("${speed}×") },
                            onClick = { speedMenu = false; onSpeedChanged(speed) },
                        )
                    }
                }
            }
            OutlinedButton(onClick = onPlayInBackground, enabled = prepared, modifier = Modifier.testTag("${prefix}_background_start")) {
                Icon(Icons.Rounded.Headphones, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                LText("Play in background")
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.VolumeUp, contentDescription = uiText("Volume"))
            Slider(
                value = volume,
                onValueChange = onVolumeChanged,
                valueRange = 0f..1f,
                enabled = prepared,
                modifier = Modifier.weight(1f).testTag("${prefix}_volume"),
            )
        }
    }
}

@Composable
private fun MediaPropertyRows(info: MediaPreviewInfo) {
    PropertyRow("Duration", MediaPlaybackRules.timeLabel(info.durationMillis))
    info.mimeType?.let { PropertyRow("Type", it) }
    info.bitRate?.let { PropertyRow("Bit rate", it) }
}

@Composable
private fun FileEditActions(
    state: FileEditUiState,
    onSave: () -> Unit,
    onSaveAs: () -> Unit,
) {
    val session = state.session
    val busy = state.preparing || state.saving || state.modifyingPdf
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = MaterialTheme.shapes.medium,
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (busy) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                LText(
                    when {
                        state.modifyingPdf -> "The signature is being added to the private working copy…"
                        state.preparing -> "Preparing a safe editable copy…"
                        state.saving -> "Saving and verifying…"
                        state.hasUnsavedChanges -> "Unsaved changes are kept in a private working copy"
                        state.hasOriginChanges -> "A copy is saved elsewhere; the original still differs"
                        session != null -> "Editing uses a private working copy"
                        else -> "Editing could not be prepared"
                    },
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(
                    onClick = onSave,
                    enabled = session != null && state.hasOriginChanges && session.origin.canWrite && !busy,
                    modifier = Modifier.testTag("save-edit-original"),
                ) {
                    Icon(Icons.Rounded.Save, contentDescription = null)
                    Spacer(Modifier.width(5.dp))
                    LText("Save")
                }
                OutlinedButton(
                    onClick = onSaveAs,
                    enabled = session != null && !busy,
                    modifier = Modifier.testTag("save-edit-as"),
                ) {
                    Icon(Icons.Rounded.SaveAs, contentDescription = null)
                    Spacer(Modifier.width(5.dp))
                    LText("Save as")
                }
            }
            if (session != null && !session.origin.canWrite) {
                LText(
                    "The original is read-only. Save the edited file to another location.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
            state.status?.let { LText(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
            state.error?.let { LText(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun TextPreview(
    state: FileEditUiState?,
    onPrepareEdit: () -> Unit,
    onTextChanged: (String) -> Unit,
    onEncodingChanged: (TextEncoding) -> Unit,
    onLineEndingChanged: (LineEnding) -> Unit,
    onSave: () -> Unit,
    onSaveAs: () -> Unit,
) {
    LaunchedEffect(state?.sourceKey) {
        if (state?.session == null && state?.preparing != true) onPrepareEdit()
    }
    when {
        state == null || state.preparing -> Column(
            modifier = Modifier.fillMaxSize().padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) { CircularProgressIndicator() }
        state.session == null -> LText(
            state.error ?: "Could not prepare the built-in editor",
            modifier = Modifier.fillMaxSize().padding(18.dp),
            color = MaterialTheme.colorScheme.error,
        )
        else -> FullTextEditor(
            sourceKey = state.sourceKey.orEmpty(),
            fileName = state.session.displayName,
            text = state.text.orEmpty(),
            readOnly = state.saving,
            encoding = state.encoding ?: TextEncoding.UTF8,
            lineEnding = state.lineEnding ?: LineEnding.LF,
            onTextChanged = onTextChanged,
            onEncodingChanged = onEncodingChanged,
            onLineEndingChanged = onLineEndingChanged,
            onSave = onSave,
            onSaveAs = onSaveAs,
        )
    }
}

@Composable
private fun EditConflictDialog(
    conflict: EditConflict,
    workingRevision: FileRevision,
    saving: Boolean,
    canMerge: Boolean,
    onMerge: () -> Unit,
    onOverwrite: () -> Unit,
    onSaveAs: () -> Unit,
    onKeepEditing: () -> Unit,
) {
    val dateFormat = rememberLocalizedDateTimeFormat(DateFormat.SHORT, DateFormat.SHORT)
    AlertDialog(
        onDismissRequest = onKeepEditing,
        title = { LText("The original file changed") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LText("Shovel did not overwrite it. Compare the revisions and choose what to do.")
                Text(conflict.originLabel, style = MaterialTheme.typography.bodySmall)
                LText("Original when opened", fontWeight = FontWeight.SemiBold)
                Text(revisionSummary(conflict.expected, dateFormat), style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                LText("Your edited copy", fontWeight = FontWeight.SemiBold)
                Text(revisionSummary(workingRevision, dateFormat), style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                LText("Current original", fontWeight = FontWeight.SemiBold)
                if (conflict.current == null) {
                    LText("The original file no longer exists")
                } else {
                    Text(revisionSummary(conflict.current, dateFormat), style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                }
                LText(
                    if (canMerge) {
                        "Merge compares the original, your changes, and the current server version. Ambiguous sections are clearly marked in the editor."
                    } else {
                        "Overwrite replaces the current original. Save as keeps both versions."
                    },
                )
            }
        },
        confirmButton = {
            Button(
                onClick = if (canMerge) onMerge else onOverwrite,
                enabled = !saving,
                modifier = Modifier.testTag(if (canMerge) "merge-edit-conflict" else "overwrite-edit-conflict"),
            ) { LText(if (canMerge) "Merge changes" else "Overwrite original") }
        },
        dismissButton = {
            Column(horizontalAlignment = Alignment.End) {
                if (canMerge) {
                    TextButton(
                        onClick = onOverwrite,
                        enabled = !saving,
                        modifier = Modifier.testTag("overwrite-edit-conflict"),
                    ) { LText("Overwrite original") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onSaveAs, enabled = !saving) { LText("Save as") }
                    TextButton(onClick = onKeepEditing, enabled = !saving) { LText("Keep editing") }
                }
            }
        },
    )
}

@Composable
private fun EditSaveAsConflictDialog(
    conflict: EditSaveAsConflict,
    saving: Boolean,
    onReplace: () -> Unit,
    onKeepBoth: () -> Unit,
    onChooseAnother: () -> Unit,
    onDismiss: () -> Unit,
) {
    val dateFormat = rememberLocalizedDateTimeFormat()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { LText("The destination file already exists") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LText("Shovel did not overwrite anything. Choose how to resolve the conflict.")
                Text(conflict.destination.label, style = MaterialTheme.typography.bodySmall)
                PropertyRow("Existing file size", FileSystemRules.humanBytes(conflict.existing.sizeBytes))
                conflict.existing.modifiedAtMillis?.let { modified ->
                    PropertyRow("Existing file modified", dateFormat.format(Date(modified)))
                }
                conflict.existing.sha256?.let { sha ->
                    PropertyRow("Existing file SHA-256", sha.take(16) + "…")
                }
                LText("Overwrite safely replaces the existing file. Keep both chooses an available name.")
            }
        },
        confirmButton = {
            Button(onClick = onReplace, enabled = !saving) { LText("Overwrite") }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                TextButton(onClick = onKeepBoth, enabled = !saving) { LText("Keep both") }
                TextButton(onClick = onChooseAnother, enabled = !saving) { LText("Choose another location") }
            }
        },
    )
}

@Composable
private fun ApkPreview(file: File) {
    val context = LocalContext.current
    var confirmInstall by remember(file.absolutePath) { mutableStateOf(false) }
    var showContents by remember(file.absolutePath) { mutableStateOf(false) }
    val info = remember(file.absolutePath) {
        @Suppress("DEPRECATION")
        context.packageManager.getPackageArchiveInfo(
            file.absolutePath,
            if (android.os.Build.VERSION.SDK_INT >= 28) android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES
            else android.content.pm.PackageManager.GET_SIGNATURES,
        )
    }
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(Icons.Rounded.InstallMobile, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        info?.packageName?.let {
            Text(it, style = MaterialTheme.typography.titleLarge)
        } ?: LText("APK information unavailable", style = MaterialTheme.typography.titleLarge)
        info?.let { packageInfo ->
            @Suppress("DEPRECATION")
            val versionCode = if (android.os.Build.VERSION.SDK_INT >= 28) packageInfo.longVersionCode else packageInfo.versionCode.toLong()
            PropertyRow("Version", "${packageInfo.versionName ?: "?"} ($versionCode)")
            @Suppress("DEPRECATION")
            val certificate = if (android.os.Build.VERSION.SDK_INT >= 28) {
                packageInfo.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
            } else {
                packageInfo.signatures?.firstOrNull()?.toByteArray()
            }
            certificate?.let {
                PropertyRow("Signature SHA-256", MessageDigest.getInstance("SHA-256").digest(certificate).joinToString("") { "%02x".format(it) })
            }
        }
        LText("Android always confirms installation. The app cannot install silently.", style = MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick = { showContents = true }, modifier = Modifier.testTag("apk_open_contents")) {
            LText("Open archive")
        }
        Button(onClick = { confirmInstall = true }) {
            Icon(Icons.Rounded.InstallMobile, contentDescription = null)
            LText("Open installer", modifier = Modifier.padding(start = 8.dp))
        }
    }
    if (showContents) ApkContentsDialog(file, onDismiss = { showContents = false })
    if (confirmInstall) ApkInstallConfirmationDialog(
        cacheKey = "${file.absolutePath}:${file.lastModified()}:${file.length()}",
        load = { com.shovel.filemanager.apk.ApkInstallMetadataReader.standalone(context, file) },
        onDismiss = { confirmInstall = false },
        onInstall = { confirmInstall = false; installApk(context, file) },
    )
}

@Composable
private fun ArchivePreview(
    file: FileEntry,
    entries: List<ArchiveEntryInfo>,
    currentPath: String,
    onPathChanged: (String) -> Unit,
    onCopyEntry: ((String) -> Unit)?,
    onCopyEntries: ((Set<String>) -> Unit)?,
    onOpenEntry: (String) -> Unit,
    onShareEntries: (Set<String>) -> Unit,
    onExtractEntries: (Set<String>, String, CharArray?) -> Unit,
    onRenameEntry: ((String, String) -> Unit)?,
    onDeleteEntries: ((Set<String>) -> Unit)?,
    onMoveEntries: ((Set<String>) -> Unit)?,
    onRefresh: () -> Unit,
    loadThumbnail: suspend (String) -> Result<File>,
    onExtract: ((FileEntry, String, CharArray?) -> Unit)?,
    initialExtractDirectory: String,
    loadExtractDirectory: suspend (String) -> Result<List<FileEntry>>,
    mutable: Boolean,
    initialDisplayDefaults: DirectoryDisplayDefaults,
    onApplyDisplayToAll: (DirectoryDisplaySettings, SortMode?, SortDirection) -> Unit,
) {
    var extractAllRequested by remember { mutableStateOf(false) }
    var extractSelectionRequested by remember { mutableStateOf<Set<String>?>(null) }
    var searchVisible by remember(file.absolutePath) { mutableStateOf(false) }
    var searchQuery by remember(file.absolutePath) { mutableStateOf("") }
    var entryFilters by remember(file.absolutePath, currentPath) { mutableStateOf<Set<DirectoryEntryFilter>>(emptySet()) }
    var showEntryFilter by remember(file.absolutePath, currentPath) { mutableStateOf(false) }
    var menu by remember(file.absolutePath) { mutableStateOf(false) }
    var showDisplaySettings by remember(file.absolutePath) { mutableStateOf(false) }
    var displaySettings by remember(file.absolutePath) { mutableStateOf(initialDisplayDefaults.settings) }
    var sortMode by remember(file.absolutePath) { mutableStateOf(initialDisplayDefaults.sortMode) }
    var sortDirection by remember(file.absolutePath) { mutableStateOf(initialDisplayDefaults.sortDirection) }
    var selectedPaths by remember(file.absolutePath, currentPath) { mutableStateOf(emptySet<String>()) }
    var renameTarget by remember(file.absolutePath) { mutableStateOf<ArchiveBrowserItem?>(null) }
    var renameText by remember(file.absolutePath) { mutableStateOf("") }
    var deleteRequested by remember(file.absolutePath) { mutableStateOf<Set<String>?>(null) }
    var moveRequested by remember(file.absolutePath) { mutableStateOf<Set<String>?>(null) }
    var refreshing by remember(file.absolutePath) { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(currentPath) {
        searchVisible = false
        searchQuery = ""
        selectedPaths = emptySet()
        listState.scrollToItem(0)
        gridState.scrollToItem(0)
    }
    LaunchedEffect(entries) {
        selectedPaths = selectedPaths.filterTo(linkedSetOf()) { selected ->
            entries.any { entry ->
                val normalized = entry.name.replace('\\', '/').trim('/')
                normalized == selected || normalized.startsWith("$selected/")
            }
        }
        refreshing = false
    }
    val browser = remember(entries) { ArchiveBrowserIndex.from(entries) }
    val children = remember(browser, currentPath) { browser.children(currentPath) }
    var visibleEntries by remember(file.absolutePath, currentPath) { mutableStateOf<List<ArchiveBrowserItem>>(emptyList()) }
    var transforming by remember(file.absolutePath, currentPath) { mutableStateOf(false) }
    LaunchedEffect(children, searchQuery, entryFilters, sortMode, sortDirection) {
        val requestedChildren = children
        val query = searchQuery.trim()
        transforming = true
        visibleEntries = emptyList()
        visibleEntries = withContext(Dispatchers.Default) {
            val ordered = orderArchiveEntries(requestedChildren, sortMode, sortDirection)
            ordered.filter { entry ->
                (query.isEmpty() || entry.name.contains(query, ignoreCase = true)) &&
                    DirectoryEntryFilterRules.matches(
                        FileSystemRules.detectKind(entry.name, mimeType = null, isDirectory = entry.directory),
                        entryFilters,
                    )
            }
        }
        transforming = false
    }
    val grid = displaySettings.layoutMode == DirectoryLayoutMode.GRID
    val goUp = { if (currentPath.isNotEmpty()) onPathChanged(ArchiveBrowserIndex.parentOf(currentPath)) }
    val visiblePaths = visibleEntries.mapTo(linkedSetOf(), ArchiveBrowserItem::path)
    val allVisibleSelected = visiblePaths.isNotEmpty() && visiblePaths.all(selectedPaths::contains)
    val toggleSelection: (String) -> Unit = { path ->
        selectedPaths = if (path in selectedPaths) selectedPaths - path else selectedPaths + path
    }
    val requestRefresh: () -> Unit = {
        if (!refreshing) {
            refreshing = true
            onRefresh()
            scope.launch {
                delay(800)
                refreshing = false
            }
        }
    }
    val openOrSelect: (ArchiveBrowserItem) -> Unit = { entry ->
        when {
            selectedPaths.isNotEmpty() -> toggleSelection(entry.path)
            entry.directory -> onPathChanged(entry.path)
            else -> onOpenEntry(entry.path)
        }
    }
    val beginRename: (ArchiveBrowserItem) -> Unit = { entry ->
        renameTarget = entry
        renameText = entry.name
    }
    Column(modifier = Modifier.fillMaxSize()) {
        if (selectedPaths.isNotEmpty()) {
            SelectionActionBar(
                count = selectedPaths.size,
                allSelected = allVisibleSelected,
                onClose = { selectedPaths = emptySet() },
                onToggleSelectAll = {
                    selectedPaths = if (allVisibleSelected) selectedPaths - visiblePaths else selectedPaths + visiblePaths
                },
            ) {
                onCopyEntries?.let { copy ->
                    IconButton(onClick = { copy(selectedPaths); selectedPaths = emptySet() }) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = uiText("Copy"))
                    }
                }
                IconButton(onClick = { onShareEntries(selectedPaths); selectedPaths = emptySet() }) {
                    Icon(Icons.Rounded.Share, contentDescription = uiText("Share"))
                }
                IconButton(onClick = { extractSelectionRequested = selectedPaths }) {
                    Icon(Icons.Rounded.Archive, contentDescription = uiText("Extract"))
                }
                if (mutable && onMoveEntries != null) {
                    IconButton(onClick = { moveRequested = selectedPaths }) {
                        Icon(Icons.Rounded.DriveFileMove, contentDescription = uiText("Move from archive"))
                    }
                }
                if (mutable && selectedPaths.size == 1 && onRenameEntry != null) {
                    IconButton(onClick = {
                        renameTarget = visibleEntries.firstOrNull { it.path == selectedPaths.single() }
                            ?: children.firstOrNull { it.path == selectedPaths.single() }
                        renameText = renameTarget?.name.orEmpty()
                    }) {
                        Icon(Icons.Rounded.Edit, contentDescription = uiText("Rename"))
                    }
                }
                if (mutable && onDeleteEntries != null) {
                    IconButton(onClick = { deleteRequested = selectedPaths }) {
                        Icon(Icons.Rounded.Delete, contentDescription = uiText("Delete"))
                    }
                }
            }
        } else {
        DirectoryBrowserToolbar(
            title = if (currentPath.isEmpty()) uiText("Archive root") else ArchiveBrowserIndex.folderName(currentPath),
            path = if (currentPath.isEmpty()) file.name else "${file.name} / $currentPath",
            backEnabled = currentPath.isNotEmpty(),
            forwardEnabled = false,
            upEnabled = currentPath.isNotEmpty(),
            searchActive = searchVisible,
            grid = grid,
            testTagPrefix = "archive",
            onBack = goUp,
            onForward = {},
            onUp = goUp,
            onToggleSearch = {
                searchVisible = !searchVisible
                if (!searchVisible) searchQuery = ""
            },
            onToggleLayout = {
                displaySettings = displaySettings.copy(
                    layoutMode = if (grid) DirectoryLayoutMode.LIST else DirectoryLayoutMode.GRID,
                )
            },
            onOpenSettings = { showDisplaySettings = true },
        ) {
            Box {
                IconButton(onClick = { menu = true }, modifier = Modifier.testTag("archive_actions")) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = uiText("Folder actions"))
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (onExtract != null) {
                        DropdownMenuItem(
                            text = { LText("Extract") },
                            leadingIcon = { Icon(Icons.Rounded.Archive, contentDescription = null) },
                            onClick = { menu = false; extractAllRequested = true },
                        )
                    }
                    if (onCopyEntry != null && currentPath.isNotEmpty()) {
                        DropdownMenuItem(
                            text = { LText("Copy archive folder") },
                            leadingIcon = { Icon(Icons.Rounded.ContentCopy, contentDescription = null) },
                            onClick = { menu = false; onCopyEntry(currentPath) },
                        )
                    }
                    if (onExtract != null || (onCopyEntry != null && currentPath.isNotEmpty())) HorizontalDivider()
                    DirectoryDisplayMenuItems(
                        grid = grid,
                        includeHidden = false,
                        hiddenFilesAvailable = false,
                        showThumbnails = displaySettings.showThumbnails,
                        thumbnailsAvailable = true,
                        sortMode = sortMode,
                        sortDirection = sortDirection,
                        displaySettingsTestTag = "archive_display_settings",
                        onToggleHidden = {},
                        onToggleLayout = {
                            displaySettings = displaySettings.copy(
                                layoutMode = if (grid) DirectoryLayoutMode.LIST else DirectoryLayoutMode.GRID,
                            )
                        },
                        onToggleThumbnails = { displaySettings = displaySettings.copy(showThumbnails = !displaySettings.showThumbnails) },
                        onOpenSettings = { showDisplaySettings = true },
                        onSort = { sortMode = it },
                        onDismissMenu = { menu = false },
                        filterActive = entryFilters.isNotEmpty(),
                        onOpenFilter = { showEntryFilter = true },
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { LText("Refresh") },
                        leadingIcon = { Icon(Icons.Rounded.Refresh, contentDescription = null) },
                        enabled = !refreshing,
                        onClick = { menu = false; requestRefresh() },
                    )
                }
            }
        }
        }
        if (searchVisible) {
            DirectoryQuickSearchField(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                onClose = { searchVisible = false; searchQuery = "" },
                filterActive = entryFilters.isNotEmpty(),
                onOpenFilter = { showEntryFilter = true },
                modifier = Modifier.testTag("directory_search_field_archive"),
            )
        }
        ShovelPullToRefresh(
            isRefreshing = refreshing,
            onRefresh = requestRefresh,
            modifier = Modifier.fillMaxWidth().weight(1f),
            testTag = "pull_to_refresh_archive",
        ) {
        when {
            transforming && visibleEntries.isEmpty() -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            visibleEntries.isEmpty() -> Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                LText(if (children.isEmpty()) "Folder is empty" else "No matches found")
            }
            grid -> {
                LazyVerticalGrid(
                columns = GridCells.Fixed(displaySettings.gridColumns.coerceIn(1, 6)),
                state = gridState,
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy((8f * displaySettings.spacingScalePercent / 100f).dp),
                verticalArrangement = Arrangement.spacedBy((8f * displaySettings.spacingScalePercent / 100f).dp),
            ) {
                gridItems(visibleEntries, key = { it.path }) { entry ->
                    ArchiveGridItem(
                        entry = entry,
                        iconScalePercent = displaySettings.iconScalePercent,
                        gridStyle = displaySettings.gridStyle,
                        selected = entry.path in selectedPaths,
                        selectionMode = selectedPaths.isNotEmpty(),
                        showThumbnails = displaySettings.showThumbnails,
                        onClick = { openOrSelect(entry) },
                        onLongClick = { toggleSelection(entry.path) },
                        onSelect = { toggleSelection(entry.path) },
                        onOpen = { if (entry.directory) onPathChanged(entry.path) else onOpenEntry(entry.path) },
                        onCopy = onCopyEntry?.let { copy -> { copy(entry.path) } },
                        onShare = { onShareEntries(setOf(entry.path)) },
                        onExtract = { extractSelectionRequested = setOf(entry.path) },
                        onRename = if (mutable && onRenameEntry != null) ({ beginRename(entry) }) else null,
                        onMove = if (mutable && onMoveEntries != null) ({ moveRequested = setOf(entry.path) }) else null,
                        onDelete = if (mutable && onDeleteEntries != null) ({ deleteRequested = setOf(entry.path) }) else null,
                        loadThumbnail = loadThumbnail,
                    )
                }
                }
                LazyGridFastScroller(gridState)
            }
            else -> {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                    items(visibleEntries, key = { it.path }) { entry ->
                    ArchiveListItem(
                        entry = entry,
                        iconScalePercent = displaySettings.iconScalePercent,
                        spacingScalePercent = displaySettings.spacingScalePercent,
                        selected = entry.path in selectedPaths,
                        selectionMode = selectedPaths.isNotEmpty(),
                        showThumbnails = displaySettings.showThumbnails,
                        onClick = { openOrSelect(entry) },
                        onLongClick = { toggleSelection(entry.path) },
                        onSelect = { toggleSelection(entry.path) },
                        onOpen = { if (entry.directory) onPathChanged(entry.path) else onOpenEntry(entry.path) },
                        onCopy = onCopyEntry?.let { copy -> { copy(entry.path) } },
                        onShare = { onShareEntries(setOf(entry.path)) },
                        onExtract = { extractSelectionRequested = setOf(entry.path) },
                        onRename = if (mutable && onRenameEntry != null) ({ beginRename(entry) }) else null,
                        onMove = if (mutable && onMoveEntries != null) ({ moveRequested = setOf(entry.path) }) else null,
                        onDelete = if (mutable && onDeleteEntries != null) ({ deleteRequested = setOf(entry.path) }) else null,
                        loadThumbnail = loadThumbnail,
                    )
                        HorizontalDivider()
                    }
                }
                LazyListFastScroller(listState)
            }
        }
        }
    }
    if (showDisplaySettings) {
        DirectoryDisplaySettingsDialog(
            initialSettings = displaySettings,
            thumbnailsAvailable = true,
            initialSortMode = sortMode,
            initialSortDirection = sortDirection,
            onDismiss = { showDisplaySettings = false },
            onApply = {
                displaySettings = it
                showDisplaySettings = false
            },
            onApplySort = { mode, direction ->
                sortMode = mode
                sortDirection = direction
            },
            onApplyToAll = { settings, mode, direction ->
                displaySettings = settings
                mode?.let { sortMode = it }
                sortDirection = direction
                onApplyDisplayToAll(settings, mode, direction)
                showDisplaySettings = false
            },
        )
    }
    if (showEntryFilter) {
        DirectoryEntryFilterDialog(
            selected = entryFilters,
            onSelectedChange = { entryFilters = it },
            onDismiss = { showEntryFilter = false },
        )
    }
    if (extractAllRequested || extractSelectionRequested != null) {
        val selection = extractSelectionRequested
        ArchiveExtractionDialog(
            archiveName = file.name,
            selection = selection,
            initialDirectory = initialExtractDirectory,
            loadDirectory = loadExtractDirectory,
            onDismiss = {
                extractAllRequested = false
                extractSelectionRequested = null
            },
            onConfirm = { destinationDirectory, secret ->
                selection?.let { onExtractEntries(it, destinationDirectory, secret) }
                    ?: onExtract?.invoke(file, destinationDirectory, secret)
                extractAllRequested = false
                extractSelectionRequested = null
                selectedPaths = emptySet()
            },
        )
    }
    renameTarget?.let { entry ->
        AlertDialog(
            onDismissRequest = { renameTarget = null; renameText = "" },
            title = { LText("Rename archive entry") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { LText("New name") },
                    singleLine = true,
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRenameEntry?.invoke(entry.path, renameText)
                        selectedPaths = emptySet()
                        renameTarget = null
                        renameText = ""
                    },
                    enabled = renameText.isNotBlank() && renameText.trim() != entry.name,
                ) { LText("Rename") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null; renameText = "" }) { LText("Cancel") } },
        )
    }
    deleteRequested?.let { requested ->
        val affected = entries.filter { archiveEntry ->
            val path = archiveEntry.name.replace('\\', '/').trim('/')
            requested.any { selected -> path == selected || path.startsWith("$selected/") }
        }
        DeleteConfirmationDialog(
            names = requested.map { it.substringAfterLast('/') }, permanent = false,
            title = "Delete from archive?", confirmLabel = "Delete",
            onDismiss = { deleteRequested = null },
            onConfirm = {
                onDeleteEntries?.invoke(requested)
                selectedPaths = emptySet()
                deleteRequested = null
            },
            explanation = "The ZIP archive will be rewritten safely. A recovery backup is created before the change.",
            fallbackFiles = affected.count { !it.directory },
            fallbackFolders = affected.count(ArchiveEntryInfo::directory),
            fallbackBytes = affected.filterNot(ArchiveEntryInfo::directory).sumOf { it.sizeBytes.coerceAtLeast(0L) },
        )
    }
    moveRequested?.let { requested ->
        AlertDialog(
            onDismissRequest = { moveRequested = null },
            title = { LText("Move from archive?") },
            text = { LText("Files will first be extracted and verified beside the archive. Only then will they be removed from the ZIP.") },
            confirmButton = {
                Button(onClick = {
                    onMoveEntries?.invoke(requested)
                    selectedPaths = emptySet()
                    moveRequested = null
                }) { LText("Move") }
            },
            dismissButton = { TextButton(onClick = { moveRequested = null }) { LText("Cancel") } },
        )
    }
}

@Composable
private fun ArchiveListItem(
    entry: ArchiveBrowserItem,
    iconScalePercent: Int,
    spacingScalePercent: Int,
    selected: Boolean,
    selectionMode: Boolean,
    showThumbnails: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onSelect: () -> Unit,
    onOpen: () -> Unit,
    onCopy: (() -> Unit)?,
    onShare: () -> Unit,
    onExtract: () -> Unit,
    onRename: (() -> Unit)?,
    onMove: (() -> Unit)?,
    onDelete: (() -> Unit)?,
    loadThumbnail: suspend (String) -> Result<File>,
) {
    val iconSize = (32f * iconScalePercent / 100f).dp
    val verticalPadding = (10f * spacingScalePercent / 100f).dp
    var menuExpanded by remember(entry.path) { mutableStateOf(false) }
    com.shovel.filemanager.ui.theme.AppearanceContentOn(if (selected) MaterialTheme.colorScheme.secondaryContainer else androidx.compose.ui.graphics.Color.Transparent) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else androidx.compose.ui.graphics.Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 14.dp, vertical = verticalPadding)
            .testTag("archive-entry-${entry.path}"),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (selectionMode) {
            Checkbox(checked = selected, onCheckedChange = { onSelect() })
        }
        ArchiveEntryVisual(
            entry = entry,
            size = iconSize,
            showThumbnails = showThumbnails,
            loadThumbnail = loadThumbnail,
        )
        Text(entry.name, modifier = Modifier.weight(1f).padding(horizontal = 12.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (!entry.directory && entry.sizeBytes >= 0) {
            Text(FileSystemRules.humanBytes(entry.sizeBytes), style = MaterialTheme.typography.labelSmall)
        }
        Box {
            IconButton(onClick = { menuExpanded = true }) {
                Icon(Icons.Rounded.MoreVert, contentDescription = uiText("File actions: ${entry.name}"))
            }
            ArchiveEntryActionMenu(
                expanded = menuExpanded,
                selected = selected,
                directory = entry.directory,
                onDismiss = { menuExpanded = false },
                onSelect = onSelect,
                onOpen = onOpen,
                onCopy = onCopy,
                onShare = onShare,
                onExtract = onExtract,
                onRename = onRename,
                onMove = onMove,
                onDelete = onDelete,
            )
        }
        if (entry.directory) Icon(Icons.Rounded.ChevronRight, contentDescription = uiText("Open folder"))
    }
    }
}

@Composable
private fun ArchiveGridItem(
    entry: ArchiveBrowserItem,
    iconScalePercent: Int,
    gridStyle: DirectoryGridStyle,
    selected: Boolean,
    selectionMode: Boolean,
    showThumbnails: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onSelect: () -> Unit,
    onOpen: () -> Unit,
    onCopy: (() -> Unit)?,
    onShare: () -> Unit,
    onExtract: () -> Unit,
    onRename: (() -> Unit)?,
    onMove: (() -> Unit)?,
    onDelete: (() -> Unit)?,
    loadThumbnail: suspend (String) -> Result<File>,
) {
    val iconSize = (64f * iconScalePercent / 100f).dp
    var menuExpanded by remember(entry.path) { mutableStateOf(false) }
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .testTag("archive-entry-${entry.path}"),
        tonalElevation = if (gridStyle == DirectoryGridStyle.CLASSIC) 0.dp else 2.dp,
        color = when {
            selected -> MaterialTheme.colorScheme.secondaryContainer
            gridStyle == DirectoryGridStyle.CLASSIC -> MaterialTheme.colorScheme.surface.copy(alpha = 0f)
            else -> MaterialTheme.colorScheme.surface
        },
        shape = if (gridStyle == DirectoryGridStyle.CLASSIC) androidx.compose.foundation.shape.RoundedCornerShape(4.dp) else MaterialTheme.shapes.medium,
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                ArchiveEntryVisual(
                    entry = entry,
                    size = iconSize,
                    showThumbnails = showThumbnails,
                    loadThumbnail = loadThumbnail,
                )
                Text(entry.name, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (!entry.directory && entry.sizeBytes >= 0) {
                    Text(FileSystemRules.humanBytes(entry.sizeBytes), style = MaterialTheme.typography.labelSmall)
                }
            }
            if (selectionMode) {
                Checkbox(
                    checked = selected,
                    onCheckedChange = { onSelect() },
                    modifier = Modifier.align(Alignment.TopStart),
                )
            }
            Box(modifier = Modifier.align(Alignment.TopEnd)) {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = uiText("File actions: ${entry.name}"))
                }
                ArchiveEntryActionMenu(
                    expanded = menuExpanded,
                    selected = selected,
                    directory = entry.directory,
                    onDismiss = { menuExpanded = false },
                    onSelect = onSelect,
                    onOpen = onOpen,
                    onCopy = onCopy,
                    onShare = onShare,
                    onExtract = onExtract,
                    onRename = onRename,
                    onMove = onMove,
                    onDelete = onDelete,
                )
            }
        }
    }
}

@Composable
private fun ArchiveEntryVisual(
    entry: ArchiveBrowserItem,
    size: androidx.compose.ui.unit.Dp,
    showThumbnails: Boolean,
    loadThumbnail: suspend (String) -> Result<File>,
) {
    val kind = remember(entry.path) { FileSystemRules.detectKind(entry.name, mimeType = null, isDirectory = entry.directory) }
    val supportsThumbnail = !entry.directory && kind in setOf(EntryKind.IMAGE, EntryKind.VIDEO)
    val materialized by produceState<File?>(
        initialValue = null,
        key1 = entry.path,
        key2 = showThumbnails,
    ) {
        value = if (showThumbnails && supportsThumbnail) loadThumbnail(entry.path).getOrNull() else null
    }
    val local = materialized
    if (local != null && local.isFile) {
        LocalFileVisual(
            entry = FileEntry(
                absolutePath = local.absolutePath,
                name = entry.name,
                kind = kind,
                sizeBytes = local.length(),
                modifiedAtMillis = entry.modifiedAtMillis ?: local.lastModified(),
                isHidden = false,
                isReadable = true,
                isWritable = false,
            ),
            targetWidth = size,
            targetHeight = size,
            showThumbnails = true,
            modifier = Modifier.size(size),
        )
    } else {
        Icon(
            if (entry.directory) Icons.Rounded.Folder else Icons.Rounded.Description,
            contentDescription = null,
            tint = if (entry.directory) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(size),
        )
    }
}

private data class ArchiveExtractionNavigation(
    val currentPath: String,
    val backStack: List<String> = emptyList(),
) {
    fun navigateTo(path: String): ArchiveExtractionNavigation = if (path == currentPath) this else copy(
        currentPath = path,
        backStack = (backStack + currentPath).takeLast(100),
    )
}

@Composable
private fun ArchiveExtractionDialog(
    archiveName: String,
    selection: Set<String>?,
    initialDirectory: String,
    loadDirectory: suspend (String) -> Result<List<FileEntry>>,
    onDismiss: () -> Unit,
    onConfirm: (String, CharArray?) -> Unit,
) {
    var navigation by remember(archiveName, initialDirectory) {
        mutableStateOf(ArchiveExtractionNavigation(initialDirectory))
    }
    var directories by remember(archiveName) { mutableStateOf<List<FileEntry>>(emptyList()) }
    var loading by remember(archiveName) { mutableStateOf(true) }
    var error by remember(archiveName) { mutableStateOf<String?>(null) }
    var refreshToken by remember(archiveName) { mutableStateOf(0) }
    var password by remember(archiveName) { mutableStateOf("") }
    val currentPath = navigation.currentPath
    val outputName = ArchiveMutationRules.extractionBaseName(archiveName, "Extracted")

    LaunchedEffect(currentPath, refreshToken) {
        loading = true
        error = null
        directories = emptyList()
        loadDirectory(currentPath).fold(
            onSuccess = { loaded ->
                directories = loaded.asSequence().filter(FileEntry::isDirectory).take(10_000).toList()
            },
            onFailure = { failure -> error = failure.message ?: "Could not open the folder" },
        )
        loading = false
    }

    AlertDialog(
        modifier = Modifier.testTag("archive_extract_dialog"),
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Rounded.Archive, contentDescription = null) },
        title = { LText(if (selection == null) "Extract archive" else "Extract selected entries") },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LText("Choose the folder where the extracted folder will be created.")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val parent = File(currentPath).parentFile?.absolutePath
                    IconButton(
                        onClick = { parent?.let { navigation = navigation.navigateTo(it) } },
                        enabled = parent != null && !loading,
                    ) {
                        Icon(Icons.Rounded.ArrowUpward, contentDescription = uiText("Up"))
                    }
                    Text(
                        currentPath,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    IconButton(onClick = { refreshToken += 1 }, enabled = !loading) {
                        Icon(Icons.Rounded.Refresh, contentDescription = uiText("Refresh"))
                    }
                }
                LText("Will be created: $outputName", fontWeight = FontWeight.SemiBold)
                LText(
                    "If that folder already exists, it will not be overwritten — a new numbered name will be used.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                when {
                    loading -> Box(Modifier.fillMaxWidth().heightIn(min = 120.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    error != null -> LText(error.orEmpty(), color = MaterialTheme.colorScheme.error)
                    directories.isEmpty() -> LText("This folder has no subfolders", style = MaterialTheme.typography.bodySmall)
                    else -> LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp)) {
                        items(directories, key = FileEntry::absolutePath) { directory ->
                             Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("archive_extract_folder_${directory.absolutePath.hashCode()}")
                                    .clickable {
                                     navigation = navigation.navigateTo(directory.absolutePath)
                                 }.padding(horizontal = 6.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Rounded.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text(
                                    directory.name,
                                    modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Icon(Icons.Rounded.ChevronRight, contentDescription = uiText("Open folder"))
                            }
                            HorizontalDivider()
                        }
                    }
                }
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { LText("Archive password (optional)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                )
            }
        },
        confirmButton = {
             Button(
                modifier = Modifier.testTag("archive_extract_confirm"),
                onClick = {
                    val secret = password.takeIf(String::isNotBlank)?.toCharArray()
                    password = ""
                    onConfirm(currentPath, secret)
                },
                enabled = !loading && error == null,
            ) { LText("Extract here") }
        },
        dismissButton = {
            TextButton(onClick = { password = ""; onDismiss() }) { LText("Cancel") }
        },
    )
}

@Composable
private fun ArchiveEntryActionMenu(
    expanded: Boolean,
    selected: Boolean,
    directory: Boolean,
    onDismiss: () -> Unit,
    onSelect: () -> Unit,
    onOpen: () -> Unit,
    onCopy: (() -> Unit)?,
    onShare: () -> Unit,
    onExtract: () -> Unit,
    onRename: (() -> Unit)?,
    onMove: (() -> Unit)?,
    onDelete: (() -> Unit)?,
) {
    fun run(action: () -> Unit) {
        onDismiss()
        action()
    }
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { LText(if (directory) "Open folder" else "Open") },
            leadingIcon = { Icon(if (directory) Icons.Rounded.Folder else Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null) },
            onClick = { run(onOpen) },
        )
        DropdownMenuItem(
            text = { LText(if (selected) "Deselect" else "Select") },
            leadingIcon = { Checkbox(checked = selected, onCheckedChange = null) },
            onClick = { run(onSelect) },
        )
        onCopy?.let { copy ->
            DropdownMenuItem(
                text = { LText("Copy") },
                leadingIcon = { Icon(Icons.Rounded.ContentCopy, contentDescription = null) },
                onClick = { run(copy) },
            )
        }
        DropdownMenuItem(
            text = { LText("Share") },
            leadingIcon = { Icon(Icons.Rounded.Share, contentDescription = null) },
            onClick = { run(onShare) },
        )
        DropdownMenuItem(
            text = { LText("Extract") },
            leadingIcon = { Icon(Icons.Rounded.Archive, contentDescription = null) },
            onClick = { run(onExtract) },
        )
        if (onRename != null || onMove != null || onDelete != null) HorizontalDivider()
        onMove?.let { move ->
            DropdownMenuItem(
                text = { LText("Move from archive") },
                leadingIcon = { Icon(Icons.Rounded.DriveFileMove, contentDescription = null) },
                onClick = { run(move) },
            )
        }
        onRename?.let { rename ->
            DropdownMenuItem(
                text = { LText("Rename") },
                leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null) },
                onClick = { run(rename) },
            )
        }
        onDelete?.let { delete ->
            DropdownMenuItem(
                text = { LText("Delete") },
                leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null) },
                onClick = { run(delete) },
            )
        }
    }
}

private fun orderArchiveEntries(
    entries: List<ArchiveBrowserItem>,
    mode: SortMode,
    direction: SortDirection,
): List<ArchiveBrowserItem> {
    val ascending = when (mode) {
        SortMode.NAME -> compareBy<ArchiveBrowserItem> { it.name.lowercase(Locale.ROOT) }
        SortMode.SIZE -> compareBy<ArchiveBrowserItem> { it.sizeBytes }.thenBy { it.name.lowercase(Locale.ROOT) }
        SortMode.MODIFIED -> compareBy<ArchiveBrowserItem> { it.modifiedAtMillis ?: Long.MAX_VALUE }
            .thenBy { it.name.lowercase(Locale.ROOT) }
        SortMode.TYPE -> compareBy<ArchiveBrowserItem> { it.name.substringAfterLast('.', "").lowercase(Locale.ROOT) }
            .thenBy { it.name.lowercase(Locale.ROOT) }
    }
    val comparator = if (direction == SortDirection.ASCENDING) ascending else ascending.reversed()
    val (directories, files) = entries.partition(ArchiveBrowserItem::directory)
    return directories.sortedWith(comparator) + files.sortedWith(comparator)
}

@Composable
private fun PropertiesPreview(source: PreviewSource, note: String? = null) {
    val dateFormat = rememberLocalizedDateTimeFormat()
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        Icon(Icons.Rounded.Description, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        note?.let { LText(it, modifier = Modifier.padding(vertical = 10.dp)) }
        PropertyRow("Name", source.name)
        PropertyRow("Location", source.locationLabel)
        PropertyRow("Size", source.sizeBytes?.let(FileSystemRules::humanBytes) ?: uiText("Unknown"))
        source.modifiedAtMillis?.let { PropertyRow("Modified", dateFormat.format(Date(it))) }
        PropertyRow("Readable", uiText(if (source.isReadable) "Yes" else "No"))
        PropertyRow("Writable", uiText(if (source.isWritable) "Yes" else "No"))
    }
}

@Composable
private fun PropertyRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        LText(label, modifier = Modifier.weight(0.35f), style = MaterialTheme.typography.labelMedium)
        Text(value, modifier = Modifier.weight(0.65f), style = MaterialTheme.typography.bodyMedium)
    }
    HorizontalDivider()
}

@Composable
private fun MediaDetailsDialog(source: PreviewSource, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val locale = LocalConfiguration.current.locales[0]
    val rows by produceState<Result<List<Pair<String, String>>>?>(null, source.key, locale) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                if (source.kind == EntryKind.IMAGE) imageMetadata(context, source, locale)
                else mediaPreviewInfo(context, source, includeArtwork = false).let {
                    listOfNotNull("Duration" to MediaPlaybackRules.timeLabel(it.durationMillis),
                        it.mimeType?.let { value -> "Type" to value }, it.bitRate?.let { value -> "Bit rate" to value })
                }
            }
        }
    }
    ShovelModalDialog(title = "Info", icon = Icons.Rounded.Info, onDismissRequest = onDismiss,
        modifier = Modifier.testTag("preview_details_dialog"), actions = { TextButton(onClick = onDismiss) { LText("Close") } }) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp)) {
            PropertyRow("Name", source.name)
            PropertyRow("Location", source.locationLabel)
            source.sizeBytes?.let { PropertyRow("Size", FileSystemRules.humanBytes(it)) }
            val result = rows
            if (result == null) CircularProgressIndicator()
            else result.fold(
                onSuccess = { values -> values.forEach { (label, value) -> PropertyRow(label, value) } },
                onFailure = { PreviewLoadError(it) },
            )
        }
    }
}

private fun mediaPreviewInfo(context: android.content.Context, source: PreviewSource, includeArtwork: Boolean = true): MediaPreviewInfo {
    val retriever = MediaMetadataRetriever()
    return try {
        // A content URI keeps the file descriptor owned by Shovel and avoids asking the
        // platform media process to reopen an app-private or privileged filesystem path.
        retriever.setDataSource(context, source.uri(context))
        MediaPreviewInfo(
            durationMillis = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?.coerceAtLeast(0L) ?: 0L,
            mimeType = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE),
            bitRate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE),
            artwork = if (!includeArtwork) null else retriever.embeddedPicture
                ?.takeIf { it.size <= 8 * 1_024 * 1_024 }
                ?.let(::decodeMediaArtwork),
        )
    } finally {
        retriever.release()
    }
}

private fun backgroundPlaylistForSource(context: android.content.Context, source: PreviewSource,
    playlist: List<com.shovel.filemanager.media.BackgroundMediaItem>): List<com.shovel.filemanager.media.BackgroundMediaItem> {
    val local = source.localFile?.let(Uri::fromFile)?.toString() ?: return playlist
    return playlist.map { if (it.uri == local) it.copy(uri = source.uri(context).toString()) else it }
}

private fun decodeMediaArtwork(bytes: ByteArray): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > 1_024 || bounds.outHeight / sample > 1_024) sample *= 2
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
}

private fun setMediaDataSource(
    player: MediaPlayer,
    context: android.content.Context,
    source: PreviewSource,
) {
    player.setDataSource(context, source.uri(context))
}

internal fun pdfDocumentInfo(context: android.content.Context, source: PreviewSource): PdfDocumentInfo =
    source.openFileDescriptor(context).use { descriptor ->
        PdfRenderer(descriptor).use { renderer ->
            require(renderer.pageCount > 0) { "The PDF has no pages" }
            require(renderer.pageCount <= PdfRenderRules.MAX_PAGE_COUNT) { "The PDF exceeds the safe limit of ${PdfRenderRules.MAX_PAGE_COUNT} pages" }
            PdfDocumentInfo(
                pages = List(renderer.pageCount) { pageIndex ->
                    renderer.openPage(pageIndex).use { page ->
                        PdfPageSize(page.width, page.height)
                    }
                },
            )
        }
    }

internal fun renderPdfPage(
    context: android.content.Context,
    source: PreviewSource,
    pageIndex: Int,
    viewportWidthPx: Int,
    zoom: Float,
): Bitmap {
    source.openFileDescriptor(context).use { descriptor ->
        PdfRenderer(descriptor).use { renderer ->
            require(renderer.pageCount in 1..PdfRenderRules.MAX_PAGE_COUNT) { "Unsupported PDF page count" }
            require(pageIndex in 0 until renderer.pageCount) { "The PDF page is unavailable" }
            renderer.openPage(pageIndex).use { page ->
                val (width, height) = PdfRenderRules.pageSizeForViewport(
                    sourceWidth = page.width,
                    sourceHeight = page.height,
                    viewportWidthPx = viewportWidthPx,
                    zoom = zoom,
                )
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(android.graphics.Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bitmap
            }
        }
    }
}

private fun decodeBoundedBitmap(context: android.content.Context, source: PreviewSource): Bitmap {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        val imageSource = source.localFile?.let { ImageDecoder.createSource(it) }
            ?: ImageDecoder.createSource(context.contentResolver, source.uri(context))
        return ImageDecoder.decodeBitmap(imageSource) { decoder, info, _ ->
            var sample = 1
            while (info.size.width / sample > 2_048 || info.size.height / sample > 2_048) sample *= 2
            decoder.setTargetSampleSize(sample)
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            decoder.memorySizePolicy = ImageDecoder.MEMORY_POLICY_LOW_RAM
        }
    }
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    source.openFileDescriptor(context).use { descriptor ->
        BitmapFactory.decodeFileDescriptor(descriptor.fileDescriptor, null, bounds)
    }
    require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Could not read the image" }
    var sample = 1
    while (bounds.outWidth / sample > 2_048 || bounds.outHeight / sample > 2_048) sample *= 2
    return requireNotNull(source.openFileDescriptor(context).use { descriptor ->
        BitmapFactory.decodeFileDescriptor(descriptor.fileDescriptor, null, BitmapFactory.Options().apply { inSampleSize = sample })
    }) {
        "Could not read the image"
    }
}

private fun imageMetadata(context: android.content.Context, source: PreviewSource, locale: Locale): List<Pair<String, String>> {
    fun attributes(exif: ExifInterface): List<Pair<String, String>> {
        val takenAt = listOf(
            ExifInterface.TAG_DATETIME_ORIGINAL to ExifInterface.TAG_OFFSET_TIME_ORIGINAL,
            ExifInterface.TAG_DATETIME_DIGITIZED to ExifInterface.TAG_OFFSET_TIME_DIGITIZED,
            ExifInterface.TAG_DATETIME to ExifInterface.TAG_OFFSET_TIME,
        ).firstNotNullOfOrNull { (dateTag, offsetTag) ->
            parseExifDateTimeMillis(exif.getAttribute(dateTag), exif.getAttribute(offsetTag))
        }
        return listOfNotNull(
            exif.getAttribute(ExifInterface.TAG_MAKE)?.let { "Manufacturer" to it },
            exif.getAttribute(ExifInterface.TAG_MODEL)?.let { "Model" to it },
            takenAt?.let {
                "Taken" to com.shovel.filemanager.ui.localization.localizedDateTime(it, locale)
            },
            exif.getAttribute(ExifInterface.TAG_ORIENTATION)?.let { "Orientation" to it },
        )
    }
    return source.localFile?.let { attributes(ExifInterface(it)) }
        ?: source.openFileDescriptor(context).use { attributes(ExifInterface(it.fileDescriptor)) }
}

private fun boundedOffset(candidate: Offset, viewport: IntSize, scale: Float): Offset {
    val maxX = viewport.width * (scale - 1f) / 2f
    val maxY = viewport.height * (scale - 1f) / 2f
    return Offset(candidate.x.coerceIn(-maxX, maxX), candidate.y.coerceIn(-maxY, maxY))
}

private fun sha256(context: android.content.Context, source: PreviewSource): String {
    val digest = MessageDigest.getInstance("SHA-256")
    source.openInputStream(context).buffered().use { input ->
        val buffer = ByteArray(256 * 1_024)
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            digest.update(buffer, 0, read)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

private fun shareFile(context: android.content.Context, source: PreviewSource) {
    val uri = source.uri(context)
    context.startActivity(
        Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = source.mimeType(context)
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri(source.name, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            },
            context.appString(R.string.share_file_chooser_title),
        ),
    )
}

internal fun openWith(context: android.content.Context, source: PreviewSource) {
    val uri = source.uri(context)
    val viewIntent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, source.mimeType(context))
        clipData = ClipData.newRawUri(source.name, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    val chooser = Intent.createChooser(
        viewIntent,
        context.appString(R.string.open_with_chooser_title, source.name),
    ).apply {
        putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(ComponentName(context, MainActivity::class.java)))
    }
    context.startActivity(chooser)
}

internal fun canEditExternally(context: android.content.Context, source: PreviewSource): Boolean {
    if (!EditabilityRules.mayUseExternalEditor(source.kind, source.extension)) return false
    val uri = runCatching { source.uri(context) }.getOrNull() ?: return false
    val intent = Intent(Intent.ACTION_EDIT).apply {
        setDataAndType(uri, source.mimeType(context))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
    }
    @Suppress("DEPRECATION")
    return context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
        .any { it.activityInfo?.packageName != context.packageName }
}

private fun createExternalEditIntent(context: android.content.Context, session: EditSession): Intent {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", session.workingFile)
    val editIntent = Intent(Intent.ACTION_EDIT).apply {
        setDataAndType(uri, session.mimeType)
        clipData = ClipData.newRawUri(session.displayName, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
    }
    return Intent.createChooser(
        editIntent,
        context.appString(R.string.edit_with_chooser_title, session.displayName),
    ).apply {
        putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(ComponentName(context, MainActivity::class.java)))
    }
}

private fun createSaveAsIntent(session: EditSession): Intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
    addCategory(Intent.CATEGORY_OPENABLE)
    type = session.mimeType.ifBlank { "application/octet-stream" }
    putExtra(Intent.EXTRA_TITLE, session.displayName)
}

private fun revisionSummary(revision: FileRevision, dateFormat: DateFormat): String = buildString {
    append(FileSystemRules.humanBytes(revision.sizeBytes))
    revision.modifiedAtMillis?.let {
        append(" · ")
        append(dateFormat.format(Date(it)))
    }
    append(" · SHA-256 ")
    append(revision.sha256.take(12))
    append('…')
}

private fun installApk(context: android.content.Context, file: File) {
    context.startActivity(
        Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(
                FileProvider.getUriForFile(context, "${context.packageName}.files", file),
                "application/vnd.android.package-archive",
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        },
    )
}

private fun entrySummary(context: android.content.Context, source: PreviewSource, dateFormat: DateFormat): String = listOfNotNull(
    source.sizeBytes?.let(FileSystemRules::humanBytes),
    source.modifiedAtMillis?.let { dateFormat.format(Date(it)) },
    source.mimeType(context).takeIf { source.modifiedAtMillis == null },
).joinToString(" · ")
